(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-common"],{

/***/ "+Dwh":
/*!*****************************************!*\
  !*** ./src/lib/commands/setColWidth.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "8e1d");


/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      _ref$cols = _ref.cols,
      cols = _ref$cols === void 0 ? 1 : _ref$cols,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  var resizeColWidth = value;
  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  var undoCmds = [];

  for (var col = index; col < index + cols; col++) {
    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('setColWidth', {
      index: col,
      value: resizeColWidth
    }));
  }

  if (render) {
    for (var _col = index; _col < index + cols; _col++) {
      worksheet.setColumnWidth(_col, resizeColWidth);
    }
  }

  if (undo) {
    for (var _col2 = index; _col2 < index + cols; _col2++) {
      var oldValue = Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(data.columns, [_col2, 'size']) || worksheet.defaults.colWidth;
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('setColWidth', {
        index: _col2,
        value: oldValue
      }));
    }

    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "/VHl":
/*!**********************************!*\
  !*** ./src/lib/parseSnapshot.js ***!
  \**********************************/
/*! exports provided: default, decodeSpreadsheetSave */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decodeSpreadsheetSave", function() { return decodeSpreadsheetSave; });
/* harmony import */ var core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.constructor */ "Oyvg");
/* harmony import */ var core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_search__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.search */ "OG14");
/* harmony import */ var core_js_modules_es6_regexp_search__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_search__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.regexp.to-string */ "a1Th");
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es6.string.bold */ "SMB2");
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/slicedToArray */ "k5N+");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es6.regexp.split */ "KKXr");
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./util */ "8e1d");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Constants */ "Eo9w");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Font */ "lLCG");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Logger */ "GONd");











var logger = new _Logger__WEBPACK_IMPORTED_MODULE_10__["default"]('parseSnapshot');
/* harmony default export */ __webpack_exports__["default"] = (function (snapshot) {
  logger.debug('parse snapshot', snapshot);
  var data = {
    data: {
      dataTable: []
    },
    colHeaderRowInfos: [{
      size: 25
    }],
    rowHeaderColInfos: [{
      size: 50
    }],
    rows: [],
    columns: [],
    spans: [],
    comments: [],
    floatingObjects: []
  };
  if (snapshot === '' || !snapshot) return data;
  var parts = decodeSpreadsheetSave(snapshot),
      sheet = snapshot.substring(parts.sheet.start, parts.sheet.end);
  var lines = sheet.split(/\r\n|\n/);
  var dataTable = {},
      borders = {},
      colors = {},
      layouts = {},
      formats = {},
      spans = [],
      rows = [],
      columns = [],
      floatingObjects = [],
      comments = [],
      objects = {
    borders: borders,
    colors: colors,
    layouts: layouts,
    formats: formats
  };

  for (var i = 0; i < lines.length; i++) {
    var line = lines[i],
        _parts = line.split(':');

    switch (_parts[0]) {
      case 'border':
        borders[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts[1])] = parseBorderStyle(_parts[2]).color;
        break;

      case 'color':
        colors[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts[1])] = _parts[2];
        break;

      case 'layout':
        _parts = lines[i].match(/^layout:(\d+):(.+)$/); // layouts can have ":" in them

        layouts[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts[1])] = _parts[2];
        break;

      case 'cellformat':
        formats[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts[1])] = Object(_util__WEBPACK_IMPORTED_MODULE_7__["decodeFromSave"])(_parts[2]);
        break;
    }
  }

  for (var _i = 0; _i < lines.length; _i++) {
    var _line = lines[_i],
        _parts2 = _line.split(':'),
        pos = void 0,
        cell = void 0,
        image = void 0,
        row = void 0,
        col = void 0;

    switch (_parts2[0]) {
      case 'version':
        break;

      case 'cell':
        pos = Object(_util__WEBPACK_IMPORTED_MODULE_7__["coordToPos"])(_parts2[1]);
        cell = Object(_util__WEBPACK_IMPORTED_MODULE_7__["safeGet"])(dataTable, "".concat(pos.row, ".").concat(pos.col)) || {};
        Object(_util__WEBPACK_IMPORTED_MODULE_7__["extend"])(cell, parseCellParts(pos.row, pos.col, _parts2, objects, spans, comments));
        Object(_util__WEBPACK_IMPORTED_MODULE_7__["safeSet"])(dataTable, "".concat(pos.row, ".").concat(pos.col), cell);
        break;

      case 'image':
        image = parseImageParts(_parts2);
        image.floatingObjectType = 1;
        floatingObjects.push(image);
        break;

      case 'row':
        row = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts2[1]) - 1;
        rows[row] = parseRowParts(_parts2);
        break;

      case 'col':
        col = Object(_util__WEBPACK_IMPORTED_MODULE_7__["labelToCol"])(_parts2[1]);
        columns[col] = parseColParts(_parts2);
        break;

      case 'freeze':
        {
          var _parts2$1$split = _parts2[1].split(/\|/g),
              _parts2$1$split2 = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_4__["default"])(_parts2$1$split, 3),
              _col = _parts2$1$split2[0],
              _row = _parts2$1$split2[1],
              type = _parts2$1$split2[2];

          if (type === 'freezeRow' || type === 'freezeRowCol') {
            data.frozenRowCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_row) + 1;
          }

          if (type === 'freezeCol' || type === 'freezeRowCol') {
            data.frozenColCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_col) + 1;
          }

          break;
        }

      case 'sheet':
        if (_parts2[1] === 'c') {
          data.columnCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts2[2]) < 20 ? 20 : Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts2[2]);
        }

        if (_parts2[3] === 'r') {
          data.rowCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts2[4]) < 100 ? 100 : Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(_parts2[4]);
        }

        break;
    }
  }

  Object(_util__WEBPACK_IMPORTED_MODULE_7__["extend"])(data, {
    data: {
      dataTable: dataTable
    },
    spans: spans,
    comments: comments,
    rows: rows,
    columns: columns,
    floatingObjects: floatingObjects
  });
  return data;
});

function parseCellParts(row, col, parts, objects, spans, comments) {
  var i = 2,
      cell = {},
      type,
      layout,
      format; // let { borders, colors, layouts, formats } = objects;

  var colors = objects.colors,
      layouts = objects.layouts,
      formats = objects.formats;
  var style = {},
      font = new _Font__WEBPACK_IMPORTED_MODULE_9__["default"](''),
      span = {
    row: row,
    col: col,
    rowCount: 1,
    colCount: 1
  },
      comment = {};

  while (type = parts[i++]) {
    switch (type) {
      case 'v':
      case 't':
        cell.value = Object(_util__WEBPACK_IMPORTED_MODULE_7__["decodeFromSave"])(parts[i++]);
        if (type === 't') cell.value = decodeURIComponent(cell.value);

        if (cell.value === '') {
          delete cell.value;
        } else if (!isNaN(cell.value)) {
          // 数字默认布局为右边
          cell.value = +cell.value;
        }

        break;

      case 'b':
        Object(_util__WEBPACK_IMPORTED_MODULE_7__["each"])(['top', 'right', 'bottom', 'left'], function (direction) {
          if (Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]) === 1) {
            style["border".concat(Object(_util__WEBPACK_IMPORTED_MODULE_7__["upperFirst"])(direction))] = {
              color: 'rgb(0, 0, 0)',
              style: 1
            };
          } else {
            style["border".concat(Object(_util__WEBPACK_IMPORTED_MODULE_7__["upperFirst"])(direction))] = {
              color: '',
              style: 1
            };
          }
        });
        break;

      case 'bg':
        style.backColor = colors[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++])];
        break;

      case 'rowspan':
        span.rowCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;

      case 'colspan':
        span.colCount = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;

      case 'c':
        style.foreColor = colors[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++])];
        break;

      case 'fs':
        font.size(Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]));
        break;

      case 'fw':
        font.bold(Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]));
        break;

      case 'fi':
        font.italic(Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]));
        break;

      case 'ft':
        style.textDecoration = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]) ? 2 : 0;
        break;

      case 'tw':
        if (Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]) === 1) {
          style.wordWrap = true;
        } else {
          style.wordWrap = false;
        }

        break;

      case 'l':
        layout = layouts[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++])];

        if (layout) {
          var vAlign = layout.split(';')[1].split(':')[1];
          style.vAlign = Object(_util__WEBPACK_IMPORTED_MODULE_7__["getVAlign"])(vAlign);
        } else {
          i--;
        }

        break;

      case 'cf':
        format = formats[Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++])];

        if (format) {
          style.hAlign = Object(_util__WEBPACK_IMPORTED_MODULE_7__["getHAlign"])(format);
        } else {
          i--;
        }

        break;

      case 'vtf':
        // 公式快照解析
        cell.formula = parts[5];
        cell.formula = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toStr"])(Object(_util__WEBPACK_IMPORTED_MODULE_7__["decodeFromSave"])(cell.formula));
        break;

      case 'cid':
        comment = {
          'span': span,
          'cid': parts[i++] || ''
        };
        comments.push(comment);
        break;
    }
  }

  if (font.toString()) {
    font.family(_Constants__WEBPACK_IMPORTED_MODULE_8__["DEFAULT_FONT"].FAMILY);
    style.font = font.toString();
  }

  if (span.rowCount > 1 || span.colCount > 1) spans.push(span);
  cell.style = style;
  return cell;
}

function parseImageParts(parts) {
  var image = {
    name: parts[1]
  };
  var i = 2,
      type;

  while (type = parts[i++]) {
    switch (type) {
      case 's':
        image.src = decodeURIComponent(parts[i++]);
        break;

      case 'x':
        image.x = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;

      case 'y':
        image.y = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;

      case 'w':
        image.width = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;

      case 'h':
        image.height = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;
    }
  }

  return image;
}

function parseRowParts(parts) {
  var row = {},
      i = 2,
      type;

  while (type = parts[i++]) {
    switch (type) {
      case 'h':
        row.size = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;
    }
  }

  return row;
}

function parseColParts(parts) {
  var column = {},
      i = 2,
      type;

  while (type = parts[i++]) {
    switch (type) {
      case 'w':
        column.size = Object(_util__WEBPACK_IMPORTED_MODULE_7__["toNum"])(parts[i++]);
        break;
    }
  }

  return column;
}

function parseBorderStyle(style) {
  var ret = {};
  style = style.split(' ');
  ret.width = style.shift();
  ret.type = style.shift();
  ret.color = style.join(' ');
  return ret;
} // Copy from SocialCalc


function decodeSpreadsheetSave(str) {
  var pos1, mpregex, searchinfo, boundary, boundaryregex, blanklineregex, start, ending, line, i, lines, p, pnum;
  var parts = {};
  var partlist = [];
  pos1 = str && str.search(/^MIME-Version:\s1\.0/im);
  if (pos1 < 0) return parts;
  mpregex = /^Content-Type:\s*multipart\/mixed;\s*boundary=(\S+)/gim;
  mpregex.lastIndex = pos1;
  searchinfo = mpregex.exec(str);
  if (mpregex.lastIndex <= 0) return parts;
  boundary = searchinfo[1];
  boundaryregex = new RegExp('^--' + boundary + '(?:\r\n|\n)', 'mg');
  boundaryregex.lastIndex = mpregex.lastIndex;
  searchinfo = boundaryregex.exec(str); // find header top boundary

  blanklineregex = /(?:\r\n|\n)(?:\r\n|\n)/gm;
  blanklineregex.lastIndex = boundaryregex.lastIndex;
  searchinfo = blanklineregex.exec(str); // skip to after blank line

  if (!searchinfo) return parts;
  start = blanklineregex.lastIndex;
  boundaryregex.lastIndex = start;
  searchinfo = boundaryregex.exec(str); // find end of header

  if (!searchinfo) return parts;
  ending = searchinfo.index;
  lines = str.substring(start, ending).split(/\r\n|\n/); // get header as lines

  for (i = 0; i < lines.length; i++) {
    line = lines[i];
    p = line.split(':');

    switch (p[0]) {
      case 'version':
        break;

      case 'part':
        partlist.push(p[1]);
        break;
    }
  }

  for (pnum = 0; pnum < partlist.length; pnum++) {
    // get each part
    blanklineregex.lastIndex = ending;
    searchinfo = blanklineregex.exec(str); // find blank line ending mime-part header

    if (!searchinfo) return parts;
    start = blanklineregex.lastIndex;

    if (pnum == partlist.length - 1) {
      // last one has different boundary
      boundaryregex = new RegExp('^--' + boundary + '--$', 'mg');
    }

    boundaryregex.lastIndex = start;
    searchinfo = boundaryregex.exec(str); // find ending boundary

    if (!searchinfo) return parts;
    ending = searchinfo.index;
    parts[partlist[pnum]] = {
      start: start,
      end: ending
    }; // return position within full string
  }

  return parts;
}

/***/ }),

/***/ 1:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "11+Z":
/*!********************************!*\
  !*** ./src/lib/generateCmd.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Constants */ "Eo9w");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./util */ "8e1d");



/* harmony default export */ __webpack_exports__["default"] = (function (type, options) {
  switch (type) {
    case 'setValue':
      return setValueCmd(options);

    case 'setStyle':
      return setStyleCmd(options);

    case 'setRowHeight':
      return setRowHeightCmd(options);

    case 'setColWidth':
      return setColWidthCmd(options);

    case 'freeze':
      return freezeCmd(options);

    case 'setImage':
      return setImageCmd(options);

    case 'merge':
      return mergeCmd(options);

    case 'insertRow':
      return insertRowCmd(options);

    case 'insertCol':
      return insertColCmd(options);

    case 'deleteRow':
      return deleteRowCmd(options);

    case 'deleteCol':
      return deleteColCmd(options);

    case 'setFormula':
      return setFormulaCmd(options);

    case 'setAll':
      return setAllCmd(options);

    case 'setComment':
      return setCommentCmd(options);
  }
});

function getCmdForSetValue(selection, value) {
  return "set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " text t ").concat(encodeURIComponent(value)); // if(isNaN(value)){
  //     return `set ${selectionToRange(selection)} text t ${encodeURIComponent(
  //         value
  //     )}`;
  // }else{
  //     return `set ${selectionToRange(selection)} text v ${encodeURIComponent(
  //         value
  //     )}`;
  // }
}

function setValueCmd(options) {
  var selection = options.selection,
      value = options.value;
  return getCmdForSetValue(selection, value);
}

function setCommentCmd(options) {
  var selection = options.selection,
      value = options.value;
  return "set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " commentId ").concat(encodeURIComponent(value));
}

function setStyleCmd(_ref) {
  var selection = _ref.selection,
      property = _ref.property,
      value = _ref.value;
  var range = Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection);

  switch (property) {
    case 'bold':
      return "set ".concat(range, " weight ").concat(value);

    case 'textWrap':
      return "set ".concat(range, " textwrap ").concat(value);

    case 'italic':
    case 'strike':
      return "set ".concat(range, " ").concat(property, " ").concat(value);

    case 'hAlign':
      return "set ".concat(range, " cellformat ").concat(value);

    case 'vAlign':
      return "set ".concat(range, " layout padding:* * * *;vertical-align:").concat(value, ";");

    case 'foreColor':
      return "set ".concat(range, " color ").concat(value);

    case 'backColor':
      return "set ".concat(range, " bgcolor ").concat(value);

    case 'fontSize':
      return "set ".concat(range, " size ").concat(value);

    case 'borderTop':
      return "set ".concat(range, " bt ").concat(value);

    case 'borderRight':
      return "set ".concat(range, " br ").concat(value);

    case 'borderBottom':
      return "set ".concat(range, " bb ").concat(value);

    case 'borderLeft':
      return "set ".concat(range, " bl ").concat(value);
  }
}

function setRowHeightCmd(_ref2) {
  var index = _ref2.index,
      value = _ref2.value;
  return "set ".concat(index + 1, " height ").concat(value);
}

function setColWidthCmd(_ref3) {
  var index = _ref3.index,
      value = _ref3.value;
  return "set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["colToLabel"])(index + 1), " width ").concat(value);
}

function freezeCmd(_ref4) {
  var type = _ref4.type,
      row = _ref4.row,
      col = _ref4.col;

  switch (type) {
    case 'row':
      type = 'freezeRow';
      break;

    case 'column':
      type = 'freezeCol';
      break;

    case 'rowColumn':
      type = 'freezeRowCol';
      break;

    case 'cancel':
      type = 'freezeCancel';
      break;
  }

  return "set sheet freeze ".concat(col, "|").concat(row, "|").concat(type);
}

function setImageCmd(options) {
  var id = options.id,
      value = options.value;

  if (value) {
    var src = value.src,
        x = value.x,
        y = value.y,
        width = value.width,
        height = value.height;
    return "set image ".concat(id, " all :s:").concat(encodeURIComponent(src), ":x:").concat(x, ":y:").concat(y, ":w:").concat(width, ":h:").concat(height);
  } else {
    return "set image ".concat(id);
  }
}

function mergeCmd(_ref5) {
  var selection = _ref5.selection,
      value = _ref5.value;
  var range = value ? Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection) : Object(_util__WEBPACK_IMPORTED_MODULE_2__["posToCoord"])(selection.row, selection.col);
  return "".concat(value ? 'merge' : 'unmerge', " ").concat(range);
}

function insertRowCmd(_ref6) {
  var index = _ref6.index,
      colCount = _ref6.colCount;
  return "insertrow ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])({
    row: index,
    rowCount: 1,
    col: 0,
    colCount: colCount
  }));
}

function insertColCmd(_ref7) {
  var index = _ref7.index,
      rowCount = _ref7.rowCount;
  return "insertcol ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])({
    col: index,
    colCount: 1,
    row: 0,
    rowCount: rowCount
  }));
}

function deleteRowCmd(_ref8) {
  var index = _ref8.index,
      colCount = _ref8.colCount;
  return "deleterow ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])({
    col: 0,
    colCount: colCount,
    row: index,
    rowCount: 1
  }));
}

function deleteColCmd(_ref9) {
  var index = _ref9.index,
      rowCount = _ref9.rowCount;
  return "deletecol ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])({
    row: 0,
    rowCount: rowCount,
    col: index,
    colCount: 1
  }));
}

function setFormulaCmd(_ref10) {
  var selection = _ref10.selection,
      value = _ref10.value;
  return "set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " formula ").concat(value);
}

function setAllCmd(_ref11) {
  var selection = _ref11.selection,
      value = _ref11.value;
  var style = value.style,
      formula = value.formula;
  var ret = [];

  if (value.value) {
    ret = ret.concat([getCmdForSetValue(selection, value.value)]);
  }

  if (style) {
    if (style.font) {
      if (style.font.indexOf('px') > -1) {
        var regSize = /(\d+)px/;
        var match = style.font.match(regSize);
        var size = Object(_util__WEBPACK_IMPORTED_MODULE_2__["toNum"])(match[1]);
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " size ").concat(size)]);
      } else {
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " size ").concat(_Constants__WEBPACK_IMPORTED_MODULE_1__["DEFAULT_FONT"].SIZE)]);
      }

      if (style.font.indexOf('700') > -1 || style.font.indexOf('bold') > -1) {
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " weight 1")]);
      } else {
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " weight 0")]);
      }

      if (style.font.indexOf('italic') > -1) {
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " italic 1")]);
      } else {
        ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " italic 0")]);
      }
    }

    if (style.backColor) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " bgcolor ").concat(style.backColor)]);
    }

    if (style.foreColor) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " color ").concat(style.foreColor)]);
    }

    if (style.borderTop) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " bt 1px solid rgb(0, 0, 0)")]);
    }

    if (style.borderRight) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " br 1px solid rgb(0, 0, 0)")]);
    }

    if (style.borderBottom) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " bb 1px solid rgb(0, 0, 0)")]);
    }

    if (style.borderLeft) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " bl 1px solid rgb(0, 0, 0)")]);
    }

    if (style.hAlign === 0) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " cellformat left")]);
    } else if (style.hAlign === 1) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " cellformat middle")]);
    } else if (style.hAlign === 2) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " cellformat right")]);
    }

    if (style.vAlign === 0) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " layout padding:* * * *;vertical-align:top;")]);
    }

    if (style.vAlign === 1) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " layout padding:* * * *;vertical-align:middle;")]);
    } else if (style.vAlign === 2) {
      ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " layout padding:* * * *;vertical-align:bottom;")]);
    }

    ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " strike ").concat(style.textDecoration === 2 ? 1 : 0)]);
    ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " textwrap ").concat(style.wordWrap === true ? 1 : 0)]);
  }

  if (formula) {
    ret = ret.concat(["set ".concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection), " formula ").concat(formula)]);
  }

  if (selection.rowCount > 1 || selection.colCount > 1) {
    var range = value ? Object(_util__WEBPACK_IMPORTED_MODULE_2__["selectionToRange"])(selection) : Object(_util__WEBPACK_IMPORTED_MODULE_2__["posToCoord"])(selection.row, selection.col);
    ret = ret.concat(["".concat(value ? 'merge' : 'unmerge', " ").concat(range)]);
  }

  return ret;
}

/***/ }),

/***/ 2:
/*!**********************!*\
  !*** util (ignored) ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "2c2J":
/*!**********************************!*\
  !*** ./src/store/modules/app.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/defineProperty */ "oyJW");
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.array.iterator */ "yt8O");
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.object.keys */ "RW0V");
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mutationTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../mutationTypes */ "NPqI");
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! vue */ "Kw5r");






var _mutations;



/* harmony default export */ __webpack_exports__["default"] = ({
  state: {
    fileType: 'excel',
    isReadOnly: false,
    isEdit: true,
    isCollection: false,
    enableSendButtonFileName: false,
    enableSendButtonSpread: false,
    baseMsg: {}
  },
  getters: {},
  mutations: (_mutations = {}, Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_5__["default"].UPDATE_SETTINGS, function (state, payload) {
    if (payload instanceof Object) {
      Object.keys(payload).forEach(function (key) {
        vue__WEBPACK_IMPORTED_MODULE_6__["default"].set(state, key, payload[key]);
      });
    }
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_5__["default"].UPDATE_BASE_MSG, function (state, _ref) {
    var baseMsg = _ref.baseMsg;
    state.baseMsg = baseMsg;
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_5__["default"].UPDATE_WATERMARK, function (state) {
    state.openMark = state.openMark ? 0 : 1;
  }), _mutations),
  actions: {}
});

/***/ }),

/***/ 3:
/*!************************!*\
  !*** buffer (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "3iHG":
/*!*****************************************!*\
  !*** ./src/lib/commands/clearFormat.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../config */ "Gh6Q");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "8e1d");


/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync,
      unRefresh = _ref.unRefresh;

  // 添加命令到commands/undoCmds数组
  var commands = [];
  var undoCmds = []; // 获取操作返回的commands/undoCmds数组

  var cmdRet = {}; // 撤销管理器

  var undoManager = this.undoManager,
      data = this.data;
  selection.row = selection.row < 0 ? 0 : selection.row;
  selection.col = selection.col < 0 ? 0 : selection.col;
  if (undoStack) undoManager.addUndoStack(); // 清除合并单元格

  var spans = Object(_util__WEBPACK_IMPORTED_MODULE_1__["getMergeCellList"])(selection, data.spans);

  if (spans && spans.length) {
    Object(_util__WEBPACK_IMPORTED_MODULE_1__["each"])(spans || [], function (span) {
      cmdRet = _this.execute('merge', {
        selection: span,
        value: 0,
        sync: sync,
        render: render,
        undoStack: undoStack,
        undo: undo,
        clear: true,
        unRefresh: unRefresh
      });
      commands = commands.concat(Object(_util__WEBPACK_IMPORTED_MODULE_1__["toArr"])(cmdRet.commands));
      undoCmds = undoCmds.concat(Object(_util__WEBPACK_IMPORTED_MODULE_1__["toArr"])(cmdRet.undoCmds));
    });
  } // 清除格式命令将所有指令合并


  for (var key in _config__WEBPACK_IMPORTED_MODULE_0__["clearConfig"]) {
    cmdRet = this.execute('setStyle', {
      selection: selection,
      property: key,
      value: _config__WEBPACK_IMPORTED_MODULE_0__["clearConfig"][key],
      sync: sync,
      render: render,
      undoStack: undoStack,
      undo: undo,
      clear: true,
      unRefresh: unRefresh
    });
    commands = commands.concat(Object(_util__WEBPACK_IMPORTED_MODULE_1__["toArr"])(cmdRet.commands));
    undoCmds = undoCmds.concat(Object(_util__WEBPACK_IMPORTED_MODULE_1__["toArr"])(cmdRet.undoCmds));
  } // 清除格式操作将所有合并后的指令，一起压入撤销栈


  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  } // 清除格式操作将所有合并后的指令，一起发送指令同步数据到远程


  if (sync) this.sendCmds(commands);
  return {
    commands: commands,
    undoCmds: undoCmds
  };
});

/***/ }),

/***/ 4:
/*!************************!*\
  !*** crypto (ignored) ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "4s26":
/*!***************************************!*\
  !*** ./src/lib/commands/insertRow.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");


var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('insertRow');
/* globals GC */

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(index);
  var undoManager = this.undoManager,
      worksheet = this.worksheet;
  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  var colCount = worksheet.getColumnCount();
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('insertRow', {
    index: index,
    colCount: colCount
  }));

  if (render) {
    worksheet.addRows(index, 1);

    if (index > 0) {
      worksheet.copyTo(index - 1, 0, index, 0, 1, colCount, GC.Spread.Sheets.CopyToOptions.style);
      var rowHeight = worksheet.getRowHeight(index - 1);
      worksheet.setRowHeight(index, rowHeight, GC.Spread.Sheets.SheetArea.viewport);
    }
  }

  if (undo) {
    var undoCmds = [];
    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('deleteRow', {
      index: index,
      colCount: colCount
    }));
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "4wGw":
/*!***************************************!*\
  !*** ./src/lib/commands/insertCol.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");


var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('insertCol');
/* globals GC */

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(index);
  var undoManager = this.undoManager,
      worksheet = this.worksheet;
  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  var rowCount = worksheet.getRowCount();
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('insertCol', {
    index: index,
    rowCount: rowCount
  }));

  if (render) {
    worksheet.addColumns(index, 1);

    if (index > 0) {
      worksheet.copyTo(0, index - 1, 0, index, rowCount, 1, GC.Spread.Sheets.CopyToOptions.style);
      var colWidth = worksheet.getColumnWidth(index - 1);
      worksheet.setColumnWidth(index, colWidth, GC.Spread.Sheets.SheetArea.viewport);
    }
  }

  if (undo) {
    var undoCmds = [];
    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('deleteCol', {
      index: index,
      rowCount: rowCount
    }));
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "5Rcl":
/*!************************************!*\
  !*** ./src/lib/commands/freeze.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util */ "8e1d");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('freeze');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      type = _ref.type,
      row = _ref.row,
      col = _ref.col,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(type, row, col);
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  var preRow = data.frozenRowCount;
  var preCol = data.frozenColCount;
  var preType = computeType(preRow, preCol);
  var isNeedAction = 1 || isSomeAction({
    type: type,
    row: row,
    col: col
  }, {
    preType: preType,
    preRow: preRow,
    preCol: preCol
  });

  if (isNeedAction) {
    if (undoStack) undoManager.addUndoStack();
    var commands = [];
    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('freeze', {
      type: type,
      row: row,
      col: col
    }));

    if (render) {
      if (type === 'row' || type === 'rowColumn') {
        worksheet.frozenRowCount(row);
        worksheet.showRow(row);
      }

      if (type === 'column' || type === 'rowColumn') {
        worksheet.frozenColumnCount(col);
        worksheet.showColumn(col);
      }

      if (type === 'cancel') {
        worksheet.frozenRowCount(0);
        worksheet.frozenColumnCount(0); // Need this to prevent auto scrolling.

        worksheet.showColumn(0);
        worksheet.showRow(0);
      }

      worksheet.options.frozenlineColor = 'rgba(0, 0, 0, .4)'; // 冻结线颜色样式
    }

    if (undo) {
      var undoCmds = getUndoCmds(type, preType, preRow, preCol);
      undoManager.addUndo({
        commands: commands,
        undoCmds: undoCmds
      });
    }

    if (sync) this.sendCmds(commands);
    return commands;
  }

  return null;
}); // 计算出上一次的冻结指令类型

function computeType(preRow, preCol) {
  var type = 'column';

  if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(preRow)) {
    if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(preCol)) {
      type = 'rowColumn';
    } else {
      type = 'row';
    }
  } else if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(preCol)) {
    if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(preRow)) {
      type = 'rowColumn';
    } else {
      type = 'column';
    }
  } else {
    type = 'cancel';
  }

  return type;
} // 与上一次操作相同效果的操作，不需要加入undo


function isSomeAction(newAction, preAction) {
  var newType = newAction.type,
      newRow = newAction.row,
      newCol = newAction.col;
  var preType = preAction.preType,
      preRow = preAction.preRow,
      preCol = preAction.preCol;
  var flag = true;

  switch (preType) {
    case 'row':
      if (newType === preType && newRow === preRow) {
        flag = false;
      }

      break;

    case 'column':
      if (newType === preType && newCol === preCol) {
        flag = false;
      }

      break;

    case 'rowColumn':
      if (newType === preType && newRow === preRow && newCol === preCol || newType === 'row' && newRow === preRow || newType === 'column' && newCol === preCol) {
        flag = false;
      }

      break;

    case 'cancel':
      if (newType === preType) {
        flag = false;
      }

      break;
  }

  return flag;
} // 获取冻结 undo 指令


function getUndoCmds(newType, preType, preRow, preCol) {
  var row = 0;
  var col = 0;
  var undoCmds = [];

  switch (preType) {
    case 'row':
      row = preRow;
      col = 0;
      break;

    case 'column':
      row = 0;
      col = preCol;
      break;

    case 'rowColumn':
      row = preRow;
      col = preCol;
      break;

    case 'cancel':
      row = 0;
      col = 0;
      break;
  }

  undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('freeze', {
    type: preType,
    row: row,
    col: col
  })); // 特殊处理

  if (preType === 'row') {
    if (newType === 'column') {
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('freeze', {
        type: 'column',
        row: 0,
        col: 0
      }));
      return undoCmds;
    } else if (newType === 'rowColumn') {
      undoCmds.push(getCancelCmd());
    }
  } else if (preType === 'column') {
    if (newType === 'row') {
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('freeze', {
        type: 'row',
        row: 0,
        col: 0
      }));
      return undoCmds;
    } else if (newType === 'rowColumn') {
      undoCmds.push(getCancelCmd());
    }
  }

  return undoCmds;
}

function getCancelCmd() {
  return Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('freeze', {
    type: 'cancel',
    row: 0,
    col: 0
  });
}

/***/ }),

/***/ "7rPh":
/*!*****************************************!*\
  !*** ./src/lib/commands/deleteValue.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Logger */ "GONd");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_2__["default"]('deleteValue');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection);
  var undoManager = this.undoManager,
      data = this.data,
      worksheet = this.worksheet;
  var dataTable = data.data.dataTable; // 添加栈

  if (undoStack) undoManager.addUndoStack(); // 添加命令到commands/undoCmds数组

  var commands = [];
  var undoCmds = []; // 按顺序先设置公式为空, 再设置值

  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setFormula', {
    selection: selection,
    value: undefined
  }), Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
    selection: selection,
    value: ''
  })); // 添加命令到undoCmds 支持撤销操作

  if (undo) {
    Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
      var value = Object(_util__WEBPACK_IMPORTED_MODULE_0__["safeGet"])(dataTable, [row, col, 'value']) || '';
      var formula = Object(_util__WEBPACK_IMPORTED_MODULE_0__["safeGet"])(dataTable, [row, col, 'formula']) || '';

      if (formula) {
        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setFormula', {
          selection: {
            row: row,
            col: col,
            rowCount: 1,
            colCount: 1
          },
          value: formula
        }));
      } else {
        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
          selection: {
            row: row,
            col: col,
            rowCount: 1,
            colCount: 1
          },
          value: value
        }));
      }
    });
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  } // 自适应调整行高


  for (var row = selection.row; row < selection.row + selection.rowCount; row++) {
    worksheet.autoFitRow(row);
  } // 发送指令同步数据到远程


  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "8H8d":
/*!**************************************!*\
  !*** ./src/store/modules/comment.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/defineProperty */ "oyJW");
/* harmony import */ var _mutationTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../mutationTypes */ "NPqI");


/* harmony default export */ __webpack_exports__["default"] = ({
  state: {
    commentList: []
  },
  mutations: Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _mutationTypes__WEBPACK_IMPORTED_MODULE_1__["default"].UPDATE_COMMENT_LIST, function (state, _ref) {
    var comment = _ref.comment;
    state.commentList.push(comment);
  })
});

/***/ }),

/***/ "8e1d":
/*!*************************!*\
  !*** ./src/lib/util.js ***!
  \*************************/
/*! exports provided: inherits, has, ColorHash, slice, keys, freeze, isUndef, allKeys, before, isObj, cloneObject, colToLabel, colorToHex, colorToRgb, idxOf, coordToPos, noop, toStr, decodeFromSave, detectBrowser, detectOs, restArgs, downloadImage, optimizeCb, getBorder, getColData, getColorHash, getMergeCellList, getMouseXY, identity, objToStr, isArr, castPath, safeGet, flatten, isBlob, isDate, isFile, isFn, isMiniProgram, isNum, isArrLike, each, cloneDeep, createAssigner, defaults, extend, clone, copy, extendOwn, invert, values, contain, isStr, getFontSize, getHAlign, getVAlign, isBrowser, root, Blob, isFormula, splitPath, isImage, isMatch, isNaN, isNode, isRegExp, iterateSelection, keyCode, labelToCol, last, repeat, lpad, dateFormat, ltrim, mapGetters, matcher, safeCb, filter, difference, map, toArr, Class, Enum, createUrl, download, intersect, nextTick, now, partial, once, Emitter, Logger, pickImage, posToCoord, random, randomBytes, rangeToSelection, rtrim, safeSet, selectionToRange, startWith, strHash, type, upperFirst, stringify, timediff, toNum, trim, uploadImage, uuid, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(global, process) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "inherits", function() { return inherits; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "has", function() { return has; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ColorHash", function() { return ColorHash; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "slice", function() { return slice; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "keys", function() { return keys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "freeze", function() { return freeze; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isUndef", function() { return isUndef; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "allKeys", function() { return allKeys; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "before", function() { return before; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isObj", function() { return isObj; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneObject", function() { return cloneObject; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colToLabel", function() { return colToLabel; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorToHex", function() { return colorToHex; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "colorToRgb", function() { return colorToRgb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "idxOf", function() { return idxOf; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "coordToPos", function() { return coordToPos; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toStr", function() { return toStr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "decodeFromSave", function() { return decodeFromSave; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detectBrowser", function() { return detectBrowser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "detectOs", function() { return detectOs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "restArgs", function() { return restArgs; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "downloadImage", function() { return downloadImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "optimizeCb", function() { return optimizeCb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBorder", function() { return getBorder; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColData", function() { return getColData; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getColorHash", function() { return getColorHash; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMergeCellList", function() { return getMergeCellList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMouseXY", function() { return getMouseXY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "identity", function() { return identity; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "objToStr", function() { return objToStr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isArr", function() { return isArr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "castPath", function() { return castPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "safeGet", function() { return safeGet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "flatten", function() { return flatten; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isBlob", function() { return isBlob; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isDate", function() { return isDate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFile", function() { return isFile; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFn", function() { return isFn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMiniProgram", function() { return isMiniProgram; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isNum", function() { return isNum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isArrLike", function() { return isArrLike; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "each", function() { return each; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "cloneDeep", function() { return cloneDeep; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createAssigner", function() { return createAssigner; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "defaults", function() { return defaults; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extend", function() { return extend; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clone", function() { return clone; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "copy", function() { return copy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "extendOwn", function() { return extendOwn; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "invert", function() { return invert; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "values", function() { return values; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "contain", function() { return contain; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isStr", function() { return isStr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFontSize", function() { return getFontSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getHAlign", function() { return getHAlign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getVAlign", function() { return getVAlign; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isBrowser", function() { return isBrowser; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "root", function() { return root; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Blob", function() { return Blob; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isFormula", function() { return isFormula; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "splitPath", function() { return splitPath; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isImage", function() { return isImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isMatch", function() { return isMatch; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isNaN", function() { return isNaN; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isNode", function() { return isNode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isRegExp", function() { return isRegExp; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "iterateSelection", function() { return iterateSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "keyCode", function() { return keyCode; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "labelToCol", function() { return labelToCol; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "last", function() { return last; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "repeat", function() { return repeat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "lpad", function() { return lpad; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dateFormat", function() { return dateFormat; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ltrim", function() { return ltrim; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapGetters", function() { return mapGetters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "matcher", function() { return matcher; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "safeCb", function() { return safeCb; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "filter", function() { return filter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "difference", function() { return difference; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "map", function() { return map; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toArr", function() { return toArr; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Class", function() { return Class; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Enum", function() { return Enum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "createUrl", function() { return createUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "download", function() { return download; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "intersect", function() { return intersect; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "nextTick", function() { return nextTick; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "now", function() { return now; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "partial", function() { return partial; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "once", function() { return _once; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Emitter", function() { return Emitter; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Logger", function() { return Logger; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "pickImage", function() { return pickImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "posToCoord", function() { return posToCoord; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "random", function() { return random; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "randomBytes", function() { return randomBytes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rangeToSelection", function() { return rangeToSelection; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rtrim", function() { return rtrim; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "safeSet", function() { return safeSet; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "selectionToRange", function() { return selectionToRange; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "startWith", function() { return startWith; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "strHash", function() { return strHash; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "type", function() { return type; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "upperFirst", function() { return upperFirst; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "stringify", function() { return stringify; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "timediff", function() { return timediff; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toNum", function() { return toNum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "trim", function() { return trim; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uploadImage", function() { return uploadImage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "uuid", function() { return uuid; });
/* harmony import */ var core_js_modules_es6_typed_uint8_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.typed.uint8-array */ "NO8f");
/* harmony import */ var core_js_modules_es6_typed_uint8_array__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_typed_uint8_array__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.function.name */ "f3/d");
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es6_number_constructor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es6.number.constructor */ "xfY5");
/* harmony import */ var core_js_modules_es6_number_constructor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_number_constructor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es6.regexp.replace */ "pIFo");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es6.regexp.split */ "KKXr");
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/typeof */ "a94B");
/* harmony import */ var core_js_modules_es6_object_freeze__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! core-js/modules/es6.object.freeze */ "DW2E");
/* harmony import */ var core_js_modules_es6_object_freeze__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_object_freeze__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es6.array.iterator */ "yt8O");
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! core-js/modules/es6.object.keys */ "RW0V");
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es6.regexp.to-string */ "a1Th");
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_14__);
// Built by eustia.

















var _ = {};
/* ------------------------------ inherits ------------------------------ */

var inherits = _.inherits = function () {
  /* Inherit the prototype methods from one constructor into another.
   *
   * |Name      |Type    |Desc       |
   * |----------|--------|-----------|
   * |Class     |function|Child Class|
   * |SuperClass|function|Super Class|
   *
   * ```javascript
   * function People(name)
   * {
   *     this._name = name;
   * }
   * People.prototype = {
   *     getName: function ()
   *     {
   *         return this._name;
   *     }
   * };
   * function Student(name)
   * {
   *     this._name = name;
   * }
   * inherits(Student, People);
   * var s = new Student('RedHood');
   * s.getName(); // -> 'RedHood'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(Class, SuperClass) {
    if (objCreate) return Class.prototype = objCreate(SuperClass.prototype);
    noop.prototype = SuperClass.prototype;
    Class.prototype = new noop();
  }

  var objCreate = Object.create;

  function noop() {}

  return exports;
}();
/* ------------------------------ has ------------------------------ */

var has = _.has = function () {
  /* Checks if key is a direct property.
   *
   * |Name  |Type   |Desc                            |
   * |------|-------|--------------------------------|
   * |obj   |object |Object to query                 |
   * |key   |string |Path to check                   |
   * |return|boolean|True if key is a direct property|
   *
   * ```javascript
   * has({one: 1}, 'one'); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  var hasOwnProp = Object.prototype.hasOwnProperty;

  function exports(obj, key) {
    return hasOwnProp.call(obj, key);
  }

  return exports;
}();
/* ------------------------------ ColorHash ------------------------------ */

var ColorHash = _.ColorHash = function (exports) {
  /**
   * Color Hash Class
   *
   * @class
   */
  exports =
  /*#__PURE__*/
  function () {
    function ColorHash(options) {
      Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_12__["default"])(this, ColorHash);

      options = options || {};
      var LS = [options.lightness, options.saturation].map(function (param) {
        param = param || [0.35, 0.5, 0.65]; // note that 3 is a prime

        return Object.prototype.toString.call(param) === '[object Array]' ? param.concat() : [param];
      });
      this.L = LS[0];
      this.S = LS[1];
      this.hash = options.hash || BKDRHash;
    }
    /**
     * Returns the hash in [h, s, l].
     * Note that H ∈ [0, 360); S ∈ [0, 1]; L ∈ [0, 1];
     *
     * @param {String} str string to hash
     * @returns {Array} [h, s, l]
     */


    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_13__["default"])(ColorHash, [{
      key: "hsl",
      value: function hsl(str) {
        var H, S, L;
        var hash = this.hash(str);
        H = hash % 359; // note that 359 is a prime

        hash = parseInt(hash / 360);
        S = this.S[hash % this.S.length];
        hash = parseInt(hash / this.S.length);
        L = this.L[hash % this.L.length];
        return [H, S, L];
      }
      /**
       * Returns the hash in [r, g, b].
       * Note that R, G, B ∈ [0, 255]
       *
       * @param {String} str string to hash
       * @returns {Array} [r, g, b]
       */

    }, {
      key: "rgb",
      value: function rgb(str) {
        var hsl = this.hsl(str);
        return HSL2RGB.apply(this, hsl);
      }
      /**
       * Returns the hash in hex
       *
       * @param {String} str string to hash
       * @returns {String} hex with #
       */

    }, {
      key: "hex",
      value: function hex(str) {
        var rgb = this.rgb(str);
        return RGB2HEX(rgb);
      }
    }]);

    return ColorHash;
  }();
  /**
   * BKDR Hash (modified version)
   *
   * @param {String} str string to hash
   * @returns {Number}
   */


  function BKDRHash(str) {
    var seed = 131;
    var seed2 = 137;
    var hash = 0; // make hash more sensitive for short string like 'a', 'b', 'c'

    str += 'x'; // Note: Number.MAX_SAFE_INTEGER equals 9007199254740991

    var MAX_SAFE_INTEGER = parseInt(9007199254740991 / seed2);

    for (var i = 0; i < str.length; i++) {
      if (hash > MAX_SAFE_INTEGER) {
        hash = parseInt(hash / seed2);
      }

      hash = hash * seed + str.charCodeAt(i);
    }

    return hash;
  }
  /**
   * Convert RGB Array to HEX
   *
   * @param {Array} RGBArray - [R, G, B]
   * @returns {String} 6 digits hex starting with #
   */


  function RGB2HEX(RGBArray) {
    var hex = '#';
    RGBArray.forEach(function (value) {
      if (value < 16) {
        hex += 0;
      }

      hex += value.toString(16);
    });
    return hex;
  }
  /**
   * Convert HSL to RGB
   *
   * @see {@link http://zh.wikipedia.org/wiki/HSL?HSV????} for further information.
   * @param {Number} H Hue ? [0, 360)
   * @param {Number} S Saturation ? [0, 1]
   * @param {Number} L Lightness ? [0, 1]
   * @returns {Array} R, G, B ? [0, 255]
   */


  function HSL2RGB(H, S, L) {
    H /= 360;
    var q = L < 0.5 ? L * (1 + S) : L + S - L * S;
    var p = 2 * L - q;
    return [H + 1 / 3, H, H - 1 / 3].map(function (color) {
      if (color < 0) {
        color++;
      }

      if (color > 1) {
        color--;
      }

      if (color < 1 / 6) {
        color = p + (q - p) * 6 * color;
      } else if (color < 0.5) {
        color = q;
      } else if (color < 2 / 3) {
        color = p + (q - p) * 6 * (2 / 3 - color);
      } else {
        color = p;
      }

      return Math.round(color * 255);
    });
  }

  return exports;
}({});
/* ------------------------------ slice ------------------------------ */

var slice = _.slice = function () {
  /* Create slice of source array or array-like object.
   *
   * |Name              |Type  |Desc                      |
   * |------------------|------|--------------------------|
   * |array             |array |Array to slice            |
   * |[start=0]         |number|Start position            |
   * |[end=array.length]|number|End position, not included|
   *
   * ```javascript
   * slice([1, 2, 3, 4], 1, 2); // -> [2]
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(arr, start, end) {
    var len = arr.length;

    if (start == null) {
      start = 0;
    } else if (start < 0) {
      start = Math.max(len + start, 0);
    } else {
      start = Math.min(start, len);
    }

    if (end == null) {
      end = len;
    } else if (end < 0) {
      end = Math.max(len + end, 0);
    } else {
      end = Math.min(end, len);
    }

    var ret = [];

    while (start < end) {
      ret.push(arr[start++]);
    }

    return ret;
  }

  return exports;
}();
/* ------------------------------ keys ------------------------------ */

var keys = _.keys = function (exports) {
  /* Create an array of the own enumerable property names of object.
   *
   * |Name  |Type  |Desc                   |
   * |------|------|-----------------------|
   * |obj   |object|Object to query        |
   * |return|array |Array of property names|
   * 
   * ```javascript
   * keys({a: 1}); // -> ['a']
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * has 
   */
  exports = Object.keys || function (obj) {
    var ret = [],
        key;

    for (key in obj) {
      if (has(obj, key)) ret.push(key);
    }

    return ret;
  };

  return exports;
}({});
/* ------------------------------ freeze ------------------------------ */

var freeze = _.freeze = function () {
  /* Shortcut for Object.freeze.
   *
   * Use Object.defineProperties if Object.freeze is not supported.
   * 
   * |Name  |Type  |Desc            |
   * |------|------|----------------|
   * |obj   |object|Object to freeze|
   * |return|object|Object passed in|
   * 
   * ```javascript
   * var a = {b: 1};
   * freeze(a);
   * a.b = 2;
   * console.log(a); // -> {b: 1}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * keys 
   */
  function exports(obj) {
    if (Object.freeze) return Object.freeze(obj);
    keys(obj).forEach(function (prop) {
      if (!Object.getOwnPropertyDescriptor(obj, prop).configurable) return;
      Object.defineProperty(obj, prop, {
        writable: false,
        configurable: false
      });
    });
    return obj;
  }

  return exports;
}();
/* ------------------------------ isUndef ------------------------------ */

var isUndef = _.isUndef = function () {
  /* Check if value is undefined.
   *
   * |Name  |Type   |Desc                      |
   * |------|-------|--------------------------|
   * |val   |*      |Value to check            |
   * |return|boolean|True if value is undefined|
   *
   * ```javascript
   * isUndef(void 0); // -> true
   * isUndef(null); // -> false
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(val) {
    return val === void 0;
  }

  return exports;
}();
/* ------------------------------ allKeys ------------------------------ */

var allKeys = _.allKeys = function () {
  /* Retrieve all the names of object's own and inherited properties.
   *
   * |Name  |Type  |Desc                       |
   * |------|------|---------------------------|
   * |obj   |object|Object to query            |
   * |return|array |Array of all property names|
   *
   * > Members of Object's prototype won't be retrieved.
   *
   * ```javascript
   * var obj = Object.create({zero: 0});
   * obj.one = 1;
   * allKeys(obj) // -> ['zero', 'one']
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(obj) {
    var ret = [],
        key;

    for (key in obj) {
      ret.push(key);
    }

    return ret;
  }

  return exports;
}();
/* ------------------------------ before ------------------------------ */

var before = _.before = function () {
  /* Create a function that invokes less than n times.
   *
   * |Name  |Type    |Desc                                            |
   * |------|--------|------------------------------------------------|
   * |n     |number  |Number of calls at which fn is no longer invoked|
   * |fn    |function|Function to restrict                            |
   * |return|function|New restricted function                         |
   *
   * Subsequent calls to the created function return the result of the last fn invocation.
   *
   * ```javascript
   * $(element).on('click', before(5, function() {}));
   * // -> allow function to be call 4 times at last.
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(n, fn) {
    var memo;
    return function () {
      if (--n > 0) memo = fn.apply(this, arguments);
      if (n <= 1) fn = null;
      return memo;
    };
  }

  return exports;
}();
/* ------------------------------ isObj ------------------------------ */

var isObj = _.isObj = function () {
  /* Check if value is the language type of Object.
   *
   * |Name  |Type   |Desc                      |
   * |------|-------|--------------------------|
   * |val   |*      |Value to check            |
   * |return|boolean|True if value is an object|
   *
   * [Language Spec](http://www.ecma-international.org/ecma-262/6.0/#sec-ecmascript-language-types)
   *
   * ```javascript
   * isObj({}); // -> true
   * isObj([]); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(val) {
    var type = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__["default"])(val);

    return !!val && (type === 'function' || type === 'object');
  }

  return exports;
}();
/* ------------------------------ cloneObject ------------------------------ */

var cloneObject = _.cloneObject = function () {
  function exports(obj) {
    if (obj === null || Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__["default"])(obj) !== 'object') {
      return obj;
    }

    var temp = new obj.constructor();

    for (var key in obj) {
      temp[key] = exports(obj[key]);
    }

    return temp;
  }

  return exports;
}();
/* ------------------------------ colToLabel ------------------------------ */

var colToLabel = _.colToLabel = function () {
  function exports(index) {
    if (!index) return 'A';
    if (index <= 26) return String.fromCharCode(64 + index); // 101 is A's asii value

    var n1 = index / 26,
        n2 = index % 26;
    return String.fromCharCode(64 + n1) + String.fromCharCode(64 + n2);
  }

  return exports;
}();
/* ------------------------------ colorToHex ------------------------------ */

var colorToHex = _.colorToHex = function () {
  var colorReg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;

  function exports(sColor) {
    var that = sColor;

    if (/^(rgb|RGB)/.test(that)) {
      var aColor = that.replace(/(?:\(|\)|rgb|RGB)*/g, '').split(',');
      var strHex = '#';

      for (var i = 0; i < aColor.length; i++) {
        var hex = Number(aColor[i]).toString(16);

        if (hex === '0') {
          hex += hex;
        }

        strHex += hex;
      }

      if (strHex.length !== 7) {
        strHex = that;
      }

      return strHex;
    } else if (colorReg.test(that)) {
      var aNum = that.replace(/#/, '').split('');

      if (aNum.length === 6) {
        return that;
      } else if (aNum.length === 3) {
        var numHex = '#';

        for (i = 0; i < aNum.length; i += 1) {
          numHex += aNum[i] + aNum[i];
        }

        return numHex;
      }
    } else {
      return that;
    }
  }

  return exports;
}();
/* ------------------------------ colorToRgb ------------------------------ */

var colorToRgb = _.colorToRgb = function () {
  var colorReg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;

  function exports(sColor) {
    if (sColor && colorReg.test(sColor)) {
      if (sColor.length === 4) {
        var sColorNew = '#';

        for (var i = 1; i < 4; i += 1) {
          sColorNew += sColor.slice(i, i + 1).concat(sColor.slice(i, i + 1));
        }

        sColor = sColorNew;
      }

      var sColorChange = [];

      for (i = 1; i < 7; i += 2) {
        sColorChange.push(parseInt('0x' + sColor.slice(i, i + 2)));
      }

      return 'RGB(' + sColorChange.join(',') + ')';
    } else {
      return sColor;
    }
  }

  return exports;
}();
/* ------------------------------ idxOf ------------------------------ */

var idxOf = _.idxOf = function () {
  /* Get the index at which the first occurrence of value.
   *
   * |Name     |Type  |Desc                |
   * |---------|------|--------------------|
   * |arr      |array |Array to search     |
   * |val      |*     |Value to search for |
   * |fromIdx=0|number|Index to search from|
   *
   * ```javascript
   * idxOf([1, 2, 1, 2], 2, 2); // -> 3
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(arr, val, fromIdx) {
    return Array.prototype.indexOf.call(arr, val, fromIdx);
  }

  return exports;
}();
/* ------------------------------ coordToPos ------------------------------ */

var coordToPos = _.coordToPos = function () {
  function exports(coord) {
    var c, i, r, ch;
    c = 0;
    r = 0;

    for (i = 0; i < coord.length; i++) {
      ch = coord.charCodeAt(i); // if (ch === 36) {
      // } else if (ch <= 57) {

      if (ch <= 57) {
        r = 10 * r + ch - 48;
      } else if (ch >= 97) {
        c = 26 * c + ch - 96;
      } else if (ch >= 65) {
        c = 26 * c + ch - 64;
      }
    }

    return {
      row: r - 1,
      col: c - 1
    };
  }

  return exports;
}();
/* ------------------------------ noop ------------------------------ */

var noop = _.noop = function () {
  /* A no-operation function.
   *
   * ```javascript
   * noop(); // Does nothing
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports() {}

  return exports;
}();
/* ------------------------------ toStr ------------------------------ */

var toStr = _.toStr = function () {
  /* Convert value to a string.
   *
   * |Name  |Type  |Desc            |
   * |------|------|----------------|
   * |val   |*     |Value to convert|
   * |return|string|Resulted string |
   *
   * ```javascript
   * toStr(null); // -> ''
   * toStr(1); // -> '1'
   * toStr(false); // -> 'false'
   * toStr([1, 2, 3]); // -> '1,2,3'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(val) {
    return val == null ? '' : val.toString();
  }

  return exports;
}();
/* ------------------------------ decodeFromSave ------------------------------ */

var decodeFromSave = _.decodeFromSave = function () {
  function exports(s) {
    if (typeof s !== 'string') return s;
    if (s.indexOf('\\') == -1) return s; // for performace reasons: replace nothing takes up time

    var r = s.replace(/\\c/g, ':');
    r = r.replace(/\\n/g, '\n');
    return r.replace(/\\b/g, '\\');
  }

  return exports;
}();
/* ------------------------------ detectBrowser ------------------------------ */

var detectBrowser = _.detectBrowser = function () {
  function exports(ua) {
    ua = ua || (isBrowser ? navigator.userAgent : '');
    ua = ua.toLowerCase();
    var ieVer = getVer(ua, 'msie ');
    if (ieVer) return {
      version: ieVer,
      name: 'ie'
    };
    if (regIe11.test(ua)) return {
      version: 11,
      name: 'ie'
    };

    for (var i = 0, len = browsers.length; i < len; i++) {
      var name = browsers[i],
          match = ua.match(regBrowsers[name]);
      if (match == null) continue;
      var version = toInt(match[1].split('.')[0]);
      if (name === 'opera') version = getVer(ua, 'version/') || version;
      return {
        name: name,
        version: version
      };
    }

    return {
      name: 'unknown',
      version: -1
    };
  }

  var regBrowsers = {
    'edge': /edge\/([0-9._]+)/,
    'firefox': /firefox\/([0-9.]+)(?:\s|$)/,
    'opera': /opera\/([0-9.]+)(?:\s|$)/,
    'android': /android\s([0-9.]+)/,
    'ios': /version\/([0-9._]+).*mobile.*safari.*/,
    'safari': /version\/([0-9._]+).*safari/,
    'chrome': /(?!chrom.*opr)chrom(?:e|ium)\/([0-9.]+)(:?\s|$)/
  };
  var regIe11 = /trident\/7\./,
      browsers = keys(regBrowsers);

  function getVer(ua, mark) {
    var idx = ua.indexOf(mark);
    if (idx > -1) return toInt(ua.substring(idx + mark.length, ua.indexOf('.', idx)));
  }

  function toInt(val) {
    if (!val) return val === 0 ? val : 0;
    val = toNum(val);
    return val - val % 1;
  }

  return exports;
}();
/* ------------------------------ detectOs ------------------------------ */

var detectOs = _.detectOs = function () {
  function exports(ua) {
    ua = ua || (isBrowser ? navigator.userAgent : '');
    ua = ua.toLowerCase();
    if (detect('windows phone')) return 'windows phone';
    if (detect('win')) return 'windows';
    if (detect('android')) return 'android';
    if (detect('ipad') || detect('iphone') || detect('ipod')) return 'ios';
    if (detect('mac')) return 'os x';
    if (detect('linux')) return 'linux';

    function detect(keyword) {
      return ua.indexOf(keyword) > -1;
    }

    return 'unknown';
  }

  return exports;
}();
/* ------------------------------ restArgs ------------------------------ */

var restArgs = _.restArgs = function () {
  /* This accumulates the arguments passed into an array, after a given index.
   *
   * |Name      |Type    |Desc                                   |
   * |----------|--------|---------------------------------------|
   * |function  |function|Function that needs rest parameters    |
   * |startIndex|number  |The start index to accumulates         |
   * |return    |function|Generated function with rest parameters|
   *
   * ```javascript
   * var paramArr = restArgs(function (rest) { return rest });
   * paramArr(1, 2, 3, 4); // -> [1, 2, 3, 4]
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(fn, startIdx) {
    startIdx = startIdx == null ? fn.length - 1 : +startIdx;
    return function () {
      var len = Math.max(arguments.length - startIdx, 0),
          rest = new Array(len),
          i;

      for (i = 0; i < len; i++) {
        rest[i] = arguments[i + startIdx];
      } // Call runs faster than apply.


      switch (startIdx) {
        case 0:
          return fn.call(this, rest);

        case 1:
          return fn.call(this, arguments[0], rest);

        case 2:
          return fn.call(this, arguments[0], arguments[1], rest);
      }

      var args = new Array(startIdx + 1);

      for (i = 0; i < startIdx; i++) {
        args[i] = arguments[i];
      }

      args[startIdx] = rest;
      return fn.apply(this, args);
    };
  }

  return exports;
}();
/* ------------------------------ downloadImage ------------------------------ */

var downloadImage = _.downloadImage = function () {
  function exports(url) {
    return new Promise(function (resolve, reject) {
      var img = document.createElement('img');
      img.src = url;
      img.addEventListener('load', function () {
        resolve(img);
      });
      img.addEventListener('error', function () {
        reject(new Error('load image failed'));
      });
    });
  }

  return exports;
}();
/* ------------------------------ optimizeCb ------------------------------ */

var optimizeCb = _.optimizeCb = function () {
  /* Used for function context binding.
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isUndef 
   */
  function exports(fn, ctx, argCount) {
    if (isUndef(ctx)) return fn;

    switch (argCount == null ? 3 : argCount) {
      case 1:
        return function (val) {
          return fn.call(ctx, val);
        };

      case 3:
        return function (val, idx, collection) {
          return fn.call(ctx, val, idx, collection);
        };

      case 4:
        return function (accumulator, val, idx, collection) {
          return fn.call(ctx, accumulator, val, idx, collection);
        };
    }

    return function () {
      return fn.apply(ctx, arguments);
    };
  }

  return exports;
}();
/* ------------------------------ getBorder ------------------------------ */

var getBorder = _.getBorder = function () {
  /* globals GC */
  function exports(border) {
    border = border.split(/\s+/);
    border.shift();
    border.shift();
    var color = border.join(' ');
    var Sheets = GC.Spread.Sheets;
    var lineStyle = Sheets.LineStyle.thin;
    return new Sheets.LineBorder(color, lineStyle);
  }

  return exports;
}();
/* ------------------------------ getColData ------------------------------ */

var getColData = _.getColData = function () {
  function exports(data, col) {
    var values = [];

    for (var i = 0, l = Object.keys(data).length; i < l; i++) {
      if (data[i] && data[i][col]) {
        values.push(data[i][col]);
      }
    }

    return values;
  }

  return exports;
}();
/* ------------------------------ getColorHash ------------------------------ */

var getColorHash = _.getColorHash = function () {
  /* dependencies
   * ColorHash 
   */
  var colorHash = null;

  function exports(vid) {
    if (!colorHash) {
      colorHash = new ColorHash({
        lightness: [0.4, 0.45, 0.5, 0.55],
        saturation: [0.6, 0.65, 0.7]
      });
    }

    return colorHash.hex(vid);
  }

  return exports;
}();
/* ------------------------------ getMergeCellList ------------------------------ */

var getMergeCellList = _.getMergeCellList = function () {
  function exports(selection, newSpan) {
    var spans = [];
    each(newSpan || [], function (span) {
      var row = selection.row,
          col = selection.col,
          rowCount = selection.rowCount,
          colCount = selection.colCount,
          rowEnd = row + rowCount - 1,
          colEnd = col + colCount - 1;

      if (span.row >= row && span.row <= rowEnd && span.col >= col && span.col <= colEnd) {
        spans.push(span);
      }
    });
    return spans;
  }

  return exports;
}();
/* ------------------------------ getMouseXY ------------------------------ */

var getMouseXY = _.getMouseXY = function () {
  function exports(e) {
    var x = 0,
        y = 0;
    e = e || window.event;

    if (e.pageX) {
      x = e.pageX;
      y = e.pageY;
    } else {
      x = e.clientX + document.body.scrollLeft - document.body.clientLeft;
      y = e.clientY + document.body.scrollTop - document.body.clientTop;
    }

    return {
      x: x,
      y: y
    };
  }

  return exports;
}();
/* ------------------------------ identity ------------------------------ */

var identity = _.identity = function () {
  /* Return the first argument given.
   *
   * |Name  |Type|Desc       |
   * |------|----|-----------|
   * |val   |*   |Any value  |
   * |return|*   |Given value|
   *
   * ```javascript
   * identity('a'); // -> 'a'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(val) {
    return val;
  }

  return exports;
}();
/* ------------------------------ objToStr ------------------------------ */

var objToStr = _.objToStr = function () {
  /* Alias of Object.prototype.toString.
   *
   * |Name  |Type  |Desc                                |
   * |------|------|------------------------------------|
   * |value |*     |Source value                        |
   * |return|string|String representation of given value|
   * 
   * ```javascript
   * objToStr(5); // -> '[object Number]'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  var ObjToStr = Object.prototype.toString;

  function exports(val) {
    return ObjToStr.call(val);
  }

  return exports;
}();
/* ------------------------------ isArr ------------------------------ */

var isArr = _.isArr = function (exports) {
  /* Check if value is an `Array` object.
   *
   * |Name  |Type   |Desc                              |
   * |------|-------|----------------------------------|
   * |val   |*      |Value to check                    |
   * |return|boolean|True if value is an `Array` object|
   *
   * ```javascript
   * isArr([]); // -> true
   * isArr({}); // -> false
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  exports = Array.isArray || function (val) {
    return objToStr(val) === '[object Array]';
  };

  return exports;
}({});
/* ------------------------------ castPath ------------------------------ */

var castPath = _.castPath = function () {
  /* Cast value into a property path array.
   *
   * |Name  |Type  |Desc               |
   * |------|------|-------------------|
   * |str   |*     |Value to inspect   |
   * |[obj] |object|Object to query    |
   * |return|array |Property path array|
   * 
   * ```javascript
   * castPath('a.b.c'); // -> ['a', 'b', 'c']
   * castPath(['a']); // -> ['a']
   * castPath('a[0].b'); // -> ['a', '0', 'b']
   * castPath('a.b.c', {'a.b.c': true}); // -> ['a.b.c']
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * has isArr 
   */
  function exports(str, obj) {
    if (isArr(str)) return str;
    if (obj && has(obj, str)) return [str];
    var ret = [];
    str.replace(regPropName, function (match, number, quote, str) {
      ret.push(quote ? str.replace(regEscapeChar, '$1') : number || match);
    });
    return ret;
  } // Lodash _stringToPath


  var regPropName = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g,
      regEscapeChar = /\\(\\)?/g;
  return exports;
}();
/* ------------------------------ safeGet ------------------------------ */

var safeGet = _.safeGet = function () {
  /* Get object property, don't throw undefined error.
   *
   * |Name  |Type        |Desc                     |
   * |------|------------|-------------------------|
   * |obj   |object      |Object to query          |
   * |path  |array string|Path of property to get  |
   * |return|*           |Target value or undefined|
   *
   * ```javascript
   * var obj = {a: {aa: {aaa: 1}}};
   * safeGet(obj, 'a.aa.aaa'); // -> 1
   * safeGet(obj, ['a', 'aa']); // -> {aaa: 1}
   * safeGet(obj, 'a.b'); // -> undefined
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isUndef castPath 
   */
  function exports(obj, path) {
    path = castPath(path, obj);
    var prop;
    prop = path.shift();

    while (!isUndef(prop)) {
      obj = obj && obj[prop];
      if (isUndef(obj)) return;
      prop = path.shift();
    }

    return obj;
  }

  return exports;
}();
/* ------------------------------ flatten ------------------------------ */

var flatten = _.flatten = function () {
  /* Recursively flatten an array.
   *
   * |Name  |Type |Desc               |
   * |------|-----|-------------------|
   * |arr   |array|Array to flatten   |
   * |return|array|New flattened array|
   *
   * ```javascript
   * flatten(['a', ['b', ['c']], 'd', ['e']]); // -> ['a', 'b', 'c', 'd', 'e']
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isArr 
   */
  function exports(arr) {
    return flat(arr, []);
  }

  function flat(arr, res) {
    var len = arr.length,
        i = -1,
        cur;

    while (len--) {
      cur = arr[++i];
      isArr(cur) ? flat(cur, res) : res.push(cur);
    }

    return res;
  }

  return exports;
}();
/* ------------------------------ isBlob ------------------------------ */

var isBlob = _.isBlob = function () {
  /* Check if value is a Blob.
   *
   * |Name  |Type   |Desc                   |
   * |------|-------|-----------------------|
   * |val   |*      |Value to check         |
   * |return|boolean|True if value is a Blob|
   * 
   * ```javascript
   * isBlob(new Blob([])); // -> true;
   * isBlob([]); // -> false
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object Blob]';
  }

  return exports;
}();
/* ------------------------------ isDate ------------------------------ */

var isDate = _.isDate = function () {
  /* Check if value is classified as a Date object.
   *
   * |Name  |Type   |Desc                          |
   * |------|-------|------------------------------|
   * |val   |*      |value to check                |
   * |return|boolean|True if value is a Date object|
   *
   * ```javascript
   * isDate(new Date()); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object Date]';
  }

  return exports;
}();
/* ------------------------------ isFile ------------------------------ */

var isFile = _.isFile = function () {
  /* Check if value is a file.
   *
   * |Name  |Type   |Desc                   |
   * |------|-------|-----------------------|
   * |val   |*      |Value to check         |
   * |return|boolean|True if value is a file|
   * 
   * ```javascript
   * isFile(new File(['test'], "test.txt", {type: "text/plain"})); // -> true
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object File]';
  }

  return exports;
}();
/* ------------------------------ isFn ------------------------------ */

var isFn = _.isFn = function () {
  /* Check if value is a function.
   *
   * |Name  |Type   |Desc                       |
   * |------|-------|---------------------------|
   * |val   |*      |Value to check             |
   * |return|boolean|True if value is a function|
   *
   * Generator function is also classified as true.
   *
   * ```javascript
   * isFn(function() {}); // -> true
   * isFn(function*() {}); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    var objStr = objToStr(val);
    return objStr === '[object Function]' || objStr === '[object GeneratorFunction]';
  }

  return exports;
}();
/* ------------------------------ isMiniProgram ------------------------------ */

var isMiniProgram = _.isMiniProgram = function (exports) {
  /* Check if running in wechat mini program.
   *
   * ```javascript
   * console.log(isMiniProgram); // -> true if running in mini program.
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isFn 
   */

  /* eslint-disable no-undef */
  exports = typeof wx !== 'undefined' && isFn(wx.openLocation);
  return exports;
}({});
/* ------------------------------ isNum ------------------------------ */

var isNum = _.isNum = function () {
  /* Check if value is classified as a Number primitive or object.
   *
   * |Name  |Type   |Desc                                 |
   * |------|-------|-------------------------------------|
   * |val   |*      |Value to check                       |
   * |return|boolean|True if value is correctly classified|
   * 
   * ```javascript
   * isNum(5); // -> true
   * isNum(5.1); // -> true
   * isNum({}); // -> false
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object Number]';
  }

  return exports;
}();
/* ------------------------------ isArrLike ------------------------------ */

var isArrLike = _.isArrLike = function () {
  /* Check if value is array-like.
   *
   * |Name  |Type   |Desc                       |
   * |------|-------|---------------------------|
   * |val   |*      |Value to check             |
   * |return|boolean|True if value is array like|
   *
   * > Function returns false.
   *
   * ```javascript
   * isArrLike('test'); // -> true
   * isArrLike(document.body.children); // -> true;
   * isArrLike([1, 2, 3]); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isNum isFn 
   */
  var MAX_ARR_IDX = Math.pow(2, 53) - 1;

  function exports(val) {
    if (!val) return false;
    var len = val.length;
    return isNum(len) && len >= 0 && len <= MAX_ARR_IDX && !isFn(val);
  }

  return exports;
}();
/* ------------------------------ each ------------------------------ */

var each = _.each = function () {
  /* Iterate over elements of collection and invokes iteratee for each element.
   *
   * |Name    |Type        |Desc                          |
   * |--------|------------|------------------------------|
   * |obj     |object array|Collection to iterate over    |
   * |iteratee|function    |Function invoked per iteration|
   * |[ctx]   |*           |Function context              |
   *
   * ```javascript
   * each({'a': 1, 'b': 2}, function (val, key) {});
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isArrLike keys optimizeCb 
   */
  function exports(obj, iteratee, ctx) {
    iteratee = optimizeCb(iteratee, ctx);
    var i, len;

    if (isArrLike(obj)) {
      for (i = 0, len = obj.length; i < len; i++) {
        iteratee(obj[i], i, obj);
      }
    } else {
      var _keys = keys(obj);

      for (i = 0, len = _keys.length; i < len; i++) {
        iteratee(obj[_keys[i]], _keys[i], obj);
      }
    }

    return obj;
  }

  return exports;
}();
/* ------------------------------ cloneDeep ------------------------------ */

var cloneDeep = _.cloneDeep = function () {
  /* Recursively clone value.
   *
   * |Name  |Type|Desc             |
   * |------|----|-----------------|
   * |val   |*   |Value to clone   |
   * |return|*   |Deep cloned Value|
   *
   * ```javascript
   * var obj = [{a: 1}, {a: 2}];
   * var obj2 = cloneDeep(obj);
   * console.log(obj[0] === obj2[1]); // -> false
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * keys isObj isFn isArr each 
   */
  function mapObject(obj, iteratee) {
    var newObj = {};
    each(obj, function (val, key) {
      var pair = iteratee(key, val);
      newObj[pair[0]] = pair[1];
    });
    return newObj;
  }

  function exports(obj) {
    if (isArr(obj)) {
      return obj.map(function (val) {
        return cloneDeep(val);
      });
    }

    if (isObj(obj) && !isFn(obj)) {
      return mapObject(obj, function (key, val) {
        return [key, cloneDeep(val)];
      });
    }

    return obj;
  }

  return exports;
}();
/* ------------------------------ createAssigner ------------------------------ */

var createAssigner = _.createAssigner = function () {
  /* Used to create extend, extendOwn and defaults.
   *
   * |Name    |Type    |Desc                          |
   * |--------|--------|------------------------------|
   * |keysFn  |function|Function to get object keys   |
   * |defaults|boolean |No override when set to true  |
   * |return  |function|Result function, extend...    |
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isUndef each 
   */
  function exports(keysFn, defaults) {
    return function (obj) {
      each(arguments, function (src, idx) {
        if (idx === 0) return;
        var keys = keysFn(src);
        each(keys, function (key) {
          if (!defaults || isUndef(obj[key])) obj[key] = src[key];
        });
      });
      return obj;
    };
  }

  return exports;
}();
/* ------------------------------ defaults ------------------------------ */

var defaults = _.defaults = function (exports) {
  /* Fill in undefined properties in object with the first value present in the following list of defaults objects.
   *
   * |Name  |Type  |Desc              |
   * |------|------|------------------|
   * |obj   |object|Destination object|
   * |*src  |object|Sources objects   |
   * |return|object|Destination object|
   *
   * ```javascript
   * defaults({name: 'RedHood'}, {name: 'Unknown', age: 24}); // -> {name: 'RedHood', age: 24}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * createAssigner allKeys 
   */
  exports = createAssigner(allKeys, true);
  return exports;
}({});
/* ------------------------------ extend ------------------------------ */

var extend = _.extend = function (exports) {
  /* Copy all of the properties in the source objects over to the destination object.
   *
   * |Name  |Type  |Desc              |
   * |------|------|------------------|
   * |obj   |object|Destination object|
   * |...src|object|Sources objects   |
   * |return|object|Destination object|
   *
   * ```javascript
   * extend({name: 'RedHood'}, {age: 24}); // -> {name: 'RedHood', age: 24}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * createAssigner allKeys 
   */
  exports = createAssigner(allKeys);
  return exports;
}({});
/* ------------------------------ clone ------------------------------ */

var clone = _.clone = function () {
  /* Create a shallow-copied clone of the provided plain object.
   *
   * Any nested objects or arrays will be copied by reference, not duplicated.
   *
   * |Name  |Type|Desc          |
   * |------|----|--------------|
   * |val   |*   |Value to clone|
   * |return|*   |Cloned value  |
   *
   * ```javascript
   * clone({name: 'eustia'}); // -> {name: 'eustia'}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isObj isArr extend 
   */
  function exports(obj) {
    if (!isObj(obj)) return obj;
    return isArr(obj) ? obj.slice() : extend({}, obj);
  }

  return exports;
}();
/* ------------------------------ copy ------------------------------ */

var copy = _.copy = function () {
  /* Copy text to clipboard using document.execCommand.
   *
   * |Name|Type    |Desc             |
   * |----|--------|-----------------|
   * |text|string  |Text to copy     |
   * |[cb]|function|Optional callback|
   * 
   * ```javascript
   * copy('text', function (err) 
   * {
   *     // Handle errors.
   * });
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * extend noop 
   */
  function exports(text, cb) {
    cb = cb || noop;
    var el = document.createElement('textarea'),
        body = document.body;
    extend(el.style, {
      fontSize: '12pt',
      border: '0',
      padding: '0',
      margin: '0',
      position: 'absolute',
      left: '-9999px'
    });
    el.value = text;
    body.appendChild(el); // Prevent showing ios keyboard.

    el.setAttribute('readonly', '');
    el.select();
    el.setSelectionRange(0, text.length);

    try {
      document.execCommand('copy');
      cb();
    } catch (e) {
      cb(e);
    } finally {
      body.removeChild(el);
    }
  }

  return exports;
}();
/* ------------------------------ extendOwn ------------------------------ */

var extendOwn = _.extendOwn = function (exports) {
  /* Like extend, but only copies own properties over to the destination object.
   *
   * |Name  |Type  |Desc              |
   * |------|------|------------------|
   * |obj   |object|Destination object|
   * |*src  |object|Sources objects   |
   * |return|object|Destination object|
   *
   * ```javascript
   * extendOwn({name: 'RedHood'}, {age: 24}); // -> {name: 'RedHood', age: 24}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * keys createAssigner 
   */
  exports = createAssigner(keys);
  return exports;
}({});
/* ------------------------------ invert ------------------------------ */

var invert = _.invert = function () {
  /* Create an object composed of the inverted keys and values of object.
   *
   * |Name  |Type  |Desc               |
   * |------|------|-------------------|
   * |obj   |object|Object to invert   |
   * |return|object|New inverted object|
   *
   * If object contains duplicate values, subsequent values overwrite property
   * assignments of previous values unless multiValue is true.
   *
   * ```javascript
   * invert({a: 'b', c: 'd', e: 'f'}); // -> {b: 'a', d: 'c', f: 'e'}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * keys each 
   */
  function exports(obj) {
    var ret = {};
    each(obj, function (val, key) {
      ret[val] = key;
    });
    return ret;
  }

  return exports;
}();
/* ------------------------------ values ------------------------------ */

var values = _.values = function () {
  /* Create an array of the own enumerable property values of object.
   *
   * |Name  |Type  |Desc                    |
   * |------|------|------------------------|
   * |obj   |object|Object to query         |
   * |return|array |Array of property values|
   *
   * ```javascript
   * values({one: 1, two: 2}); // -> [1, 2]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * each 
   */
  function exports(obj) {
    var ret = [];
    each(obj, function (val) {
      ret.push(val);
    });
    return ret;
  }

  return exports;
}();
/* ------------------------------ contain ------------------------------ */

var contain = _.contain = function () {
  /* Check if the value is present in the list.
   *
   * |Name  |Type        |Desc                                |
   * |------|------------|------------------------------------|
   * |array |array object|Target list                         |
   * |value |*           |Value to check                      |
   * |return|boolean     |True if value is present in the list|
   *
   * ```javascript
   * contain([1, 2, 3], 1); // -> true
   * contain({a: 1, b: 2}, 1); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * idxOf isArrLike values 
   */
  function exports(arr, val) {
    if (!isArrLike(arr)) arr = values(arr);
    return idxOf(arr, val) >= 0;
  }

  return exports;
}();
/* ------------------------------ isStr ------------------------------ */

var isStr = _.isStr = function () {
  /* Check if value is a string primitive.
   *
   * |Name  |Type   |Desc                               |
   * |------|-------|-----------------------------------|
   * |val   |*      |Value to check                     |
   * |return|boolean|True if value is a string primitive|
   *
   * ```javascript
   * isStr('licia'); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object String]';
  }

  return exports;
}();
/* ------------------------------ getFontSize ------------------------------ */

var getFontSize = _.getFontSize = function () {
  /* dependencies
   * isStr invert 
   */
  function exports(size) {
    if (isStr(size)) return fontMap[size] || 12;
    return invertMap[size] || '9';
  }

  var fontMap = {
    9: 12,
    10.5: 14,
    13.5: 18,
    18: 24,
    22.5: 30,
    27: 36
  };
  var invertMap = invert(fontMap);
  return exports;
}();
/* ------------------------------ getHAlign ------------------------------ */

var getHAlign = _.getHAlign = function () {
  /* dependencies
   * isStr 
   */
  function exports(val) {
    if (isStr(val)) {
      switch (val) {
        case 'left':
        case 'center':
        case 'right':
          return HorizontalAlign[val];
      }

      return HorizontalAlign.general;
    } else {
      switch (val) {
        case HorizontalAlign.left:
          return 'left';

        case HorizontalAlign.center:
          return 'center';

        case HorizontalAlign.right:
          return 'right';
      }

      return '';
    }
  }

  var HorizontalAlign = GC.Spread.Sheets.HorizontalAlign;
  return exports;
}();
/* ------------------------------ getVAlign ------------------------------ */

var getVAlign = _.getVAlign = function () {
  /* dependencies
   * isStr 
   */
  function exports(val) {
    if (isStr(val)) {
      switch (val) {
        case 'top':
        case 'bottom':
          return VerticalAlign[val];

        case 'middle':
          return VerticalAlign.center;
      }

      return VerticalAlign.general;
    } else {
      switch (val) {
        case VerticalAlign.top:
          return 'top';

        case VerticalAlign.center:
          return 'middle';

        case VerticalAlign.bottom:
          return 'bottom';
      }

      return '';
    }
  }

  var VerticalAlign = GC.Spread.Sheets.VerticalAlign;
  return exports;
}();
/* ------------------------------ isBrowser ------------------------------ */

var isBrowser = _.isBrowser = function (exports) {
  /* Check if running in a browser.
   *
   * ```javascript
   * console.log(isBrowser); // -> true if running in a browser
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  exports = (typeof window === "undefined" ? "undefined" : Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__["default"])(window)) === 'object' && (typeof document === "undefined" ? "undefined" : Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__["default"])(document)) === 'object' && document.nodeType === 9;
  return exports;
}({});
/* ------------------------------ root ------------------------------ */

var root = _.root = function (exports) {
  /* Root object reference, `global` in nodeJs, `window` in browser. */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isBrowser 
   */
  exports = isBrowser ? window : global;
  return exports;
}({});
/* ------------------------------ Blob ------------------------------ */

var Blob = _.Blob = function (exports) {
  /* Use Blob when available, otherwise BlobBuilder.
   * 
   * ### constructor
   * 
   * |Name  |Type  |Desc      |
   * |------|------|----------|
   * |parts |array |Blob parts|
   * |[opts]|object|Options   |
   * 
   * ```javascript
   * var blob = new Blob([]);
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * root each 
   */
  exports = root.Blob || function Blob(parts, opts) {
    opts = opts || {};
    var blobBuilder = new BlobBuilder();
    each(parts, function (part) {
      blobBuilder.append(part);
    });
    return opts.type ? blobBuilder.getBlob(opts.type) : blobBuilder.getBlob();
  };

  var BlobBuilder = root.BlobBuilder || root.WebKitBlobBuilder || root.MSBlobBuilder || root.MozBlobBuilder;
  return exports;
}({});
/* ------------------------------ isFormula ------------------------------ */

var isFormula = _.isFormula = function () {
  function exports(value) {
    return /^=([\s\S]+)/.test(value);
  }

  return exports;
}();
/* ------------------------------ splitPath ------------------------------ */

var splitPath = _.splitPath = function () {
  /* Split path into device, dir, name and ext.
   *
   * |Name  |Type  |Desc                               |
   * |------|------|-----------------------------------|
   * |path  |string|Path to split                      |
   * |return|object|Object containing dir, name and ext|
   * 
   * ```javascript
   * splitPath('f:/foo/bar.txt'); // -> {dir: 'f:/foo/', name: 'bar.txt', ext: '.txt'}
   * splitPath('/home/foo/bar.txt'); // -> {dir: '/home/foo/', name: 'bar.txt', ext: '.txt'} 
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(path) {
    var match = path.match(regSplit);
    return {
      dir: match[1],
      name: match[2],
      ext: match[3]
    };
  }

  var regSplit = /^([\s\S]*?)((?:\.{1,2}|[^\\/]+?|)(\.[^./\\]*|))(?:[\\/]*)$/;
  return exports;
}();
/* ------------------------------ isImage ------------------------------ */

var isImage = _.isImage = function () {
  /* dependencies
   * splitPath contain 
   */
  function exports(src) {
    return contain(['.png', '.gif', '.jpg', '.jpeg'], splitPath(src).ext);
  }

  return exports;
}();
/* ------------------------------ isMatch ------------------------------ */

var isMatch = _.isMatch = function () {
  /* Check if keys and values in src are contained in obj.
   *
   * |Name  |Type   |Desc                              |
   * |------|-------|----------------------------------|
   * |obj   |object |Object to inspect                 |
   * |src   |object |Object of property values to match|
   * |return|boolean|True if object is match           |
   *
   * ```javascript
   * isMatch({a: 1, b: 2}, {a: 1}); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * keys 
   */
  function exports(obj, src) {
    var _keys = keys(src),
        len = _keys.length;

    if (obj == null) return !len;
    obj = Object(obj);

    for (var i = 0; i < len; i++) {
      var key = _keys[i];
      if (src[key] !== obj[key] || !(key in obj)) return false;
    }

    return true;
  }

  return exports;
}();
/* ------------------------------ isNaN ------------------------------ */

var isNaN = _.isNaN = function () {
  /* Check if value is an NaN.
   *
   * |Name  |Type   |Desc                   |
   * |------|-------|-----------------------|
   * |val   |*      |Value to check         |
   * |return|boolean|True if value is an NaN|
   *
   * Undefined is not an NaN, different from global isNaN function.
   *
   * ```javascript
   * isNaN(0); // -> false
   * isNaN(NaN); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isNum 
   */
  function exports(val) {
    return isNum(val) && val !== +val;
  }

  return exports;
}();
/* ------------------------------ isNode ------------------------------ */

var isNode = _.isNode = function (exports) {
  /* Check if running in node.
   *
   * ```javascript
   * console.log(isNode); // -> true if running in node
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  exports = typeof process !== 'undefined' && objToStr(process) === '[object process]';
  return exports;
}({});
/* ------------------------------ isRegExp ------------------------------ */

var isRegExp = _.isRegExp = function () {
  /* Check if value is a regular expression.
   *
   * |Name  |Type   |Desc                                 |
   * |------|-------|-------------------------------------|
   * |val   |*      |Value to check                       |
   * |return|boolean|True if value is a regular expression|
   *
   * ```javascript
   * isRegExp(/a/); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr 
   */
  function exports(val) {
    return objToStr(val) === '[object RegExp]';
  }

  return exports;
}();
/* ------------------------------ iterateSelection ------------------------------ */

var iterateSelection = _.iterateSelection = function () {
  function exports(selection, iteratee) {
    var row = selection.row,
        col = selection.col,
        rowCount = selection.rowCount,
        colCount = selection.colCount;

    for (var i = row, rowEnd = row + rowCount; i < rowEnd; i++) {
      for (var j = col, colEnd = col + colCount; j < colEnd; j++) {
        iteratee(i, j);
      }
    }
  }

  return exports;
}();
/* ------------------------------ keyCode ------------------------------ */

var keyCode = _.keyCode = function () {
  /* Key codes and key names conversion.
   *
   * Get key code's name.
   *
   * |Name  |Type  |Desc                  |
   * |------|------|----------------------|
   * |code  |number|Key code              |
   * |return|string|Corresponding key name|
   *
   * Get key name's code.
   *
   * |Name  |Type  |Desc                  |
   * |------|------|----------------------|
   * |name  |string|Key name              |
   * |return|number|Corresponding key code|
   *
   * ```javascript
   * keyCode(13); // -> 'enter'
   * keyCode('enter'); // -> 13
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isStr invert 
   */
  function exports(val) {
    if (isStr(val)) return codeMap[val];
    return nameMap[val];
  }

  var codeMap = {
    'backspace': 8,
    'tab': 9,
    'enter': 13,
    'shift': 16,
    'ctrl': 17,
    'alt': 18,
    'pause/break': 19,
    'caps lock': 20,
    'esc': 27,
    'space': 32,
    'page up': 33,
    'page down': 34,
    'end': 35,
    'home': 36,
    'left': 37,
    'up': 38,
    'right': 39,
    'down': 40,
    'insert': 45,
    'delete': 46,
    'windows': 91,
    'right windows': 92,
    'windows menu': 93,
    'numpad *': 106,
    'numpad +': 107,
    'numpad -': 109,
    'numpad .': 110,
    'numpad /': 111,
    'num lock': 144,
    'scroll lock': 145,
    ';': 186,
    '=': 187,
    ',': 188,
    '-': 189,
    '.': 190,
    '/': 191,
    '`': 192,
    '[': 219,
    '\\': 220,
    ']': 221,
    '\'': 222
  }; // Lower case chars

  for (var i = 97; i < 123; i++) {
    codeMap[String.fromCharCode(i)] = i - 32;
  } // Numbers


  for (i = 48; i < 58; i++) {
    codeMap[i - 48] = i;
  } // Function keys


  for (i = 1; i < 13; i++) {
    codeMap['f' + i] = i + 111;
  } // Numpad keys


  for (i = 0; i < 10; i++) {
    codeMap['numpad ' + i] = i + 96;
  }

  var nameMap = invert(codeMap);
  return exports;
}();
/* ------------------------------ labelToCol ------------------------------ */

var labelToCol = _.labelToCol = function () {
  var COLUMN_LABEL_BASE = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  var COLUMN_LABEL_BASE_LENGTH = COLUMN_LABEL_BASE.length;

  function exports(label) {
    var result = 0;

    if (label) {
      for (var i = 0, j = label.length - 1; i < label.length; i += 1, j -= 1) {
        result += Math.pow(COLUMN_LABEL_BASE_LENGTH, j) * (COLUMN_LABEL_BASE.indexOf(label[i]) + 1);
      }
    }

    --result;
    return result;
  }

  return exports;
}();
/* ------------------------------ last ------------------------------ */

var last = _.last = function () {
  /* Get the last element of array.
   *
   * |Name  |Type |Desc                     |
   * |------|-----|-------------------------|
   * |arr   |array|The array to query       |
   * |return|*    |The last element of array|
   *
   * ```javascript
   * last([1, 2]); // -> 2
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(arr) {
    var len = arr ? arr.length : 0;
    if (len) return arr[len - 1];
  }

  return exports;
}();
/* ------------------------------ repeat ------------------------------ */

var repeat = _.repeat = function (exports) {
  /* Repeat string n-times.
   *
   * |Name  |Type  |Desc            |
   * |------|------|----------------|
   * |str   |string|String to repeat|
   * |n     |number|Repeat times    |
   * |return|string|Repeated string |
   *
   * ```javascript
   * repeat('a', 3); // -> 'aaa'
   * repeat('ab', 2); // -> 'abab'
   * repeat('*', 0); // -> ''
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  exports = function exports(str, n) {
    var ret = '';
    if (n < 1) return '';

    while (n > 0) {
      if (n & 1) ret += str;
      n >>= 1;
      str += str;
    }

    return ret;
  };

  return exports;
}({});
/* ------------------------------ lpad ------------------------------ */

var lpad = _.lpad = function () {
  /* Pad string on the left side if it's shorter than length.
   *
   * |Name   |Type  |Desc                  |
   * |-------|------|----------------------|
   * |str    |string|String to pad         |
   * |len    |number|Padding length        |
   * |[chars]|string|String used as padding|
   * |return |string|Resulted string       |
   *
   * ```javascript
   * lpad('a', 5); // -> '    a'
   * lpad('a', 5, '-'); // -> '----a'
   * lpad('abc', 3, '-'); // -> 'abc'
   * lpad('abc', 5, 'ab'); // -> 'ababc'
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * repeat toStr 
   */
  function exports(str, len, chars) {
    str = toStr(str);
    var strLen = str.length;
    chars = chars || ' ';
    if (strLen < len) str = (repeat(chars, len - strLen) + str).slice(-len);
    return str;
  }

  return exports;
}();
/* ------------------------------ dateFormat ------------------------------ */

var dateFormat = _.dateFormat = function () {
  /* Simple but extremely useful date format function.
   *
   * |Name           |Type   |Desc                 |
   * |---------------|-------|---------------------|
   * |[date=new Date]|Date   |Date object to format|
   * |mask           |string |Format mask          |
   * |[utc=false]    |boolean|UTC or not           |
   * |[gmt=false]    |boolean|GMT or not           |
   *
   * |Mask|Description                                                      |
   * |----|-----------------------------------------------------------------|
   * |d   |Day of the month as digits; no leading zero for single-digit days|
   * |dd  |Day of the month as digits; leading zero for single-digit days   |
   * |ddd |Day of the week as a three-letter abbreviation                   |
   * |dddd|Day of the week as its full name                                 |
   * |m   |Month as digits; no leading zero for single-digit months         |
   * |mm  |Month as digits; leading zero for single-digit months            |
   * |mmm |Month as a three-letter abbreviation                             |
   * |mmmm|Month as its full name                                           |
   * |yy  |Year as last two digits; leading zero for years less than 10     |
   * |yyyy|Year represented by four digits                                  |
   * |h   |Hours; no leading zero for single-digit hours (12-hour clock)    |
   * |hh  |Hours; leading zero for single-digit hours (12-hour clock)       |
   * |H   |Hours; no leading zero for single-digit hours (24-hour clock)    |
   * |HH  |Hours; leading zero for single-digit hours (24-hour clock)       |
   * |M   |Minutes; no leading zero for single-digit minutes                |
   * |MM  |Minutes; leading zero for single-digit minutes                   |
   * |s   |Seconds; no leading zero for single-digit seconds                |
   * |ss  |Seconds; leading zero for single-digit seconds                   |
   * |l L |Milliseconds. l gives 3 digits. L gives 2 digits                 |
   * |t   |Lowercase, single-character time marker string: a or p           |
   * |tt  |Lowercase, two-character time marker string: am or pm            |
   * |T   |Uppercase, single-character time marker string: A or P           |
   * |TT  |Uppercase, two-character time marker string: AM or PM            |
   * |Z   |US timezone abbreviation, e.g. EST or MDT                        |
   * |o   |GMT/UTC timezone offset, e.g. -0500 or +0230                     |
   * |S   |The date's ordinal suffix (st, nd, rd, or th)                    |
   * |UTC:|Must be the first four characters of the mask                    |
   *
   * ```javascript
   * dateFormat('isoDate'); // -> 2016-11-19
   * dateFormat('yyyy-mm-dd HH:MM:ss'); // -> 2016-11-19 19:00:04
   * dateFormat(new Date(), 'yyyy-mm-dd'); // -> 2016-11-19
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isStr isDate toStr lpad 
   */
  function exports(date, mask, utc, gmt) {
    if (arguments.length === 1 && isStr(date) && !regNum.test(date)) {
      mask = date;
      date = undefined;
    }

    date = date || new Date();
    if (!isDate(date)) date = new Date(date);
    mask = toStr(exports.masks[mask] || mask || exports.masks['default']);
    var maskSlice = mask.slice(0, 4);

    if (maskSlice === 'UTC:' || maskSlice === 'GMT:') {
      mask = mask.slice(4);
      utc = true;
      if (maskSlice === 'GMT:') gmt = true;
    }

    var prefix = utc ? 'getUTC' : 'get',
        d = date[prefix + 'Date'](),
        D = date[prefix + 'Day'](),
        m = date[prefix + 'Month'](),
        y = date[prefix + 'FullYear'](),
        H = date[prefix + 'Hours'](),
        M = date[prefix + 'Minutes'](),
        s = date[prefix + 'Seconds'](),
        L = date[prefix + 'Milliseconds'](),
        o = utc ? 0 : date.getTimezoneOffset(),
        flags = {
      d: d,
      dd: padZero(d),
      ddd: exports.i18n.dayNames[D],
      dddd: exports.i18n.dayNames[D + 7],
      m: m + 1,
      mm: padZero(m + 1),
      mmm: exports.i18n.monthNames[m],
      mmmm: exports.i18n.monthNames[m + 12],
      yy: toStr(y).slice(2),
      yyyy: y,
      h: H % 12 || 12,
      hh: padZero(H % 12 || 12),
      H: H,
      HH: padZero(H),
      M: M,
      MM: padZero(M),
      s: s,
      ss: padZero(s),
      l: padZero(L, 3),
      L: padZero(Math.round(L / 10)),
      t: H < 12 ? 'a' : 'p',
      tt: H < 12 ? 'am' : 'pm',
      T: H < 12 ? 'A' : 'P',
      TT: H < 12 ? 'AM' : 'PM',
      Z: gmt ? 'GMT' : utc ? 'UTC' : (toStr(date).match(regTimezone) || ['']).pop().replace(regTimezoneClip, ''),
      o: (o > 0 ? '-' : '+') + padZero(Math.floor(Math.abs(o) / 60) * 100 + Math.abs(o) % 60, 4),
      S: ['th', 'st', 'nd', 'rd'][d % 10 > 3 ? 0 : (d % 100 - d % 10 != 10) * d % 10]
    };
    return mask.replace(regToken, function (match) {
      if (match in flags) return flags[match];
      return match.slice(1, match.length - 1);
    });
  }

  function padZero(str, len) {
    return lpad(toStr(str), len || 2, '0');
  }

  var regToken = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZWN]|'[^']*'|'[^']*'/g,
      regTimezone = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
      regNum = /\d/,
      regTimezoneClip = /[^-+\dA-Z]/g;
  exports.masks = {
    'default': 'ddd mmm dd yyyy HH:MM:ss',
    'shortDate': 'm/d/yy',
    'mediumDate': 'mmm d, yyyy',
    'longDate': 'mmmm d, yyyy',
    'fullDate': 'dddd, mmmm d, yyyy',
    'shortTime': 'h:MM TT',
    'mediumTime': 'h:MM:ss TT',
    'longTime': 'h:MM:ss TT Z',
    'isoDate': 'yyyy-mm-dd',
    'isoTime': 'HH:MM:ss',
    'isoDateTime': 'yyyy-mm-dd\'T\'HH:MM:sso',
    'isoUtcDateTime': 'UTC:yyyy-mm-dd\'T\'HH:MM:ss\'Z\'',
    'expiresHeaderFormat': 'ddd, dd mmm yyyy HH:MM:ss Z'
  };
  exports.i18n = {
    dayNames: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    monthNames: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
  };
  return exports;
}();
/* ------------------------------ ltrim ------------------------------ */

var ltrim = _.ltrim = function () {
  /* Remove chars or white-spaces from beginning of string.
   *
   * |Name  |Type        |Desc              |
   * |------|------------|------------------|
   * |str   |string      |String to trim    |
   * |chars |string array|Characters to trim|
   * |return|string      |Trimmed string    |
   *
   * ```javascript
   * ltrim(' abc  '); // -> 'abc  '
   * ltrim('_abc_', '_'); // -> 'abc_'
   * ltrim('_abc_', ['a', '_']); // -> 'bc_'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  var regSpace = /^\s+/;

  function exports(str, chars) {
    if (chars == null) return str.replace(regSpace, '');
    var start = 0,
        len = str.length,
        charLen = chars.length,
        found = true,
        i,
        c;

    while (found && start < len) {
      found = false;
      i = -1;
      c = str.charAt(start);

      while (++i < charLen) {
        if (c === chars[i]) {
          found = true;
          start++;
          break;
        }
      }
    }

    return start >= len ? '' : str.substr(start, len);
  }

  return exports;
}();
/* ------------------------------ mapGetters ------------------------------ */

var mapGetters = _.mapGetters = function () {
  /* dependencies
   * each 
   */
  function exports(module, getters) {
    var ret = {};
    each(getters, function (val, key) {
      var mappedGetter = function mappedGetter() {
        return this.$store.state[module][val];
      };

      ret[key] = mappedGetter;
    });

    ret['state'] = function mappedGetter() {
      return this.$store.state[module];
    };

    return ret;
  }

  return exports;
}();
/* ------------------------------ matcher ------------------------------ */

var matcher = _.matcher = function () {
  /* Return a predicate function that checks if attrs are contained in an object.
   *
   * |Name  |Type    |Desc                              |
   * |------|--------|----------------------------------|
   * |attrs |object  |Object of property values to match|
   * |return|function|New predicate function            |
   *
   * ```javascript
   * var objects = [
   *     {a: 1, b: 2, c: 3 },
   *     {a: 4, b: 5, c: 6 }
   * ];
   * filter(objects, matcher({a: 4, c: 6 })); // -> [{a: 4, b: 5, c: 6 }]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * extendOwn isMatch 
   */
  function exports(attrs) {
    attrs = extendOwn({}, attrs);
    return function (obj) {
      return isMatch(obj, attrs);
    };
  }

  return exports;
}();
/* ------------------------------ safeCb ------------------------------ */

var safeCb = _.safeCb = function (exports) {
  /* Create callback based on input value.
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isFn isObj optimizeCb matcher identity 
   */
  exports = function exports(val, ctx, argCount) {
    if (val == null) return identity;
    if (isFn(val)) return optimizeCb(val, ctx, argCount);
    if (isObj(val)) return matcher(val);
    return function (key) {
      return function (obj) {
        return obj == null ? undefined : obj[key];
      };
    };
  };

  return exports;
}({});
/* ------------------------------ filter ------------------------------ */

var filter = _.filter = function () {
  /* Iterates over elements of collection, returning an array of all the values that pass a truth test.
   *
   * |Name     |Type    |Desc                                   |
   * |---------|--------|---------------------------------------|
   * |obj      |array   |Collection to iterate over             |
   * |predicate|function|Function invoked per iteration         |
   * |[ctx]    |*       |Predicate context                      |
   * |return   |array   |Array of all values that pass predicate|
   *
   * ```javascript
   * filter([1, 2, 3, 4, 5], function (val)
   * {
   *     return val % 2 === 0;
   * }); // -> [2, 4]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * safeCb each 
   */
  function exports(obj, predicate, ctx) {
    var ret = [];
    predicate = safeCb(predicate, ctx);
    each(obj, function (val, idx, list) {
      if (predicate(val, idx, list)) ret.push(val);
    });
    return ret;
  }

  return exports;
}();
/* ------------------------------ difference ------------------------------ */

var difference = _.difference = function (exports) {
  /* Create an array of unique array values not included in the other given array.
   *
   * |Name     |Type |Desc                        |
   * |---------|-----|----------------------------|
   * |arr      |array|Array to inspect            |
   * |[...rest]|array|Values to exclude           |
   * |return   |array|New array of filtered values|
   *
   * ```javascript
   * difference([3, 2, 1], [4, 2]); // -> [3, 1]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * restArgs flatten filter contain 
   */
  exports = restArgs(function (arr, rest) {
    rest = flatten(rest);
    return filter(arr, function (val) {
      return !contain(rest, val);
    });
  });
  return exports;
}({});
/* ------------------------------ map ------------------------------ */

var map = _.map = function () {
  /* Create an array of values by running each element in collection through iteratee.
   *
   * |Name    |Type        |Desc                          |
   * |--------|------------|------------------------------|
   * |obj     |array object|Collection to iterate over    |
   * |iteratee|function    |Function invoked per iteration|
   * |[ctx]   |*           |Function context              |
   * |return  |array       |New mapped array              |
   *
   * ```javascript
   * map([4, 8], function (n) { return n * n; }); // -> [16, 64]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * safeCb keys isArrLike 
   */
  function exports(obj, iteratee, ctx) {
    iteratee = safeCb(iteratee, ctx);

    var _keys = !isArrLike(obj) && keys(obj),
        len = (_keys || obj).length,
        results = Array(len);

    for (var i = 0; i < len; i++) {
      var curKey = _keys ? _keys[i] : i;
      results[i] = iteratee(obj[curKey], curKey, obj);
    }

    return results;
  }

  return exports;
}();
/* ------------------------------ toArr ------------------------------ */

var toArr = _.toArr = function () {
  /* Convert value to an array.
   *
   * |Name  |Type |Desc            |
   * |------|-----|----------------|
   * |val   |*    |Value to convert|
   * |return|array|Converted array |
   *
   * ```javascript
   * toArr({a: 1, b: 2}); // -> [{a: 1, b: 2}]
   * toArr('abc'); // -> ['abc']
   * toArr(1); // -> [1]
   * toArr(null); // -> []
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isArrLike map isArr isStr 
   */
  function exports(val) {
    if (!val) return [];
    if (isArr(val)) return val;
    if (isArrLike(val) && !isStr(val)) return map(val);
    return [val];
  }

  return exports;
}();
/* ------------------------------ Class ------------------------------ */

var Class = _.Class = function () {
  /* Create JavaScript class.
   *
   * |Name     |Type    |Desc                             |
   * |---------|--------|---------------------------------|
   * |methods  |object  |Public methods                   |
   * |[statics]|object  |Static methods                   |
   * |return   |function|Function used to create instances|
   *
   * ```javascript
   * var People = Class({
   *     initialize: function People(name, age)
   *     {
   *         this.name = name;
   *         this.age = age;
   *     },
   *     introduce: function ()
   *     {
   *         return 'I am ' + this.name + ', ' + this.age + ' years old.';
   *     }
   * });
   *
   * var Student = People.extend({
   *     initialize: function Student(name, age, school)
   *     {
   *         this.callSuper(People, 'initialize', arguments);
   *
   *         this.school = school;
   *     },
   *     introduce: function ()
   *     {
   *         return this.callSuper(People, 'introduce') + '\n I study at ' + this.school + '.';
   *     }
   * }, {
   *     is: function (obj)
   *     {
   *         return obj instanceof Student;
   *     }
   * });
   *
   * var a = new Student('allen', 17, 'Hogwarts');
   * a.introduce(); // -> 'I am allen, 17 years old. \n I study at Hogwarts.'
   * Student.is(a); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * extend toArr inherits has safeGet isMiniProgram 
   */
  function exports(methods, statics) {
    return Base.extend(methods, statics);
  }

  function makeClass(parent, methods, statics) {
    statics = statics || {};
    var className = methods.className || safeGet(methods, 'initialize.name') || '';
    delete methods.className;
    var ctor;

    if (isMiniProgram) {
      ctor = function ctor() {
        var args = toArr(arguments);
        return this.initialize ? this.initialize.apply(this, args) || this : this;
      };
    } else {
      ctor = new Function('toArr', 'return function ' + className + '()' + '{' + 'var args = toArr(arguments);' + 'return this.initialize ? this.initialize.apply(this, args) || this : this;' + '};')(toArr);
    }

    inherits(ctor, parent);
    ctor.prototype.constructor = ctor;

    ctor.extend = function (methods, statics) {
      return makeClass(ctor, methods, statics);
    };

    ctor.inherits = function (Class) {
      inherits(ctor, Class);
    };

    ctor.methods = function (methods) {
      extend(ctor.prototype, methods);
      return ctor;
    };

    ctor.statics = function (statics) {
      extend(ctor, statics);
      return ctor;
    };

    ctor.methods(methods).statics(statics);
    return ctor;
  }

  var Base = exports.Base = makeClass(Object, {
    className: 'Base',
    callSuper: function callSuper(parent, name, args) {
      var superMethod = parent.prototype[name];
      return superMethod.apply(this, args);
    },
    toString: function toString() {
      return this.constructor.name;
    }
  });
  return exports;
}();
/* ------------------------------ Enum ------------------------------ */

var Enum = _.Enum = function (exports) {
  /* Enum type implementation.
   *
   * ### constructor
   *
   * |Name|Type |Desc            |
   * |----|-----|----------------|
   * |arr |array|Array of strings|
   *
   * |Name|Type  |Desc                  |
   * |----|------|----------------------|
   * |obj |object|Pairs of key and value|
   *
   * ```javascript
   * var importance = new Enum([
   *     'NONE', 'TRIVIAL', 'REGULAR', 'IMPORTANT', 'CRITICAL'
   * ]);
   *
   * if (val === importance.CRITICAL)
   * {
   *     // Do something.
   * }
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * Class freeze isArr each keys 
   */
  exports = Class({
    initialize: function Enum(map) {
      if (isArr(map)) {
        this.size = map.length;
        each(map, function (member, val) {
          this[member] = val;
        }, this);
      } else {
        this.size = keys(map).length;
        each(map, function (val, member) {
          this[member] = val;
        }, this);
      }

      freeze(this);
    }
  });
  return exports;
}({});
/* ------------------------------ createUrl ------------------------------ */

var createUrl = _.createUrl = function () {
  /* CreateObjectURL wrapper.
   *
   * |Name   |Type                  |Desc                                |
   * |-------|----------------------|------------------------------------|
   * |data   |File Blob string array|Url data                            | 
   * |[opts] |object                |Used when data is not a File or Blob|
   * |return |string                |Blob url                            |
   * 
   * ```javascript
   * createUrl('test', {type: 'text/plain'}); // -> Blob url
   * createUrl(['test', 'test']);
   * createUrl(new Blob([]));
   * createUrl(new File(['test'], 'test.txt'));
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * defaults isBlob isFile Blob toArr 
   */
  function exports(data, opts) {
    opts = opts || {};
    defaults(opts, defOpts);

    if (!isBlob(data) && !isFile(data)) {
      data = new Blob(toArr(data), opts);
    }

    return URL.createObjectURL(data);
  }

  var defOpts = {
    type: 'text/plain'
  };
  return exports;
}();
/* ------------------------------ download ------------------------------ */

var download = _.download = function () {
  /* Trigger a file download on client side.
   *
   * |Name           |Type                  |Desc            |
   * |---------------|----------------------|----------------|
   * |data           |Blob File string array|Data to download|
   * |name           |string                |File name       |
   * |type=text/plain|string                |Data type       |
   * 
   * ```javascript
   * download('test', 'test.txt');
   * ```
   */

  /* module
   * env: browser
   * test: browser
   */

  /* dependencies
   * createUrl 
   */
  function exports(data, name, type) {
    type = type || 'text/plain';
    var el = document.createElement('a');
    el.setAttribute('href', createUrl(data, {
      type: type
    }));
    el.setAttribute('download', name);
    el.addEventListener('click', function (e) {
      e.stopImmediatePropagation();
    });
    document.body.appendChild(el);
    el.click();
    document.body.removeChild(el);
  }

  return exports;
}();
/* ------------------------------ intersect ------------------------------ */

var intersect = _.intersect = function () {
  /* Compute the list of values that are the intersection of all the arrays.
   *
   * |Name  |Type |Desc                          |
   * |------|-----|------------------------------|
   * |...arr|array|Arrays to inspect             |
   * |return|array|New array of inspecting values|
   *
   * ```javascript
   * intersect([1, 2, 3, 4], [2, 1, 10], [2, 1]); // -> [1, 2]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * contain toArr 
   */
  function exports(arr) {
    var ret = [],
        args = toArr(arguments),
        argsLen = args.length,
        item,
        i,
        j,
        len;

    for (i = 0, len = arr.length; i < len; i++) {
      item = arr[i];
      if (contain(ret, item)) continue;

      for (j = 1; j < argsLen; j++) {
        if (!contain(args[j], item)) break;
      }

      if (j === argsLen) ret.push(item);
    }

    return ret;
  }

  return exports;
}();
/* ------------------------------ nextTick ------------------------------ */

var nextTick = _.nextTick = function (exports) {
  /* Next tick for both node and browser.
   *
   * |Name|Type    |Desc            |
   * |----|--------|----------------|
   * |cb  |function|Function to call|
   *
   * Use process.nextTick if available.
   *
   * Otherwise setImmediate or setTimeout is used as fallback.
   *
   * ```javascript
   * nextTick(function ()
   * {
   *     // Do something...
   * });
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  if ((typeof process === "undefined" ? "undefined" : Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_typeof__WEBPACK_IMPORTED_MODULE_6__["default"])(process)) === 'object' && process.nextTick) {
    exports = process.nextTick;
  } else if (typeof setImmediate === 'function') {
    exports = function exports(cb) {
      setImmediate(ensureCallable(cb));
    };
  } else {
    exports = function exports(cb) {
      setTimeout(ensureCallable(cb), 0);
    };
  }

  function ensureCallable(fn) {
    if (typeof fn !== 'function') throw new TypeError(fn + ' is not a function');
    return fn;
  }

  return exports;
}({});
/* ------------------------------ now ------------------------------ */

var now = _.now = function (exports) {
  /* Gets the number of milliseconds that have elapsed since the Unix epoch.
   *
   * ```javascript
   * now(); // -> 1468826678701
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  exports = Date.now || function () {
    return new Date().getTime();
  };

  return exports;
}({});
/* ------------------------------ partial ------------------------------ */

var partial = _.partial = function (exports) {
  /* Partially apply a function by filling in given arguments.
   *
   * |Name       |Type    |Desc                                    |
   * |-----------|--------|----------------------------------------|
   * |fn         |function|Function to partially apply arguments to|
   * |...partials|*       |Arguments to be partially applied       |
   * |return     |function|New partially applied function          |
   *
   * ```javascript
   * var sub5 = partial(function (a, b) { return b - a }, 5);
   * sub(20); // -> 15
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * restArgs toArr 
   */
  exports = restArgs(function (fn, partials) {
    return function () {
      var args = [];
      args = args.concat(partials);
      args = args.concat(toArr(arguments));
      return fn.apply(this, args);
    };
  });
  return exports;
}({});
/* ------------------------------ once ------------------------------ */

var _once = _.once = function (exports) {
  /* Create a function that invokes once.
   *
   * |Name  |Type    |Desc                   |
   * |------|--------|-----------------------|
   * |fn    |function|Function to restrict   |
   * |return|function|New restricted function|
   *
   * ```javascript
   * function init() {};
   * var initOnce = once(init);
   * initOnce();
   * initOnce(); // -> init is invoked once
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * partial before 
   */
  exports = partial(before, 2);
  return exports;
}({});
/* ------------------------------ Emitter ------------------------------ */



var Emitter = _.Emitter = function (exports) {
  /* Event emitter class which provides observer pattern.
   *
   * ### on
   *
   * Bind event.
   *
   * ### off
   *
   * Unbind event.
   *
   * ### once
   *
   * Bind event that trigger once.
   *
   * |Name    |Type    |Desc          |
   * |--------|--------|--------------|
   * |event   |string  |Event name    |
   * |listener|function|Event listener|
   *
   * ### emit
   *
   * Emit event.
   *
   * |Name   |Type  |Desc                        |
   * |-------|------|----------------------------|
   * |event  |string|Event name                  |
   * |...args|*     |Arguments passed to listener|
   *
   * ### mixin
   *
   * [static] Mixin object class methods.
   *
   * |Name|Type  |Desc           |
   * |----|------|---------------|
   * |obj |object|Object to mixin|
   *
   * ```javascript
   * var event = new Emitter();
   * event.on('test', function () { console.log('test') });
   * event.emit('test'); // Logs out 'test'.
   * Emitter.mixin({});
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * Class has each slice once 
   */
  exports = Class({
    initialize: function Emitter() {
      this._events = this._events || {};
    },
    on: function on(event, listener) {
      this._events[event] = this._events[event] || [];

      this._events[event].push(listener);

      return this;
    },
    off: function off(event, listener) {
      if (!has(this._events, event)) return;

      this._events[event].splice(this._events[event].indexOf(listener), 1);

      return this;
    },
    once: function once(event, listener) {
      this.on(event, _once(listener));
      return this;
    },
    emit: function emit(event) {
      if (!has(this._events, event)) return;
      var args = slice(arguments, 1);
      each(this._events[event], function (val) {
        val.apply(this, args);
      }, this);
      return this;
    }
  }, {
    mixin: function mixin(obj) {
      each(['on', 'off', 'once', 'emit'], function (val) {
        obj[val] = exports.prototype[val];
      });
      obj._events = obj._events || {};
    }
  });
  return exports;
}({});
/* ------------------------------ Logger ------------------------------ */

var Logger = _.Logger = function (exports) {
  /* Simple logger with level filter.
   *
   * ### constructor
   * 
   * |Name         |Type  |Desc        |
   * |-------------|------|------------|
   * |name         |string|Logger name |
   * |[level=DEBUG]|number|Logger level|
   * 
   * ### setLevel
   * 
   * |Name |Type         |Desc        |
   * |-----|-------------|------------|
   * |level|number string|Logger level|
   * 
   * ### getLevel
   * 
   * Get current level.
   * 
   * ### trace, debug, info, warn, error
   * 
   * Logging methods.
   * 
   * ### Log Levels
   * 
   * TRACE, DEBUG, INFO, WARN, ERROR and SILENT.
   * 
   * ```javascript
   * var logger = new Logger('licia', Logger.level.ERROR);
   * logger.trace('test');
   * 
   * // Format output.
   * logger.formatter = function (type, argList)
   * {
   *     argList.push(new Date().getTime());
   * 
   *     return argList;
   * };
   * 
   * logger.on('all', function (type, argList) 
   * {
   *     // It's not affected by log level.
   * });
   * 
   * logger.on('debug', function (argList) 
   * {
   *     // Affected by log level.
   * });
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * Emitter Enum toArr isUndef clone isStr isNum 
   */
  exports = Emitter.extend({
    initialize: function Logger(name, level) {
      this.name = name;
      this.setLevel(isUndef(level) ? exports.level.DEBUG : level);
      this.callSuper(Emitter, 'initialize', arguments);
    },
    setLevel: function setLevel(level) {
      if (isStr(level)) {
        level = exports.level[level.toUpperCase()];
        if (level) this._level = level;
        return this;
      }

      if (isNum(level)) this._level = level;
      return this;
    },
    getLevel: function getLevel() {
      return this._level;
    },
    formatter: function formatter(type, argList) {
      return argList;
    },
    trace: function trace() {
      return this._log('trace', arguments);
    },
    debug: function debug() {
      return this._log('debug', arguments);
    },
    info: function info() {
      return this._log('info', arguments);
    },
    warn: function warn() {
      return this._log('warn', arguments);
    },
    error: function error() {
      return this._log('error', arguments);
    },
    _log: function _log(type, argList) {
      argList = toArr(argList);
      if (argList.length === 0) return this;
      this.emit('all', type, clone(argList));
      if (exports.level[type.toUpperCase()] < this._level) return this;
      this.emit(type, clone(argList));
      /* eslint-disable no-console */

      var consoleMethod = type === 'debug' ? console.log : console[type];
      consoleMethod.apply(console, this.formatter(type, argList));
      return this;
    }
  }, {
    level: new Enum({
      TRACE: 0,
      DEBUG: 1,
      INFO: 2,
      WARN: 3,
      ERROR: 4,
      SILENT: 5
    })
  });
  return exports;
}({});
/* ------------------------------ pickImage ------------------------------ */

var pickImage = _.pickImage = function () {
  function exports(name) {
    return new Promise(function (resolve) {
      var input = document.createElement('input');
      input.style.position = 'fixed';
      input.style.bottom = '0';
      input.style.left = '0';
      input.style.visibility = 'hidden';
      input.setAttribute('name', name);
      input.setAttribute('type', 'file');
      input.setAttribute('accept', 'image/png, image/gif, image/jpg, image/jpeg');
      document.body.appendChild(input);
      input.addEventListener('change', function () {
        document.body.removeChild(input);
        resolve(input);
      });
      input.click();
    });
  }

  return exports;
}();
/* ------------------------------ posToCoord ------------------------------ */

var posToCoord = _.posToCoord = function () {
  /* dependencies
   * colToLabel 
   */
  function exports(row, col) {
    col = col < 0 ? 0 : col;
    row = row < 0 ? 0 : row;
    return colToLabel(col + 1) + (row + 1);
  }

  return exports;
}();
/* ------------------------------ random ------------------------------ */

var random = _.random = function () {
  /* Produces a random number between min and max(inclusive).
   *
   * |Name            |Type   |Desc                  |
   * |----------------|-------|----------------------|
   * |min             |number |Minimum possible value|
   * |max             |number |Maximum possible value|
   * |[floating=false]|boolean|Float or not          |
   * |return          |number |Random number         |
   *
   * ```javascript
   * random(1, 5); // -> an integer between 0 and 5
   * random(5); // -> an integer between 0 and 5
   * random(1.2, 5.2, true); /// -> a floating-point number between 1.2 and 5.2
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(min, max, floating) {
    if (max == null) {
      max = min;
      min = 0;
    }

    var rand = Math.random();

    if (floating || min % 1 || max % 1) {
      return Math.min(min + rand * (max - min + parseFloat('1e-' + ((rand + '').length - 1))), max);
    }

    return min + Math.floor(rand * (max - min + 1));
  }

  return exports;
}();
/* ------------------------------ randomBytes ------------------------------ */

var randomBytes = _.randomBytes = function (exports) {
  /* Random bytes generator.
   *
   * Use crypto module in node or crypto object in browser if possible.
   *
   * |Name  |Type  |Desc                        |
   * |------|------|----------------------------|
   * |size  |number|Number of bytes to generate |
   * |return|object|Random bytes of given length|
   *
   * ```javascript
   * randomBytes(5); // -> [55, 49, 153, 30, 122]
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * random isBrowser isNode 
   */
  var crypto;

  if (isBrowser) {
    crypto = window.crypto || window.msCrypto;

    if (crypto) {
      exports = function exports(size) {
        var ret = new Uint8Array(size);
        crypto.getRandomValues(ret);
        return ret;
      };
    }
  } else if (isNode) {
    crypto = __webpack_require__(/*! crypto */ "HEbw");

    exports = function exports(size) {
      return crypto.randomBytes(size);
    };
  }

  exports = exports || function (size) {
    var ret = new Uint8Array(size);

    for (var i = 0; i < size; i++) {
      ret[i] = random(0, 255);
    }

    return ret;
  };

  return exports;
}({});
/* ------------------------------ rangeToSelection ------------------------------ */

var rangeToSelection = _.rangeToSelection = function () {
  /* dependencies
   * coordToPos 
   */
  function exports(range) {
    var pos = range.indexOf(':'),
        startCoord,
        startPos,
        endCoord,
        endPos;

    if (pos >= 0) {
      startCoord = range.substring(0, pos);
      startPos = coordToPos(startCoord);
      endCoord = range.substring(pos + 1);
      endPos = coordToPos(endCoord);
      return {
        row: startPos.row,
        col: startPos.col,
        rowCount: endPos.row - startPos.row + 1,
        colCount: endPos.col - startPos.col + 1
      };
    }

    startPos = coordToPos(range);
    return {
      row: startPos.row,
      col: startPos.col,
      rowCount: 1,
      colCount: 1
    };
  }

  return exports;
}();
/* ------------------------------ rtrim ------------------------------ */

var rtrim = _.rtrim = function () {
  /* Remove chars or white-spaces from end of string.
   *
   * |Name  |Type        |Desc              |
   * |------|------------|------------------|
   * |str   |string      |String to trim    |
   * |chars |string array|Characters to trim|
   * |return|string      |Trimmed string    |
   *
   * ```javascript
   * rtrim(' abc  '); // -> ' abc'
   * rtrim('_abc_', '_'); // -> '_abc'
   * rtrim('_abc_', ['c', '_']); // -> '_ab'
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  var regSpace = /\s+$/;

  function exports(str, chars) {
    if (chars == null) return str.replace(regSpace, '');
    var end = str.length - 1,
        charLen = chars.length,
        found = true,
        i,
        c;

    while (found && end >= 0) {
      found = false;
      i = -1;
      c = str.charAt(end);

      while (++i < charLen) {
        if (c === chars[i]) {
          found = true;
          end--;
          break;
        }
      }
    }

    return end >= 0 ? str.substring(0, end + 1) : '';
  }

  return exports;
}();
/* ------------------------------ safeSet ------------------------------ */

var safeSet = _.safeSet = function () {
  /* Set value at path of object.
   *
   * If a portion of path doesn't exist, it's created.
   *
   * |Name|Type        |Desc                   |
   * |----|------------|-----------------------|
   * |obj |object      |Object to modify       |
   * |path|array string|Path of property to set|
   * |val |*           |Value to set           |
   *
   * ```javascript
   * var obj = {};
   * safeSet(obj, 'a.aa.aaa', 1); // obj = {a: {aa: {aaa: 1}}}
   * safeSet(obj, ['a', 'aa'], 2); // obj = {a: {aa: 2}}
   * safeSet(obj, 'a.b', 3); // obj = {a: {aa: 2, b: 3}}
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * castPath isUndef 
   */
  function exports(obj, path, val) {
    path = castPath(path, obj);
    var lastProp = path.pop(),
        prop;
    prop = path.shift();

    while (!isUndef(prop)) {
      if (!obj[prop]) obj[prop] = {};
      obj = obj[prop];
      prop = path.shift();
    }

    obj[lastProp] = val;
  }

  return exports;
}();
/* ------------------------------ selectionToRange ------------------------------ */

var selectionToRange = _.selectionToRange = function () {
  /* dependencies
   * posToCoord 
   */
  function exports(selection) {
    var row = selection.row,
        col = selection.col,
        rowCount = selection.rowCount,
        colCount = selection.colCount;
    col = col < 0 ? 0 : col;
    row = row < 0 ? 0 : row;
    if (rowCount === 1 && colCount === 1) return posToCoord(row, col);
    var startPos = {
      row: row,
      col: col
    },
        endPos = {
      row: row + rowCount - 1,
      col: col + colCount - 1
    };
    return posToCoord(startPos.row, startPos.col) + ':' + posToCoord(endPos.row, endPos.col);
  }

  return exports;
}();
/* ------------------------------ startWith ------------------------------ */

var startWith = _.startWith = function () {
  /* Check if string starts with the given target string.
   *
   * |Name  |Type   |Desc                             |
   * |------|-------|---------------------------------|
   * |str   |string |String to search                 |
   * |prefix|string |String prefix                    |
   * |return|boolean|True if string starts with prefix|
   *
   * ```javascript
   * startWith('ab', 'a'); // -> true
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(str, prefix) {
    return str.indexOf(prefix) === 0;
  }

  return exports;
}();
/* ------------------------------ strHash ------------------------------ */

var strHash = _.strHash = function () {
  /* String hash function using djb2.
   * 
   * |Name  |Type  |Desc          |
   * |------|------|--------------|
   * |str   |string|String to hash|
   * |return|number|Hash result   |
   * 
   * ```javascript
   * strHash('test'); // -> 2090770981
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(str) {
    var hash = 5381;
    var i = str.length;

    while (i) {
      hash = (hash << 5) + hash + str.charCodeAt(--i);
    }

    return hash >>> 0; // Make sure it's always positive.
  }

  return exports;
}();
/* ------------------------------ type ------------------------------ */

var type = _.type = function () {
  /* Determine the internal JavaScript [[Class]] of an object.
   *
   * |Name  |Type  |Desc                      |
   * |------|------|--------------------------|
   * |val   |*     |Value to get type         |
   * |return|string|Type of object, lowercased|
   *
   * ```javascript
   * type(5); // -> 'number'
   * type({}); // -> 'object'
   * type(function () {}); // -> 'function'
   * type([]); // -> 'array'
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * objToStr isNaN 
   */
  function exports(val) {
    if (val === null) return 'null';
    if (val === undefined) return 'undefined';
    if (isNaN(val)) return 'nan';
    var ret = objToStr(val).match(regObj);
    if (!ret) return '';
    return ret[1].toLowerCase();
  }

  var regObj = /^\[object\s+(.*?)]$/;
  return exports;
}();
/* ------------------------------ upperFirst ------------------------------ */

var upperFirst = _.upperFirst = function () {
  /* Convert the first character of string to upper case.
   *
   * |Name  |Type  |Desc             |
   * |------|------|-----------------|
   * |str   |string|String to convert|
   * |return|string|Converted string |
   *
   * ```javascript
   * upperFirst('red'); // -> Red
   * ```
   */

  /* module
   * env: all
   * test: all
   */
  function exports(str) {
    if (str.length < 1) return str;
    return str[0].toUpperCase() + str.slice(1);
  }

  return exports;
}();
/* ------------------------------ stringify ------------------------------ */

var stringify = _.stringify = function () {
  /* JSON stringify with support for circular object, function etc.
   *
   * Undefined is treated as null value.
   *  
   * |Name  |Type  |Desc               |
   * |------|------|-------------------|
   * |obj   |object|Object to stringify|
   * |spaces|number|Indent spaces      |
   * |return|string|Stringified object |
   * 
   * ```javascript
   * stringify({a: function () {}}); // -> '{"a":"[Function function () {}]"}'
   * var obj = {a: 1};
   * obj.b = obj;
   * stringify(obj); // -> '{"a":1,"b":"[Circular ~]"}'
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * type upperFirst toStr isUndef isFn isRegExp 
   */
  function exports(obj, spaces) {
    return JSON.stringify(obj, serializer(), spaces);
  }

  function serializer() {
    var stack = [],
        keys = [];
    return function (key, val) {
      if (stack.length > 0) {
        var pos = stack.indexOf(this);

        if (pos > -1) {
          stack.splice(pos + 1);
          keys.splice(pos, Infinity, key);
        } else {
          stack.push(this);
          keys.push(key);
        }

        var valPos = stack.indexOf(val);

        if (valPos > -1) {
          if (stack[0] === val) {
            val = '[Circular ~]';
          } else {
            val = '[Circular ~.' + keys.slice(0, valPos).join('.') + ']';
          }
        }
      } else {
        stack.push(val);
      }

      if (isRegExp(val) || isFn(val)) {
        val = '[' + upperFirst(type(val)) + ' ' + toStr(val) + ']';
      } else if (isUndef(val)) {
        val = null;
      }

      return val;
    };
  }

  return exports;
}();
/* ------------------------------ timediff ------------------------------ */

var timediff = _.timediff = function () {
  /* dependencies
   * dateFormat 
   */
  function exports(seconds, diff) {
    function format(n, word) {
      n = Math.round(n);
      return '' + n + ' ' + word;
    }

    var d = Math.max(0, diff / 1000);

    if (d < 60) {
      return '1分钟前';
    }

    d /= 60;

    if (d < 60) {
      return format(d, '分钟前');
    }

    d /= 60;

    if (d < 6) {
      return format(d, '小时前');
    }

    var serverDate = new Date(seconds * 1000);

    if (d >= 6 && serverDate.toDateString() === new Date().toDateString()) {
      // 大于6小时且为今天
      if (serverDate.getHours() < 12) {
        return '上午 ' + dateFormat(serverDate, 'HH:MM');
      } else {
        return '下午 ' + dateFormat(serverDate, 'HH:MM');
      }
    }

    if (d > 24 && d <= 48) {
      return '昨天 ' + dateFormat(serverDate, 'HH:MM');
    } // d /= 24;


    return dateFormat(new Date(seconds * 1000), 'mm月dd日 HH:MM');
  }

  return exports;
}();
/* ------------------------------ toNum ------------------------------ */

var toNum = _.toNum = function (exports) {
  /* Convert value to a number.
   *
   * |Name  |Type  |Desc            |
   * |------|------|----------------|
   * |val   |*     |Value to process|
   * |return|number|Resulted number |
   *
   * ```javascript
   * toNum('5'); // -> 5
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * isNum isObj isFn isStr 
   */
  exports = function exports(val) {
    if (isNum(val)) return val;

    if (isObj(val)) {
      var temp = isFn(val.valueOf) ? val.valueOf() : val;
      val = isObj(temp) ? temp + '' : temp;
    }

    if (!isStr(val)) return val === 0 ? val : +val;
    return +val;
  };

  return exports;
}({});
/* ------------------------------ trim ------------------------------ */

var trim = _.trim = function () {
  /* Remove chars or white-spaces from beginning end of string.
   *
   * |Name  |Type        |Desc              |
   * |------|------------|------------------|
   * |str   |string      |String to trim    |
   * |chars |string array|Characters to trim|
   * |return|string      |Trimmed string    |
   *
   * ```javascript
   * trim(' abc  '); // -> 'abc'
   * trim('_abc_', '_'); // -> 'abc'
   * trim('_abc_', ['a', 'c', '_']); // -> 'b'
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * ltrim rtrim 
   */
  var regSpace = /^\s+|\s+$/g;

  function exports(str, chars) {
    if (chars == null) return str.replace(regSpace, '');
    return ltrim(rtrim(str, chars), chars);
  }

  return exports;
}();
/* ------------------------------ uploadImage ------------------------------ */

var uploadImage = _.uploadImage = function () {
  function exports(url, input) {
    var iframe = document.createElement('iframe');
    var form = document.createElement('form');
    return new Promise(function (resolve, reject) {
      var frameName = "ajax_frame_".concat(Date.now(), "_").concat(Math.random());
      iframe.setAttribute('src', 'javascript: document.domain = document.domain');
      iframe.setAttribute('name', frameName);
      form.setAttribute('target', frameName);
      form.setAttribute('action', url);
      form.setAttribute('method', 'post');
      form.setAttribute('enctype', 'multipart/form-data');
      iframe.style.display = form.style.display = 'none';
      document.body.appendChild(iframe);
      document.body.appendChild(form);
      form.appendChild(input);
      window.addEventListener('message', messageReceived);

      function messageReceived(event) {
        if (!event.data || event.data.type !== 'imgUpload') {
          return;
        }

        window.removeEventListener('message', messageReceived);
        resolve(event.data.url);
      }

      iframe.addEventListener('error', function () {
        reject(new Error('upload image failed'));
      });
      form.submit();
    }).then(function (res) {
      dispose();
      return res;
    }).catch(function (error) {
      dispose();
      throw error;
    });

    function dispose() {
      document.body.removeChild(iframe);
      document.body.removeChild(form);
    }
  }

  return exports;
}();
/* ------------------------------ uuid ------------------------------ */

var uuid = _.uuid = function () {
  /* RFC4122 version 4 compliant uuid generator.
   *
   * Check [RFC4122 4.4](http://www.ietf.org/rfc/rfc4122.txt) for reference.
   *
   * ```javascript
   * uuid(); // -> '53ce0497-6554-49e9-8d79-347406d2a88b'
   * ```
   */

  /* module
   * env: all
   * test: all
   */

  /* dependencies
   * randomBytes 
   */
  function exports() {
    var b = randomBytes(16);
    b[6] = b[6] & 0x0f | 0x40;
    b[8] = b[8] & 0x3f | 0x80;
    return hexBytes[b[0]] + hexBytes[b[1]] + hexBytes[b[2]] + hexBytes[b[3]] + '-' + hexBytes[b[4]] + hexBytes[b[5]] + '-' + hexBytes[b[6]] + hexBytes[b[7]] + '-' + hexBytes[b[8]] + hexBytes[b[9]] + '-' + hexBytes[b[10]] + hexBytes[b[11]] + hexBytes[b[12]] + hexBytes[b[13]] + hexBytes[b[14]] + hexBytes[b[15]];
  }

  var hexBytes = [];

  for (var i = 0; i < 256; i++) {
    hexBytes[i] = (i + 0x100).toString(16).substr(1);
  }

  return exports;
}();
/* harmony default export */ __webpack_exports__["default"] = (_);
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/webpack/buildin/global.js */ "yLpj"), __webpack_require__(/*! ./../../node_modules/node-libs-browser/mock/process.js */ "Q2Ig")))

/***/ }),

/***/ "8zjJ":
/*!**********************************!*\
  !*** ./src/lib/commands/sort.js ***!
  \**********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.array.sort */ "Vd3H");
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.object.keys */ "RW0V");
/* harmony import */ var core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_object_keys__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.array.iterator */ "yt8O");
/* harmony import */ var core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_iterator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es7_object_values__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/es7.object.values */ "hhXQ");
/* harmony import */ var core_js_modules_es7_object_values__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es7_object_values__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es6_object_assign__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es6.object.assign */ "91GP");
/* harmony import */ var core_js_modules_es6_object_assign__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_object_assign__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _changeset__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../changeset */ "9pe4");









 // import { WSAEHOSTUNREACH } from 'constants';

var logger = new _Logger__WEBPACK_IMPORTED_MODULE_7__["default"]('sort');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      type = _ref.type,
      selection = _ref.selection,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(type, selection);
  selection.row = selection.row < 0 ? 0 : selection.row;
  selection.col = selection.col < 0 ? 0 : selection.col;
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  var self = this;
  var isRange = type.indexOf('range') == -1 ? false : true;
  var isAscending = (type.indexOf('ascending') == -1 && type.indexOf('Ascending')) == -1 ? false : true;
  var row = isRange ? selection.row : 0,
      col = isRange ? selection.col : 0,
      rowCount = isRange ? selection.rowCount : worksheet.getRowCount(),
      colCount = isRange ? selection.colCount : worksheet.getColumnCount();
  var srcRange = {
    row: row,
    col: col,
    rowCount: rowCount,
    colCount: colCount
  };
  var isFormula; //含有合并单元格的话，就不允许排序

  if (Object(_util__WEBPACK_IMPORTED_MODULE_6__["getMergeCellList"])(srcRange, data.spans).length > 0) {
    window.showHeaderAlert('提示', '不能对包含合并单元格的行进行排序', ['确定'], function () {});
    return;
  }

  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  var undoCmds = [];
  var oldDataTable = this.getRangeData(srcRange).data.dataTable;
  var toSortDataTable = this.getRangeData(srcRange).data.dataTable;
  var changeTable = {};
  var changeStyleTable = {}; // 生成排序前指令

  undoCmds = this.execute("setAll", {
    selection: srcRange,
    value: this.getRangeData(srcRange),
    sync: false,
    unRefresh: true
  }); // 遍历dataTable这个类似二维数组的object

  traverseDataTable(oldDataTable, function (x, y, cellData) {
    //cellData存在只是有value、style、formula这些属性的其中一个，必须的有value。x为row， y为col
    if (cellData.formula) {
      isFormula = true;
    }

    if (cellData.value) {
      //单元格的值已经初始化
      changeTable["".concat(x, ":").concat(y)] = {
        hasOldValue: true,
        //排序前cellData是否的有value
        hasNewValue: false,
        //排序后cellData是否的有value
        x: x,
        y: y
      };
    } else {
      changeTable["".concat(x, ":").concat(y)] = {
        hasOldValue: false,
        hasNewValue: false,
        x: x,
        y: y
      };
    }

    if (cellData.style) {
      changeStyleTable["".concat(x, ":").concat(y)] = {
        hasOldStyle: true,
        //排序前cellData是否的有style
        hasNewStyle: false,
        //排序前cellData是否的有style
        x: x,
        y: y
      }; // 如果旧的表中该单元格有样式，那么redo时，应该把样式清除

      var commandsTemp = self.execute("clearFormat", {
        selection: {
          row: +x,
          col: +y,
          rowCount: 1,
          colCount: 1
        },
        render: false,
        sync: false,
        undo: false,
        undoStack: false,
        unRefresh: true
      });
      commands = commands.concat(commandsTemp.commands);
    } else {
      changeStyleTable["".concat(x, ":").concat(y)] = {
        hasOldStyle: false,
        hasNewStyle: false,
        x: x,
        y: y
      };
    }
  });

  if (isFormula) {
    window.showHeaderAlert('提示', '不能对包含公式的单元格进行排序', ['确定'], function () {});
    return;
  }

  logger.debug("oldDataTable : ", oldDataTable); // 暂时先注释，现在不需要用原生的方法，刷界面
  // if (render) {
  //     // 渲染界面
  //     worksheet.sortRange(row, col, rowCount, colCount, true, [{
  //         index: selection.col,
  //         ascending: isAscending
  //     }]); 
  // }
  // let newDataTable = this.getRangeData(srcRange).data.dataTable;

  var sortDataTableResult = sortDataTable(toSortDataTable, isAscending, selection.col, srcRange);
  var newDataTable = sortDataTableResult.sortedDataTable;
  var rowChangeTable = sortDataTableResult.rowChangeTable; // 注意不能直接传入this.commentList进去，因为这个属性是实时变化的。

  var tempComnmentList = Object.assign(this.commentList);
  var sortCommentsResult = sortComments(rowChangeTable, tempComnmentList, commands, undoCmds);
  commands = sortCommentsResult.commands;
  undoCmds = sortCommentsResult.undoCommands;
  logger.debug("newDataTable : ", newDataTable, rowChangeTable, this.commentList); // 和格式刷类似样，先清空value（格式），这样就不会出现value为空时，没有被撤回的情况

  traverseDataTable(newDataTable, function (x, y, cellData) {
    if (!changeTable["".concat(x, ":").concat(y)]) {
      changeTable["".concat(x, ":").concat(y)] = {
        hasOldValue: false,
        hasNewValue: false,
        x: x,
        y: y
      };
    }

    if (cellData.value) {
      changeTable["".concat(x, ":").concat(y)].hasNewValue = true;
    }

    if (changeTable["".concat(x, ":").concat(y)].hasNewValue === changeTable["".concat(x, ":").concat(y)].hasOldValue) {
      //如果新和旧的dataTable都不需要生成setValue指令或者都需要生成，则不需要添加额外的设置为空单元格的指令
      delete changeTable["".concat(x, ":").concat(y)];
    }

    if (!changeStyleTable["".concat(x, ":").concat(y)]) {
      changeStyleTable["".concat(x, ":").concat(y)] = {
        hasOldStyle: false,
        hasNewStyle: false,
        x: x,
        y: y
      };
    }

    if (cellData.style) {
      changeStyleTable["".concat(x, ":").concat(y)].hasNewStyle = true; // 如果新的表中该单元格有样式，那么undo时，应该把样式清除

      var undoTemp = self.execute("clearFormat", {
        selection: {
          row: +x,
          col: +y,
          rowCount: 1,
          colCount: 1
        },
        render: false,
        sync: false,
        undo: false,
        undoStack: false,
        unRefresh: true
      });
      undoCmds = undoCmds.concat(undoTemp.commands);
    }

    if (changeStyleTable["".concat(x, ":").concat(y)].hasOldStyle === changeStyleTable["".concat(x, ":").concat(y)].hasNewStyle) {
      delete changeStyleTable["".concat(x, ":").concat(y)];
    }
  });
  Object.values(changeTable).forEach(function (cellData) {
    logger.debug("add setValue :", cellData);
    cellData.x = +cellData.x;
    cellData.y = +cellData.y;

    if (cellData.hasNewValue && !cellData.hasOldValue) {
      //有新没旧的，undo时补一条为空的setValue指令。添加对队尾
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setValue', {
        selection: {
          row: cellData.x,
          col: cellData.y,
          rowCount: 1,
          colCount: 1
        },
        value: ''
      }));
    } else if (!cellData.hasNewValue && cellData.hasOldValue) {
      //没新有旧的，redo时补一条为空的setValue指令。添加对队首
      commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setValue', {
        selection: {
          row: cellData.x,
          col: cellData.y,
          rowCount: 1,
          colCount: 1
        },
        value: ''
      }));
    }
  }); // 暂时先注释，因为现在style，的redo和undo指令都在遍历dataTable就添加
  // Object.values(changeStyleTable).forEach(function(cellData){
  //     logger.debug("add clearFormat :", cellData);
  //     cellData.x = +cellData.x;
  //     cellData.y = +cellData.y;
  //     if (cellData.hasNewStyle && !cellData.hasOldStyle) {
  //         let undoTemp = self.execute("clearFormat",{
  //             selection:{
  //                 row: cellData.x,
  //                 col: cellData.y,
  //                 rowCount: 1,
  //                 colCount: 1
  //             },
  //             render: false,
  //             sync: false,
  //             undo: false,
  //             undoStack: false,
  //         });
  //         undoCmds = undoCmds.concat(undoTemp.commands);
  //     } 
  //     else if (!cellData.hasNewStyle && cellData.hasOldStyle) {
  //         let commandsTemp = self.execute("clearFormat", {
  //             selection:{
  //                 row: cellData.x,
  //                 col: cellData.y,
  //                 rowCount: 1,
  //                 colCount: 1
  //             },
  //             render: false,
  //             sync: false,
  //             undo: false,
  //             undoStack: false,
  //         });
  //         commands = commands.concat(commandsTemp.commands);
  //     }
  // });
  // 生成排序后指令用于保存和同步

  var tempValue = this.getRangeData(srcRange);
  tempValue.data.dataTable = newDataTable;
  commands = commands.concat(this.execute("setAll", {
    selection: srcRange,
    value: tempValue,
    sync: false,
    unRefresh: true
  }));

  if (render) {
    var localChangeSet = new _changeset__WEBPACK_IMPORTED_MODULE_9__["SheetChangeSet"]();
    localChangeSet.appendCmds(commands);
    var cmdStr = localChangeSet.getStrCmds();
    this.executeRemoteCmds(cmdStr);
  }

  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  logger.debug("undoManager hello", commands, undoCmds);
  if (sync) this.sendCmds(commands);
  return {
    commands: commands,
    undoCmds: undoCmds
  };
});

function traverseDataTable(dataTable, iteratee) {
  Object.keys(dataTable).forEach(function (x) {
    Object.keys(dataTable[x]).forEach(function (y) {
      iteratee(x, y, dataTable[x][y]);
    });
  });
}

function sortDataTable(dataTable, isAscending, index, sortRange) {
  // 将dataTable里面的全部值拿出来，作为用于排序的数组
  var toSortArray = Object.values(dataTable);
  var rowArray = Object.keys(dataTable); // 记录初始化行号

  for (var i = toSortArray.length - 1; i >= 0; i--) {
    toSortArray[i].row = +rowArray[i];
  } // 比较算法，需要写成一个闭包，因为sort里面需要访问index


  var sortFunction = function sortFunction(a, b) {
    // a和b，排序列都是未定，或''
    if ((a[index] === undefined || a[index].value === undefined || a[index].value === '') && (b[index] === undefined || b[index].value === undefined || b[index].value === '')) {
      return a.row > b.row ? 1 : -1;
    } // a为未定义，b为数字或字符串
    else if ((a[index] === undefined || a[index].value === undefined || a[index].value === '') && b[index].value !== undefined) {
        return 1;
      } // a为数字或字符串，b为未定义
      else if (a[index].value && (b[index] === undefined || b[index].value === undefined || b[index].value === '')) {
          return -1;
        } // a，b都是数字
        else if (typeof a[index].value === 'number' && typeof b[index].value === 'number') {
            var comResult = a[index].value - b[index].value;

            if (a[index].value === b[index].value) {
              return a.row > b.row ? 1 : -1;
            }

            comResult = isAscending ? comResult : -comResult;
            return comResult;
          } // a为数字，b为字符串
          else if (typeof a[index].value === 'number' && typeof b[index].value === 'string') {
              return !isAscending ? 1 : -1;
            } // a为字符串，b为数字
            else if (typeof a[index].value === 'string' && typeof b[index].value === 'number') {
                return isAscending ? 1 : -1;
              } // a，b都为字符串
              else {
                  var stringA = a[index].value,
                      stringB = b[index].value;
                  var AisCh = /[\u4e00-\u9fa5]/.test(stringA);
                  var BisCh = /[\u4e00-\u9fa5]/.test(stringB);

                  var _comResult;

                  if (AisCh && BisCh) {
                    //都是中文
                    _comResult = stringA.localeCompare(stringB, 'zh-Hans-CN', {
                      sensitivity: 'accent'
                    });

                    if (_comResult === 0) {
                      return a.row > b.row ? 1 : -1;
                    }

                    _comResult = isAscending ? _comResult : -_comResult;
                    return _comResult;
                  } else if (AisCh) {
                    return isAscending ? 1 : -1;
                  } else if (BisCh) {
                    return isAscending ? -1 : 1;
                  } else {
                    _comResult = stringA.localeCompare(stringB);

                    if (_comResult === 0) {
                      return a.row > b.row ? 1 : -1;
                    }

                    _comResult = isAscending ? _comResult : -_comResult;
                    return _comResult;
                  }
                }
  }; // 排序


  var sortedArray = toSortArray.sort(sortFunction);
  var sortedDataTable = {};
  var rowChangeTable = {}; //记录行号的变化，key为排序前的行号，value为排序后的行号
  //还原为dataTable

  for (var _i = sortedArray.length - 1; _i >= 0; _i--) {
    // 排序后，如果地i行的排序列有值，则还原为dataTable的第i行
    if (sortedArray[_i][index] && sortedArray[_i][index].value) {
      rowChangeTable["".concat(sortedArray[_i].row)] = _i + sortRange.row;
      delete sortedArray[_i].row;
      sortedDataTable["".concat(_i + sortRange.row)] = sortedArray[_i];
    } //  如果第i行没有值，则还原为dataTable的第i（row）行，取i和row的更大者
    else {
        var n = _i + sortRange.row > sortedArray[_i].row ? _i + sortRange.row : sortedArray[_i].row;
        rowChangeTable["".concat(sortedArray[_i].row)] = n;
        delete sortedArray[_i].row;
        sortedDataTable["".concat(n)] = sortedArray[_i];
      }
  }

  logger.debug("dataTable sort ", dataTable);
  logger.debug("dataTable sorted ", sortedDataTable);
  return {
    sortedDataTable: sortedDataTable,
    rowChangeTable: rowChangeTable
  };
} // 发送指令，改变评论的位置


function sortComments(rowChangeTable, commentList, commands, undoCommands) {
  var tempCommands = [],
      tempUndo = []; // 用于调整指令顺序的

  for (var i = commentList.length - 1; i >= 0; i--) {
    var beforeSortedRow = commentList[i].span.row;
    var col = commentList[i].span.col;
    var afterSortedRow = rowChangeTable["".concat(beforeSortedRow)];

    if (afterSortedRow !== undefined && beforeSortedRow !== afterSortedRow) {
      // 发生排序
      commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setComment', {
        selection: {
          row: beforeSortedRow,
          col: col,
          rowCount: 1,
          colCount: 1
        },
        value: ''
      }));
      tempCommands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setComment', {
        selection: {
          row: afterSortedRow,
          col: col,
          rowCount: 1,
          colCount: 1
        },
        value: commentList[i].cid
      }));
      tempUndo.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setComment', {
        selection: {
          row: afterSortedRow,
          col: col,
          rowCount: 1,
          colCount: 1
        },
        value: ''
      }));
      undoCommands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_8__["default"])('setComment', {
        selection: {
          row: beforeSortedRow,
          col: col,
          rowCount: 1,
          colCount: 1
        },
        value: commentList[i].cid
      }));
    }
  }

  logger.debug("the tempCommands is", tempCommands, tempUndo);
  commands = commands.concat(tempCommands);
  undoCommands = undoCommands.concat(tempUndo);
  return {
    commands: commands,
    undoCommands: undoCommands
  };
}

/***/ }),

/***/ "9NOR":
/*!***********************************!*\
  !*** ./src/lib/commands/paste.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.string.bold */ "SMB2");
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Font */ "lLCG");






var logger = new _Logger__WEBPACK_IMPORTED_MODULE_4__["default"]('paste'); // 通过渲染完excel获取最新的值 复制粘贴

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      fromSelection = _ref.fromSelection,
      isCutting = _ref.isCutting,
      toSelection = _ref.toSelection,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo;

  logger.debug(fromSelection, isCutting, toSelection);
  var commands = [];
  var undoCmds = [];
  var worksheet = this.worksheet,
      data = this.data,
      undoManager = this.undoManager; // 上次操作的旧数据

  var olddataTable = data && data.data && data.data.dataTable; // 本次操作之后的新数据

  var dataTable = worksheet.toJSON().data.dataTable; // 本次操作之后的合并单元格

  var newSpan = worksheet.toJSON().spans; //处理复制粘贴整列整行的问题

  if (toSelection) {
    var colCount = worksheet.getColumnCount();
    var rowCount = worksheet.getRowCount();

    if (toSelection.row === -1 && toSelection.rowCount === -1) {
      toSelection.row = 0;
      toSelection.rowCount = rowCount;
    }

    if (toSelection.col === -1 && toSelection.colCount === -1) {
      toSelection.col = 0;
      toSelection.colCount = colCount;
    }
  }

  undoManager.addUndoStack();

  if (newSpan && newSpan.length) {
    Object(_util__WEBPACK_IMPORTED_MODULE_2__["each"])(newSpan || [], function (span) {
      var row = toSelection.row,
          col = toSelection.col,
          rowCount = toSelection.rowCount,
          colCount = toSelection.colCount,
          rowEnd = row + rowCount - 1,
          colEnd = col + colCount - 1;

      if (span.row >= row && span.row <= rowEnd && span.col >= col && span.col <= colEnd) {
        var cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('merge', {
          selection: span,
          value: 1
        });
        var undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('merge', {
          selection: span,
          value: 0
        });
        commands = commands.concat(cmd);
        undoCmds = undoCmds.concat(undocmd);
      }
    });
  }

  Object(_util__WEBPACK_IMPORTED_MODULE_2__["iterateSelection"])(toSelection, function (row, col) {
    var selection = {
      row: row,
      col: col,
      rowCount: 1,
      colCount: 1
    }; // TODO 公式兼容

    if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'value']) !== Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(olddataTable, [row, col, 'value']) || Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'formula']) !== Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(olddataTable, [row, col, 'formula'])) {
      var cmd = '';
      var undocmd = '';

      if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'formula']) && Object(_util__WEBPACK_IMPORTED_MODULE_2__["isFormula"])('=' + Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'formula']))) {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setFormula', {
          selection: selection,
          value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'formula']) || ''
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setFormula', {
          selection: selection,
          value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(olddataTable, [row, col, 'formula']) || ''
        });
      } else {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setValue', {
          selection: selection,
          value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'value']) || ''
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setValue', {
          selection: selection,
          value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(olddataTable, [row, col, 'value']) || ''
        });
      }

      commands = commands.concat(cmd);
      undoCmds = undoCmds.concat(undocmd);
    } // 设置样式


    var style = Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(dataTable, [row, col, 'style']);
    var oldStyle = Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(olddataTable, [row, col, 'style']);
    style = style || {};
    oldStyle = oldStyle || {};
    var stylePropertyArr = ['bold', 'italic', 'fontSize', 'strike', 'textWrap', 'hAlign', 'vAlign', 'foreColor', 'backColor', 'borderTop', 'borderRight', 'borderBottom', 'borderLeft'];
    stylePropertyArr.forEach(function (property) {
      var font = '';
      if (style.font) font = style.font;
      var isFont = isFontProp(property);
      if (isFont) font = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](font);
      var oldFont = '';
      if (oldStyle.font) oldFont = oldStyle.font;
      var isOldFont = isFontProp(property);
      if (isOldFont) oldFont = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](oldFont);
      var cmd = '';
      var undocmd = '';

      switch (property) {
        case 'bold':
          if (font.bold() !== oldFont.bold()) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: font.bold() ? 1 : 0
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldFont.bold() ? 1 : 0
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'italic':
          if (font.italic() !== oldFont.italic()) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: font.italic() ? 1 : 0
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldFont.italic() ? 1 : 0
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'fontSize':
          if (font.size() !== oldFont.size()) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: font.size()
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldFont.size()
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'strike':
          style.textDecoration = style.textDecoration || 0;
          oldStyle.textDecoration = oldStyle.textDecoration || 0;

          if (style.textDecoration !== oldStyle.textDecoration) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.textDecoration ? 1 : 0
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldStyle.textDecoration ? 1 : 0
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'textWrap':
          style.wordWrap = style.wordWrap || false;
          oldStyle.wordWrap = oldStyle.wordWrap || false;

          if (style.wordWrap !== oldStyle.wordWrap) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.wordWrap ? 1 : 0
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldStyle.wordWrap ? 1 : 0
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'hAlign':
          style.hAlign = style.hAlign === 0 ? 0 : style.hAlign || 3;
          oldStyle.hAlign = oldStyle.hAlign === 0 ? 0 : oldStyle.hAlign || 3;

          if (style.hAlign !== oldStyle.hAlign) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["getHAlign"])(style.hAlign)
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["getHAlign"])(oldStyle.hAlign)
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'vAlign':
          style.vAlign = style.vAlign === 0 ? 0 : style.vAlign || 3;
          oldStyle.vAlign = oldStyle.vAlign === 0 ? 0 : oldStyle.vAlign || 3;

          if (style.vAlign !== oldStyle.vAlign) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["getVAlign"])(style.vAlign)
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["getVAlign"])(oldStyle.vAlign)
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'foreColor':
          style.foreColor = style.foreColor || '';
          oldStyle.foreColor = oldStyle.foreColor || '';

          if (style.foreColor !== oldStyle.foreColor) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.foreColor
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldStyle.foreColor
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'backColor':
          style.backColor = style.backColor || '';
          oldStyle.backColor = oldStyle.backColor || '';

          if (style.backColor !== oldStyle.backColor) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.backColor
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldStyle.backColor
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;

        case 'borderTop':
        case 'borderRight':
        case 'borderBottom':
        case 'borderLeft':
          style[property] = style[property] || '';
          oldStyle[property] = oldStyle[property] || '';

          if (style[property] !== oldStyle[property]) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style[property]
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: oldStyle[property]
            });
            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }

          break;
      }
    });
  });

  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  } // 自适应调整行高


  for (var row = toSelection.row; row < toSelection.row + toSelection.rowCount; row++) {
    worksheet.autoFitRow(row);
  }

  if (sync) this.sendCmds(commands); // window.hasCopyPasteCache = false

  return commands;
});

function isFontProp(property) {
  return ['bold', 'italic', 'fontSize'].indexOf(property) > -1;
}

/***/ }),

/***/ "9pe4":
/*!************************************!*\
  !*** ./src/lib/changeset/index.js ***!
  \************************************/
/*! exports provided: SheetChangeSet, CmdStrParser */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SheetChangeSet__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SheetChangeSet */ "pezt");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "SheetChangeSet", function() { return _SheetChangeSet__WEBPACK_IMPORTED_MODULE_0__["default"]; });

/* harmony import */ var _CmdStrParser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./CmdStrParser */ "ZqfF");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "CmdStrParser", function() { return _CmdStrParser__WEBPACK_IMPORTED_MODULE_1__["default"]; });



var changset = {
  SheetChangeSet: _SheetChangeSet__WEBPACK_IMPORTED_MODULE_0__["default"],
  CmdStrParser: _CmdStrParser__WEBPACK_IMPORTED_MODULE_1__["default"]
};

if (typeof window !== 'undefined') {
  window.changeset = changset;
}



/***/ }),

/***/ "Bjwg":
/*!****************************!*\
  !*** ./src/api/comment.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../store */ "Q2AE");


/* harmony default export */ __webpack_exports__["default"] = ({
  fetch: function fetch(sheetId) {
    var sid = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/comment/getlist",
      params: {
        docsid: sid,
        fileid: sheetId
      }
    });
  },
  fetchById: function fetchById(sheetId, mainCommentId) {
    var sid = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/comment/getbyid",
      params: {
        docsid: sid,
        fileid: sheetId,
        commentid: mainCommentId
      }
    });
  },
  create: function create(author, sheetId, content, commentPersonList) {
    var _store$state$app = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        vid = _store$state$app.vid,
        sid = _store$state$app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/comment/create?other_vid=".concat(author),
      traditional: true,
      data: {
        docsid: sid,
        fileid: sheetId,
        own_vid: vid,
        content: content,
        other_vid: commentPersonList
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  },
  reply: function reply(sheetId, content, mainCommentId, commentPersonList) {
    var _store$state$app2 = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        vid = _store$state$app2.vid,
        sid = _store$state$app2.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/comment/reply",
      traditional: true,
      data: {
        docsid: sid,
        fileid: sheetId,
        vid: vid,
        content: content,
        mainid: mainCommentId,
        replyid: mainCommentId,
        content_vid: commentPersonList
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  },
  delete: function _delete(sheetId, commentId, endComment) {
    var sid = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/comment/delete",
      traditional: true,
      data: {
        docsid: sid,
        fileid: sheetId,
        commentid: commentId,
        isall: endComment ? 1 : 0
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  }
});

/***/ }),

/***/ "BuKO":
/*!****************************!*\
  !*** ./src/api/history.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../store */ "Q2AE");


/* harmony default export */ __webpack_exports__["default"] = ({
  fetch: function fetch(version, sheetId) {
    var _store$state$app = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        mainKey = _store$state$app.mainKey,
        sid = _store$state$app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/e/".concat(mainKey),
      params: {
        docsid: sid,
        doc_version: version,
        op: 'history',
        rendertype: 'json',
        doc_sheetid: sheetId
      }
    });
  }
});

/***/ }),

/***/ "DMRR":
/*!**************************************!*\
  !*** ./src/lib/commands/dragCopy.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      args = _ref.args,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var rowCount = args.rowCount,
      columnCount = args.columnCount,
      fromRow = args.fromRow,
      toRow = args.toRow,
      fromColumn = args.fromColumn,
      toColumn = args.toColumn;
  var worksheet = this.worksheet; // 添加命令到commands数组

  var commands = [];
  fromRow = fromRow > 0 ? fromRow : 0;
  fromColumn = fromColumn > 0 ? fromColumn : 0;
  toRow = toRow > 0 ? toRow : 0;
  toColumn = toColumn > 0 ? toColumn : 0;
  rowCount = rowCount > -1 ? rowCount : worksheet.getRowCount();
  columnCount = columnCount > -1 ? columnCount : worksheet.getColumnCount();
  commands = commands.concat(this.execute('paste', {
    fromSelection: {
      row: fromRow,
      rowCount: rowCount,
      col: fromColumn,
      colCount: columnCount
    },
    isCutting: true,
    toSelection: {
      row: toRow,
      rowCount: rowCount,
      col: toColumn,
      colCount: columnCount
    },
    sync: false
  }));
  commands = commands.concat(this.execute('cut', {
    selection: {
      row: fromRow,
      rowCount: rowCount,
      col: fromColumn,
      colCount: columnCount
    },
    sync: false
  })); // 发送指令同步数据到远程

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "Eaqo":
/*!****************************************!*\
  !*** ./src/lib/changeset/IndexInfo.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return IndexInfo; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");



/**
 * 行/列 的index坐标位置信息
 */
var IndexInfo =
/*#__PURE__*/
function () {
  function IndexInfo() {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, IndexInfo);

    this.index = 0; // 行坐标或者列坐标

    this.oldIndex = 0; // 如果新增或者删除'行/列'，这个代表新增或删除行/列之前的坐标

    this.isDependOnNew = false; // 如果有新增，而且是在新增上做操作，则为true

    this.hasDeleted = false; // 如果行/列已经被删除， 则为true
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(IndexInfo, [{
    key: "isValid",
    value: function isValid() {
      return !this.hasDeleted;
    }
  }, {
    key: "dependOnNew",
    value: function dependOnNew() {
      return this.isDependOnNew;
    }
  }]);

  return IndexInfo;
}();



/***/ }),

/***/ "Eo9w":
/*!******************************!*\
  !*** ./src/lib/Constants.js ***!
  \******************************/
/*! exports provided: MSG_TYPES, CONNECTION_STATE, WINDOW_MSG_TYPES, DEFAULT_FONT */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MSG_TYPES", function() { return MSG_TYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CONNECTION_STATE", function() { return CONNECTION_STATE; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WINDOW_MSG_TYPES", function() { return WINDOW_MSG_TYPES; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DEFAULT_FONT", function() { return DEFAULT_FONT; });
var MSG_TYPES = {
  HELLO: 'hello',
  GET: 'get',
  UPDATE: 'update',
  UPDATE_CONFLICT: 'update.conflict',
  UPDATE_BROADCAST: 'update.broadcast',
  UPDATE_FILE_NAME: 'updateFileName',
  UPDATE_FILENAME_BROADCAST: 'updateFileName.broadcast',
  ADD_SHEET: 'addSheet',
  ADD_SHEET_BROADCAST: 'addSheet.broadcast',
  DELETE_SHEET: 'deleteSheet',
  DELETE_SHEET_BROADCAST: 'deleteSheet.broadcast',
  COPY_SHEET: 'copySheet',
  COPY_SHEET_BROADCAST: 'copySheet.broadcast',
  UPDATE_SHEET: 'updateSheet',
  UPDATE_SHEET_BROADCAST: 'updateSheet.broadcast',
  ROLL: 'roll',
  ROLL_BROADCAST: 'roll.broadcast',
  GET_HISTORY: 'getHistory',
  ONLINE: 'online',
  OFFLINE: 'offline',
  UDPATE_REGION: 'updateRegion',
  UDPATE_REGION_BROADCAST: 'updateRegion.broadcast',
  GET_REGIONS: 'getRegions'
};
var CONNECTION_STATE = {
  OPEN: 'open',
  CLOSED: 'closed',
  CLOSING: 'closing',
  CONNECTING: 'connecting',
  RECONNECTING: 'reconnecting'
};
var WINDOW_MSG_TYPES = {
  DOWNLOAD_LOG: 'common-dowmload-log'
};
var DEFAULT_FONT = {
  FAMILY: '-apple-system, BlinkMacSystemFont, "PingFang SC", "Microsoft YaHei", STHeiti, Helvetica, Arial, sans-serif',
  SIZE: 12
};

/***/ }),

/***/ "FH+/":
/*!**************************************!*\
  !*** ./src/lib/commands/setImage.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.function.name */ "f3/d");
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util */ "8e1d");




var logger = new _Logger__WEBPACK_IMPORTED_MODULE_1__["default"]('setImage');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      id = _ref.id,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(id, value);
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setImage', {
    id: id,
    value: value
  }));
  var pictures = worksheet.pictures;
  var picture = pictures.get(id); // set some attr about picture

  if (picture) {
    pictures.zIndex(id, getMaxZIndex(pictures, id));
    picture.dynamicSize(false); // Gets or sets whether the size of the picture changes when hiding or showing, resizing, or moving rows or columns.
  }

  if (render) {
    if (value) {
      var src = value.src,
          x = value.x,
          y = value.y,
          width = value.width,
          height = value.height;

      if (picture) {
        worksheet.suspendEvent();
        picture.src(src);
        picture.x(x);
        picture.y(y);
        picture.width(width);
        picture.height(height);
        worksheet.resumeEvent();
      } else {
        worksheet.pictures.add(id, src, x, y, width, height);
      }
    } else {
      if (picture) pictures.remove(id);
    }
  }

  if (undo) {
    var floatingObjects = data.floatingObjects,
        undoCmds = [];

    var _picture;

    if (floatingObjects) {
      Object(_util__WEBPACK_IMPORTED_MODULE_3__["each"])(floatingObjects, function (floatingObject) {
        if (floatingObject.name === id) _picture = floatingObject;
      });
    }

    var _value;

    if (_picture) {
      var _picture2 = _picture,
          _src = _picture2.src,
          _x = _picture2.x,
          _y = _picture2.y,
          _width = _picture2.width,
          _height = _picture2.height;
      _value = {
        src: _src,
        x: _x,
        y: _y,
        width: _width,
        height: _height
      };
    }

    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setImage', {
      id: id,
      value: _value
    }));
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

function getMaxZIndex(pictures, id) {
  var zIndex = pictures.zIndex(id) || 700;
  Object(_util__WEBPACK_IMPORTED_MODULE_3__["each"])(pictures.all(), function (picture) {
    var perZIndex = pictures.zIndex(picture.name());

    if (perZIndex >= zIndex) {
      zIndex = perZIndex + 1;
    }
  });
  return zIndex;
}

/***/ }),

/***/ "G3b5":
/*!************************************!*\
  !*** ./src/lib/commands/setAll.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../generateCmd */ "11+Z");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('setAll');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      value = _ref.value,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection, value);
  var worksheet = this.worksheet; // 添加命令到commands数组

  var commands = []; // 自动填充：除合并单元格外

  var dataTable = value.data.dataTable;
  Object(_util__WEBPACK_IMPORTED_MODULE_1__["iterateSelection"])(selection, function (row, col) {
    commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setAll', {
      selection: {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      },
      value: Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(dataTable, [row, col]) || {}
    }));
  }); // 自动填充：合并单元格

  var spans = value.spans;

  if (spans && spans.length) {
    Object(_util__WEBPACK_IMPORTED_MODULE_1__["each"])(spans || [], function (span) {
      commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setAll', {
        selection: span,
        value: 1
      }));
    });
  } // 自适应调整行高


  for (var row = selection.row; row < selection.row + selection.rowCount; row++) {
    worksheet.autoFitRow(row);
  } // 发送指令同步数据到远程


  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "GONd":
/*!***************************!*\
  !*** ./src/lib/Logger.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return EditorLogger; });
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.function.name */ "f3/d");
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_inherits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/inherits */ "3Aqn");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/possibleConstructorReturn */ "0yhX");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/getPrototypeOf */ "EdlT");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./util */ "8e1d");
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./emitter */ "oj7Y");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Constants */ "Eo9w");










var logs = [];
var level =  true ? _util__WEBPACK_IMPORTED_MODULE_7__["Logger"].level.SILENT : undefined; // 可以通过设置localStore里logLevel修改日志级别

var logLevel = window.localStorage.getItem('logLevel');
if (logLevel && !Object(_util__WEBPACK_IMPORTED_MODULE_7__["isUndef"])(_util__WEBPACK_IMPORTED_MODULE_7__["Logger"].level[logLevel])) level = _util__WEBPACK_IMPORTED_MODULE_7__["Logger"].level[logLevel];

var EditorLogger =
/*#__PURE__*/
function (_Logger) {
  function EditorLogger(name) {
    var _this;

    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_1__["default"])(this, EditorLogger);

    _this = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__["default"])(this, Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__["default"])(EditorLogger).call(this, name, level));
    _this.color = selectColor(name);

    _this.on('all', function (type, argList) {
      logs.push({
        type: type,
        time: Object(_util__WEBPACK_IMPORTED_MODULE_7__["dateFormat"])('yyyymmdd HH:MM:ss:l'),
        name: _this.name,
        argList: argList
      });
    }); // 关闭 log
    // this.setLevel(5);


    return _this;
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(EditorLogger, [{
    key: "formatter",
    value: function formatter(type, argList) {
      argList.unshift("".concat(this.name));
      argList.unshift("color:".concat(this.color));
      argList.unshift(Object(_util__WEBPACK_IMPORTED_MODULE_7__["dateFormat"])('yyyymmdd HH:MM:ss:l'));
      argList.unshift('%s %c%s');
      return argList;
    }
  }], [{
    key: "download",
    value: function download() {
      var content = '';
      Object(_util__WEBPACK_IMPORTED_MODULE_7__["each"])(logs, function (val) {
        var argList = Object(_util__WEBPACK_IMPORTED_MODULE_7__["map"])(val.argList, function (val) {
          return Object(_util__WEBPACK_IMPORTED_MODULE_7__["stringify"])(val);
        });
        content += "".concat(val.time, " ").concat(val.name, " ").concat(val.type, " ").concat(argList.join(' '), "\n\n");
      });

      Object(_util__WEBPACK_IMPORTED_MODULE_7__["download"])(content, "".concat(Object(_util__WEBPACK_IMPORTED_MODULE_7__["dateFormat"])('yyyymmdd HH-MM-ss'), ".log"));
    }
  }]);

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_inherits__WEBPACK_IMPORTED_MODULE_2__["default"])(EditorLogger, _Logger);

  return EditorLogger;
}(_util__WEBPACK_IMPORTED_MODULE_7__["Logger"]);


var colors = ['#0000CC', '#0000FF', '#0033CC', '#0033FF', '#0066CC', '#0066FF', '#0099CC', '#0099FF', '#00CC00', '#00CC33', '#00CC66', '#00CC99', '#00CCCC', '#00CCFF', '#3300CC', '#3300FF', '#3333CC', '#3333FF', '#3366CC', '#3366FF', '#3399CC', '#3399FF', '#33CC00', '#33CC33', '#33CC66', '#33CC99', '#33CCCC', '#33CCFF', '#6600CC', '#6600FF', '#6633CC', '#6633FF', '#66CC00', '#66CC33', '#9900CC', '#9900FF', '#9933CC', '#9933FF', '#99CC00', '#99CC33', '#CC0000', '#CC0033', '#CC0066', '#CC0099', '#CC00CC', '#CC00FF', '#CC3300', '#CC3333', '#CC3366', '#CC3399', '#CC33CC', '#CC33FF', '#CC6600', '#CC6633', '#CC9900', '#CC9933', '#CCCC00', '#CCCC33', '#FF0000', '#FF0033', '#FF0066', '#FF0099', '#FF00CC', '#FF00FF', '#FF3300', '#FF3333', '#FF3366', '#FF3399', '#FF33CC', '#FF33FF', '#FF6600', '#FF6633', '#FF9900', '#FF9933', '#FFCC00', '#FFCC33'];

function selectColor(name) {
  return colors[Object(_util__WEBPACK_IMPORTED_MODULE_7__["strHash"])(name) % colors.length];
}

_emitter__WEBPACK_IMPORTED_MODULE_8__["default"].on(_emitter__WEBPACK_IMPORTED_MODULE_8__["default"].WINDOW_MSG, function (type) {
  if (type !== _Constants__WEBPACK_IMPORTED_MODULE_9__["WINDOW_MSG_TYPES"].DOWNLOAD_LOG) return;
  _emitter__WEBPACK_IMPORTED_MODULE_8__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_8__["default"].SHOW_HEADER_ALERT, '提示', '点击确定下载调试日志到本地', ['确定', '取消'], function (index) {
    if (index === 0) EditorLogger.download();
  });
});
window.Logger = EditorLogger;

/***/ }),

/***/ "Gh6Q":
/*!***************************!*\
  !*** ./src/lib/config.js ***!
  \***************************/
/*! exports provided: clearConfig, rowHeightConfig, formulaConfig, configPaint */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "clearConfig", function() { return clearConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rowHeightConfig", function() { return rowHeightConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "formulaConfig", function() { return formulaConfig; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "configPaint", function() { return configPaint; });
// 清除格式配置项
var clearConfig = {
  'fontSize': 12,
  // 默认的文字大小
  'bold': 0,
  'italic': 0,
  'strike': 0,
  'foreColor': '',
  'backColor': '',
  'textWrap': 0,
  'hAlign': '',
  'vAlign': 'middle',
  'borderTop': '',
  'borderRight': '',
  'borderBottom': '',
  'borderLeft': ''
}; // 行高

var rowHeightConfig = [19, 22, 24, 27, 34, 43, 50]; // 公式编辑配置项

var formulaConfig = [{
  display: 'SUM(求和)',
  value: 'SUM'
}, {
  display: 'AVERAGE(平均值)',
  value: 'AVERAGE'
}, {
  display: 'COUNT(计数)',
  value: 'COUNT'
}, {
  display: 'MAX(最大值)',
  value: 'MAX'
}, {
  display: 'MIN(最小值)',
  value: 'MIN'
}]; //保存格式刷的，格式选中区域的格式

var configPaint = {
  //格式刷是否开启
  isPaint: 0,
  // 起始位置和范围
  row: 0,
  col: 0,
  rowCount: 0,
  colCount: 0,
  //记录选中范围没有单元格的格式，二维数组（行和列），记录的格式
  // 'fontSize': 12, // 默认的文字大小
  // 'bold': 0,
  // 'italic': 0,
  // 'strike': 0,
  // 'foreColor': '',
  // 'backColor': '',
  // 'textWrap': 0,
  // 'hAlign': '',
  // 'vAlign': 'middle',
  // 'borderTop': 0,
  // 'borderRight': 0,
  // 'borderBottom': 0,
  // 'borderLeft': 0
  styles: [],
  merges: []
};

/***/ }),

/***/ "Hfur":
/*!*****************************!*\
  !*** ./src/lib/spreadNS.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* globals GC */
/* harmony default export */ __webpack_exports__["default"] = (GC.Spread.Sheets);

/***/ }),

/***/ "HgRx":
/*!*************************!*\
  !*** ./src/lib/http.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "vDqi");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = (function (options) {
  return new Promise(function (resolve, reject) {
    axios__WEBPACK_IMPORTED_MODULE_0___default()(options).then(function (res) {
      resolve(res.data);
    }, function (err) {
      reject(err);
    });
  });
});

/***/ }),

/***/ "HswM":
/*!*****************************!*\
  !*** ./src/lib/CellType.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CellType; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./emitter */ "oj7Y");


/* globals GC */
 // import Logger from './Logger';
// let logger = new Logger('CellType');

var CellType = function CellType() {
  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CellType);
};


CellType.prototype = new GC.Spread.Sheets.CellTypes.Text();

CellType.prototype.getHitInfo = function (x, y, cellStyle, cellRect, context) {
  return {
    x: x,
    y: y,
    row: context.row,
    col: context.col,
    cellStyle: cellStyle,
    cellRect: cellRect,
    sheetArea: context.sheetArea
  };
};

CellType.prototype.processMouseEnter = function (hitinfo) {
  _emitter__WEBPACK_IMPORTED_MODULE_1__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_1__["default"].CELL_MOUSE_ENTER, hitinfo);
};

CellType.prototype.processMouseLeave = function (hitinfo) {
  _emitter__WEBPACK_IMPORTED_MODULE_1__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_1__["default"].CELL_MOUSE_LEAVE, hitinfo);
};

/***/ }),

/***/ "JcOx":
/*!***************************************!*\
  !*** ./src/store/modules/fxEditor.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/defineProperty */ "oyJW");
/* harmony import */ var _mutationTypes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../mutationTypes */ "NPqI");


/* harmony default export */ __webpack_exports__["default"] = ({
  state: {
    value: ''
  },
  mutations: Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])({}, _mutationTypes__WEBPACK_IMPORTED_MODULE_1__["default"].UPDATE_FXEDITOR_VALUE, function (state, _ref) {
    var text = _ref.text;
    state.value = text || '';
  })
});

/***/ }),

/***/ "JrEp":
/*!*********************************************************!*\
  !*** ./src/lib/plugins/copyPaste/ContenteditableDiv.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");



/**
 * @class ContenteditableDiv
 *
 * @plugin CopyPaste
 */
var ContenteditableDiv =
/*#__PURE__*/
function () {
  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(ContenteditableDiv, null, [{
    key: "getSingleton",
    value: function getSingleton() {
      globalSingleton.append();
      return globalSingleton;
    }
  }]);

  function ContenteditableDiv() {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, ContenteditableDiv);

    /**
     * Main ContenteditableDiv element.
     *
     * @type {HTMLElement}
     */
    this.element = void 0;
    /**
     * Store information about append to the document.body.
     *
     * @type {Boolean}
     */

    this.isAppended = false;
    /**
     * Reference counter.
     *
     * @type {Number}
     */

    this.refCounter = 0;
    this.container = void 0;
  }
  /**
   * Apends ContenteditableDiv element to the `body`
   */


  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(ContenteditableDiv, [{
    key: "append",
    value: function append() {
      if (this.hasBeenDestroyed()) {
        this.create();
      }

      this.refCounter++;

      if (!this.isAppended && document.body) {
        if (document.body) {
          this.isAppended = true;
          document.body.appendChild(this.container);
        }
      }
    }
    /**
     * Prepares ContenteditableDiv element with proper attributes.
     */

  }, {
    key: "create",
    value: function create() {
      var container = document.createElement('div');
      container.style.position = 'fixed';
      container.style.top = '0px';
      container.style.left = '0px';
      container.style.width = '0px';
      container.style.height = '0px';
      container.style.overflow = 'hidden';
      var measureContainer = document.createElement('div');
      measureContainer.setAttribute('contenteditable', 'true');
      measureContainer.setAttribute('tabindex', -1);
      measureContainer.style.position = 'absolute';
      measureContainer.style.overflow = 'hidden';
      measureContainer.style.background = 'white';
      measureContainer.style.webkitUserSelect = 'text';
      measureContainer.style.minHeight = '20px';
      measureContainer.id = 'HandsontableCopyPaste';
      container.appendChild(measureContainer);
      this.container = container;
      this.element = measureContainer;
    }
    /**
     * Deselects ContenteditableDiv element if is active.
     */

  }, {
    key: "deselect",
    value: function deselect() {
      if (this.element === document.activeElement) {
        document.activeElement.blur();
      }
    }
    /**
     * Destroy instance
     */

  }, {
    key: "destroy",
    value: function destroy() {
      this.refCounter--;
      this.refCounter = this.refCounter < 0 ? 0 : this.refCounter;

      if (this.hasBeenDestroyed() && this.element && this.element.parentNode) {
        this.container.parentNode.removeChild(this.container);
        this.element = null;
        this.isAppended = false;
      }
    }
    /**
     * Getter for the element.
     *
     * @returns {String}
     */

  }, {
    key: "getValue",
    value: function getValue() {
      return this.element.innerHTML;
    }
    /**
     * Check if instance has been destroyed
     *
     * @returns {Boolean}
     */

  }, {
    key: "hasBeenDestroyed",
    value: function hasBeenDestroyed() {
      return this.refCounter < 1;
    }
    /**
     * Check if the element is an active element in frame.
     *
     * @returns {Boolean}
     */

  }, {
    key: "isActive",
    value: function isActive() {
      return this.element === document.activeElement;
    }
    /**
     * Sets focus on the element and select content.
     */

  }, {
    key: "select",
    value: function select() {
      this.element.focus(); // 需加入setTimeout才不会选中整个页面，出现闪屏

      setTimeout(function () {
        document.execCommand('selectAll', false, null);
      }, 100);
    }
    /**
     * Setter for the element.
     *
     * @param {String} data Value which should be insert into the element.
     */

  }, {
    key: "setValue",
    value: function setValue(data) {
      this.element.innerHTML = data;
    }
  }]);

  return ContenteditableDiv;
}();

var globalSingleton = new ContenteditableDiv();
/* harmony default export */ __webpack_exports__["default"] = (ContenteditableDiv);

/***/ }),

/***/ "KSLB":
/*!************************************!*\
  !*** ./src/store/modules/sheet.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/defineProperty */ "oyJW");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mutationTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mutationTypes */ "NPqI");
/* harmony import */ var _lib_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/util */ "8e1d");
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash/merge */ "QkVN");
/* harmony import */ var lodash_merge__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash_merge__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/config */ "Gh6Q");
/* harmony import */ var _lib_spreadNS__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @lib/spreadNS */ "Hfur");



var _mutations;






/* harmony default export */ __webpack_exports__["default"] = ({
  state: {
    width: 0,
    height: 0,
    toolBar: {
      undo: 2,
      redo: 2,
      paint: 0,
      bold: 0,
      fontSize: {
        status: 0,
        current: 9,
        items: [{
          display: '9',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('9')
        }, {
          display: '10.5',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('10.5')
        }, {
          display: '13.5',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('13.5')
        }, {
          display: '18',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('18')
        }, {
          display: '22.5',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('22.5')
        }, {
          display: '27',
          value: Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["getFontSize"])('27')
        }]
      },
      italic: 0,
      strike: 0,
      textWrap: 0,
      alignLeft: 0,
      alignCenter: 0,
      alignRight: 0,
      alignTop: 0,
      alignMiddle: 0,
      alignBottom: 0,
      merge: 0,
      filter: 0,
      clearFormat: 0,
      image: 0,
      comment: 0,
      foreColor: {
        status: 0,
        current: 'rgb(0,0,0)'
      },
      backColor: {
        status: 0,
        current: '#ffffff'
      },
      formula: {
        status: 0,
        items: _lib_config__WEBPACK_IMPORTED_MODULE_5__["formulaConfig"]
      },
      sort: {
        status: 0,
        items: [{
          display: '升序',
          value: 'ascending'
        }, {
          display: '降序',
          value: 'descending'
        }, {
          display: '按范围升序',
          disabled: true,
          value: 'rangeAscending'
        }, {
          display: '按范围降序',
          disabled: true,
          value: 'rangeDescending'
        }]
      },
      border: {
        status: 0,
        items: [{
          icon: 'od_icons_BorderAll',
          value: 'all'
        }, {
          icon: 'od_icons_BorderOuter',
          value: 'outer'
        }, {
          icon: 'od_icons_BorderInner',
          value: 'inner'
        }, {
          icon: 'od_icons_BorderClear',
          value: 'clear'
        }]
      },
      freeze: {
        status: 0,
        items: [{
          display: '冻结至当前第1行',
          value: 'row'
        }, {
          display: '冻结至当前第A列',
          value: 'column'
        }, {
          display: '冻结至当前第1行A列',
          value: 'rowColumn'
        }, {
          display: '取消冻结',
          value: 'cancel'
        }]
      }
    },
    cellClick: {
      row: 0,
      col: 0,
      sheetArea: _lib_spreadNS__WEBPACK_IMPORTED_MODULE_6__["default"].SheetArea.viewport
    },
    topRowChanged: {
      newTopRow: 0,
      oldTopRow: 0,
      sheetName: ''
    },
    leftColumnChanged: {
      newLeftCol: 0,
      oldLeftCol: 0,
      sheetName: ''
    }
  },
  getters: {
    isClickHeader: function isClickHeader(state) {
      if (state.cellClick.sheetArea === _lib_spreadNS__WEBPACK_IMPORTED_MODULE_6__["default"].SheetArea.colHeader || state.cellClick.sheetArea === _lib_spreadNS__WEBPACK_IMPORTED_MODULE_6__["default"].SheetArea.rowHeader) {
        return true;
      }

      return false;
    }
  },
  mutations: (_mutations = {}, Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_TOOL_BAR, function (state, payload) {
    delete payload.type;
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.toolBar, payload);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].DESELECT, function (state) {
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.toolBar, {
      paint: 2,
      bold: 2,
      italic: 2,
      strike: 2,
      textWrap: 2,
      alignLeft: 2,
      alignCenter: 2,
      alignRight: 2,
      alignTop: 2,
      alignMiddle: 2,
      alignBottom: 2,
      merge: 2,
      filter: 2,
      clearFormat: 2,
      image: 2,
      comment: 2,
      fontSize: {
        status: 2
      },
      foreColor: {
        status: 2
      },
      backColor: {
        status: 2
      },
      formula: {
        status: 2
      },
      border: {
        status: 2
      },
      sort: {
        status: 2
      },
      freeze: {
        status: 2
      }
    });
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].DISABLE_ALL_TOOL_BAR, function (state) {
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.toolBar, {
      undo: 2,
      redo: 2,
      paint: 2,
      bold: 2,
      italic: 2,
      strike: 2,
      textWrap: 2,
      alignLeft: 2,
      alignCenter: 2,
      alignRight: 2,
      alignTop: 2,
      alignMiddle: 2,
      alignBottom: 2,
      merge: 2,
      filter: 2,
      clearFormat: 2,
      image: 2,
      comment: 2,
      fontSize: {
        status: 2
      },
      foreColor: {
        status: 2
      },
      backColor: {
        status: 2
      },
      formula: {
        status: 2
      },
      border: {
        status: 2
      },
      sort: {
        status: 2
      },
      freeze: {
        status: 2
      }
    });
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_CELL_CLICK, function (state, _ref) {
    var data = _ref.data;
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.cellClick, data);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_TOPROW_CHANGED, function (state, _ref2) {
    var data = _ref2.data;
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.topRowChanged, data);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_LEFTCOL_CHANGED, function (state, _ref3) {
    var data = _ref3.data;
    lodash_merge__WEBPACK_IMPORTED_MODULE_4___default()(state.leftColumnChanged, data);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_SHEET_WIDTH, function (state, _ref4) {
    var width = _ref4.width;
    state.width = width;
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_SHEET_HEIGHT, function (state, _ref5) {
    var height = _ref5.height;
    state.height = height;
  }), _mutations),
  actions: {}
});

/***/ }),

/***/ "LX+s":
/*!***********************************!*\
  !*** ./src/lib/commands/index.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _setValue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./setValue */ "odEX");
/* harmony import */ var _setStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./setStyle */ "QCD9");
/* harmony import */ var _setFormula__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./setFormula */ "TzrH");
/* harmony import */ var _setRowHeight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./setRowHeight */ "iVfD");
/* harmony import */ var _setColWidth__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./setColWidth */ "+Dwh");
/* harmony import */ var _freeze__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./freeze */ "5Rcl");
/* harmony import */ var _setImage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./setImage */ "FH+/");
/* harmony import */ var _setBorder__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./setBorder */ "T22h");
/* harmony import */ var _merge__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./merge */ "YXv6");
/* harmony import */ var _insertRow__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./insertRow */ "4s26");
/* harmony import */ var _insertCol__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./insertCol */ "4wGw");
/* harmony import */ var _deleteRow__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./deleteRow */ "k884");
/* harmony import */ var _deleteCol__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./deleteCol */ "ktbB");
/* harmony import */ var _setAll__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./setAll */ "G3b5");
/* harmony import */ var _clearFormat__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./clearFormat */ "3iHG");
/* harmony import */ var _deleteValue__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./deleteValue */ "7rPh");
/* harmony import */ var _paint__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./paint */ "OFCJ");
/* harmony import */ var _cut__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./cut */ "RtkB");
/* harmony import */ var _paste__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./paste */ "9NOR");
/* harmony import */ var _setPaste__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./setPaste */ "gFnr");
/* harmony import */ var _sort__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./sort */ "8zjJ");
/* harmony import */ var _setComment__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./setComment */ "N6OM");
/* harmony import */ var _dragFilling__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./dragFilling */ "VF69");
/* harmony import */ var _dragFilled__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./dragFilled */ "sQsY");
/* harmony import */ var _dragMove__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./dragMove */ "o3O1");
/* harmony import */ var _dragCopy__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./dragCopy */ "DMRR");


























/* harmony default export */ __webpack_exports__["default"] = ({
  setValue: _setValue__WEBPACK_IMPORTED_MODULE_0__["default"],
  setStyle: _setStyle__WEBPACK_IMPORTED_MODULE_1__["default"],
  setFormula: _setFormula__WEBPACK_IMPORTED_MODULE_2__["default"],
  setRowHeight: _setRowHeight__WEBPACK_IMPORTED_MODULE_3__["default"],
  setColWidth: _setColWidth__WEBPACK_IMPORTED_MODULE_4__["default"],
  freeze: _freeze__WEBPACK_IMPORTED_MODULE_5__["default"],
  setImage: _setImage__WEBPACK_IMPORTED_MODULE_6__["default"],
  setBorder: _setBorder__WEBPACK_IMPORTED_MODULE_7__["default"],
  merge: _merge__WEBPACK_IMPORTED_MODULE_8__["default"],
  insertRow: _insertRow__WEBPACK_IMPORTED_MODULE_9__["default"],
  insertCol: _insertCol__WEBPACK_IMPORTED_MODULE_10__["default"],
  deleteRow: _deleteRow__WEBPACK_IMPORTED_MODULE_11__["default"],
  deleteCol: _deleteCol__WEBPACK_IMPORTED_MODULE_12__["default"],
  sort: _sort__WEBPACK_IMPORTED_MODULE_20__["default"],
  setAll: _setAll__WEBPACK_IMPORTED_MODULE_13__["default"],
  clearFormat: _clearFormat__WEBPACK_IMPORTED_MODULE_14__["default"],
  deleteValue: _deleteValue__WEBPACK_IMPORTED_MODULE_15__["default"],
  paint: _paint__WEBPACK_IMPORTED_MODULE_16__["default"],
  cut: _cut__WEBPACK_IMPORTED_MODULE_17__["default"],
  paste: _paste__WEBPACK_IMPORTED_MODULE_18__["default"],
  setPaste: _setPaste__WEBPACK_IMPORTED_MODULE_19__["default"],
  setComment: _setComment__WEBPACK_IMPORTED_MODULE_21__["default"],
  dragFilling: _dragFilling__WEBPACK_IMPORTED_MODULE_22__["default"],
  dragFilled: _dragFilled__WEBPACK_IMPORTED_MODULE_23__["default"],
  dragMove: _dragMove__WEBPACK_IMPORTED_MODULE_24__["default"],
  dragCopy: _dragCopy__WEBPACK_IMPORTED_MODULE_25__["default"]
});

/***/ }),

/***/ "Lt7s":
/*!**************************************!*\
  !*** ./src/lib/changeset/PosInfo.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return PosInfo; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");



/**
 * 行列坐标位置，包含一个行、一个列 IndexInfo
 */
var PosInfo =
/*#__PURE__*/
function () {
  function PosInfo() {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, PosInfo);

    this.row = null; // IndexInfo

    this.col = null; // IndexInfo

    this.hasDeleted = false; // 是否被删除
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(PosInfo, [{
    key: "isValid",
    value: function isValid() {
      return !this.hasDeleted;
    }
  }]);

  return PosInfo;
}();



/***/ }),

/***/ "N6OM":
/*!****************************************!*\
  !*** ./src/lib/commands/setComment.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../emitter */ "oj7Y");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_1__["default"]('setComment');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection, value);
  var commands = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('setComment', {
    selection: selection,
    value: value || ''
  }));

  if (render) {
    var comment;

    if (value && selection) {
      comment = this.worksheet.comments.add(selection.row, selection.col, '');
      comment.displayMode(0); //设置批注 但不展示批注 显示自己实现的框

      _emitter__WEBPACK_IMPORTED_MODULE_2__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_COMMENT);
    } else {
      comment = this.worksheet.comments.remove(selection.row, selection.col);
    }
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "NPqI":
/*!************************************!*\
  !*** ./src/store/mutationTypes.js ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0__);

/* harmony default export */ __webpack_exports__["default"] = ({
  UPDATE_SETTINGS: 'UPDATE_SETTINGS',
  UPDATE_BASE_MSG: 'UPDATE_BASE_MSG',
  UPDATE_WATERMARK: 'UPDATE_WATERMARK',
  UPDATE_TOOL_BAR: 'UPDATE_TOOL_BAR',
  DESELECT: 'DESELECT',
  DISABLE_ALL_TOOL_BAR: 'DISABLE_ALL_TOOL_BAR',
  // 设置 sheet 的宽度、高度
  SET_SHEET_WIDTH: 'SET_SHEET_WIDTH',
  SET_SHEET_HEIGHT: 'SET_SHEET_HEIGHT',
  // 当单元格被点击的时候
  SET_CELL_CLICK: 'SET_CELL_CLICK',
  // 当纵向滚动条滚动的时候
  SET_TOPROW_CHANGED: 'SET_TOPROW_CHANGED',
  // 当横向滚动条滚动的时候
  SET_LEFTCOL_CHANGED: 'SET_LEFTCOL_CHANGED',
  INIT_SHEETS: 'INIT_SHEETS',
  ADD_SHEET: 'ADD_SHEET',
  DELETE_SHEET: 'DELETE_SHEET',
  UPDATE_SHEET: 'UPDATE_SHEET',
  UPDATE_SHEETS: 'UPDATE_SHEETS',
  SET_ACTIVE_SHEET: 'SET_ACTIVE_SHEET',
  UPDATE_STATUS: 'UPDATE_STATUS',
  UPDATE_CELL_VALUE: 'UPDATE_CELL_VALUE',
  UPDATE_FXEDITOR_VALUE: 'UPDATE_FXEDITOR_VALUE',
  UPDATE_COMMENT_LIST: 'UPDATE_COMMENT_LIST'
});

/***/ }),

/***/ "OFCJ":
/*!***********************************!*\
  !*** ./src/lib/commands/paint.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/objectSpread */ "yT7P");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../config */ "Gh6Q");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Font */ "lLCG");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _changeset__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../changeset */ "9pe4");








var logger = new _Logger__WEBPACK_IMPORTED_MODULE_6__["default"]('paint');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      _ref$isSelectionChang = _ref.isSelectionChange,
      isSelectionChange = _ref$isSelectionChang === void 0 ? false : _ref$isSelectionChang,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render;

  // 添加命令到commands/undoCmds数组
  var commands = [];
  var undoCmds = []; // 当前sheet

  var activeSheet = this; // 撤销管理器

  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  if (undoStack && _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint == 1 && isSelectionChange) undoManager.addUndoStack(); //判断是否开始格式刷

  if (isSelectionChange && _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint == 0) {
    //没有拷贝选中区域的格式，只是更改区域，则直接跳过
    return;
  } else if (_config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint == 0 && !isSelectionChange) {
    //点击格式刷，拷贝选中区域的格式，并且更新鼠标的图标为格式刷
    // TODO:修改鼠标
    // document.getElementById('excel-containervp_vp').style.cursor =
    //     'url(HTTPS://p.qpic.cn/wwhead/duc2TvpEgSQO4BpE0WZSZ0q9qunzMXyniceavibicBfLAGLM6zoNdHreeNgQ6WJibTosjEIVBRmY6R4/40),wait !important';
    // 记录选中区域的配置
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint = 1; // 初始化格式数组

    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].styles = new Array();
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].row = selection.row;
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].col = selection.col;
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].rowCount = selection.rowCount;
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].colCount = selection.colCount;

    for (var i = 0; i < selection.rowCount; i++) {
      _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].styles[i] = new Array();
    }

    Object(_util__WEBPACK_IMPORTED_MODULE_4__["iterateSelection"])(selection, function (row, col) {
      var style = worksheet.getStyle(row, col) || {};
      var cell = worksheet.getCell(row, col);
      var font = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](cell.font());
      _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].styles[row - selection.row][col - selection.col] = {
        fontSize: font._size || 12,
        bold: font._bold ? 1 : 0,
        italic: font._italic ? 1 : 0,
        strike: style.textDecoration ? 1 : 0,
        foreColor: style.foreColor || '',
        backColor: style.backColor || '',
        textWrap: style.wordWrap ? 1 : 0,
        hAlign: Object(_util__WEBPACK_IMPORTED_MODULE_4__["getHAlign"])(style.hAlign === 0 ? 0 : style.hAlign || 3),
        vAlign: Object(_util__WEBPACK_IMPORTED_MODULE_4__["getVAlign"])(style.vAlign === 0 ? 0 : style.vAlign || 3),
        borderTop: style.borderTop ? 1 : 0,
        borderRight: style.borderRight ? 1 : 0,
        borderBottom: style.borderBottom ? 1 : 0,
        borderLeft: style.borderLeft ? 1 : 0
      }; // 绑定事件
    }); // 需要合并的单元格

    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].merges = Object(_util__WEBPACK_IMPORTED_MODULE_4__["getMergeCellList"])(selection, data.spans);
    logger.debug('the configPaint.styles is ', _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].styles);
    logger.debug('the configPaint.merges is ', _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].merges);
  } else if (_config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint == 1 && isSelectionChange) {
    //已经拷贝了区域的格式，并且更新选中区域，则执行格式刷，还原鼠标和格式刷
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint = 0; // TODO:还原鼠标

    logger.debug('begin');
    var srcRowCount = _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].rowCount;
    var srcColCount = _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].colCount;
    Object(_util__WEBPACK_IMPORTED_MODULE_4__["iterateSelection"])(selection, function (row, col) {
      var mapRow = (row - selection.row) % srcRowCount;
      var mapCol = (col - selection.col) % srcColCount;
      var style = _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].styles[mapRow][mapCol];
      var value = '';
      var valueOld = '';
      var styleOld = customGetStyle(worksheet, row, col);

      for (var key in style) {
        if (key.indexOf('border') != -1) {
          value = style[key] == 1 ? '1px solid rgb(0, 0, 0)' : '';
          valueOld = styleOld[key] == 1 ? '1px solid rgb(0, 0, 0)' : '';
        } else {
          value = style[key];
          valueOld = styleOld[key];
        }

        commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: {
            row: row,
            col: col,
            rowCount: 1,
            colCount: 1
          },
          property: key,
          value: value
        }));
        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: {
            row: row,
            col: col,
            rowCount: 1,
            colCount: 1
          },
          property: key,
          value: valueOld
        }));
      }
    }); // 保存选中区域内已合并的单元格，注意压栈顺序不能改变

    var spansInSecletion = Object(_util__WEBPACK_IMPORTED_MODULE_4__["getMergeCellList"])(selection, data.spans);
    logger.debug("the spansInSecletion is ", spansInSecletion);
    Object(_util__WEBPACK_IMPORTED_MODULE_4__["each"])(spansInSecletion || [], function (span) {
      logger.debug("the span in spansInSecletion is ", span);
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
        selection: Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, span),
        value: 1
      }));
    });
    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
      selection: selection,
      value: 0
    }));
    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
      selection: selection,
      value: 1
    }));
    logger.debug("the undo is ", Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
      selection: selection,
      value: 0
    })); // 保存选中区域内已合并的单元格 end
    // 合并的单元格

    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
      selection: selection,
      value: 0
    }));
    Object(_util__WEBPACK_IMPORTED_MODULE_4__["each"])(_config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].merges, function (span) {
      var rowSpan = span.row - _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].row;
      var colSpan = span.col - _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].col;

      for (var x = selection.row + rowSpan; x + span.rowCount <= selection.row + selection.rowCount; x += _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].rowCount) {
        for (var y = selection.col + colSpan; y + span.colCount <= selection.col + selection.colCount; y += _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].colCount) {
          commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
            selection: {
              row: x,
              col: y,
              rowCount: span.rowCount,
              colCount: span.colCount
            },
            value: 1
          }));
        }
      }
    }); // 合并的单元格end

    logger.debug('end');
  } else {
    //已经拷贝区域的格式，没有更新选中区域，则取消格式刷拷贝的格式
    // TODO:还原鼠标
    _config__WEBPACK_IMPORTED_MODULE_3__["configPaint"].isPaint = 0;
  } // 清除格式操作将所有合并后的指令，一起压栈


  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  } // 清除格式操作将所有合并后的指令，一起发送指令同步数据到远程


  if (sync) activeSheet.sendCmds(commands);

  if (render) {
    var localChangeSet = new _changeset__WEBPACK_IMPORTED_MODULE_7__["SheetChangeSet"]();
    localChangeSet.appendCmds(commands);
    var cmdStr = localChangeSet.getStrCmds();
    activeSheet.executeRemoteCmds(cmdStr);
  }

  return {
    commands: commands,
    undoCmds: undoCmds
  };
});

function customGetStyle(worksheet, row, col) {
  var style = worksheet.getStyle(row, col) || {};
  var cell = worksheet.getCell(row, col);
  var font = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](cell.font());
  return {
    fontSize: font._size || 12,
    bold: font._bold || 0,
    italic: font._italic || 0,
    strike: font._strike || 0,
    foreColor: style.foreColor || '',
    backColor: style.backColor || '',
    textWrap: style.textWrap || 0,
    hAlign: style.hAlign === 0 ? 0 : style.hAlign || 3,
    vAlign: style.vAlign === 0 ? 0 : style.vAlign || 3,
    borderTop: style.borderTop ? 1 : 0,
    borderRight: style.borderRight ? 1 : 0,
    borderBottom: style.borderBottom ? 1 : 0,
    borderLeft: style.borderLeft ? 1 : 0
  };
}

/***/ }),

/***/ "Q2AE":
/*!****************************!*\
  !*** ./src/store/index.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue */ "Kw5r");
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vuex */ "L2JU");
/* harmony import */ var _modules_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/app */ "2c2J");
/* harmony import */ var _modules_spread__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modules/spread */ "Yrf8");
/* harmony import */ var _modules_sheet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modules/sheet */ "KSLB");
/* harmony import */ var _modules_fxEditor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./modules/fxEditor */ "JcOx");
/* harmony import */ var _modules_comment__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./modules/comment */ "8H8d");







vue__WEBPACK_IMPORTED_MODULE_0__["default"].use(vuex__WEBPACK_IMPORTED_MODULE_1__["default"]);
/* harmony default export */ __webpack_exports__["default"] = (new vuex__WEBPACK_IMPORTED_MODULE_1__["default"].Store({
  modules: {
    app: _modules_app__WEBPACK_IMPORTED_MODULE_2__["default"],
    spread: _modules_spread__WEBPACK_IMPORTED_MODULE_3__["default"],
    sheet: _modules_sheet__WEBPACK_IMPORTED_MODULE_4__["default"],
    fxEditor: _modules_fxEditor__WEBPACK_IMPORTED_MODULE_5__["default"],
    comment: _modules_comment__WEBPACK_IMPORTED_MODULE_6__["default"]
  }
}));

/***/ }),

/***/ "QCD9":
/*!**************************************!*\
  !*** ./src/lib/commands/setStyle.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.to-string */ "a1Th");
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.string.bold */ "SMB2");
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Font */ "lLCG");






/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      property = _ref.property,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$clear = _ref.clear,
      clear = _ref$clear === void 0 ? false : _ref$clear,
      _ref$multiple = _ref.multiple,
      multiple = _ref$multiple === void 0 ? false : _ref$multiple,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var undoManager = this.undoManager,
      data = this.data,
      worksheet = this.worksheet,
      textWrapFlags = this.textWrapFlags; // 若清除格式操作，则在clearFormat.js里添加栈；否则，直接在此添加栈

  if (undoStack && !clear) undoManager.addUndoStack(); // 添加命令到commands/undoCmds数组

  var commands = [];
  var undoCmds = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
    selection: selection,
    property: property,
    value: value
  }));
  var isFont = isFontProp(property); // 渲染数据到当前sheet

  if (render) {
    if (!multiple) worksheet.suspendPaint();
    Object(_util__WEBPACK_IMPORTED_MODULE_4__["iterateSelection"])(selection, function (row, col) {
      var cell = worksheet.getCell(row, col),
          font;
      if (isFont) font = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](cell.font());

      switch (property) {
        case 'bold':
          font.bold(!!value);
          break;

        case 'italic':
          font.italic(!!value);
          break;

        case 'fontSize':
          font.size(value);
          break;

        case 'strike':
          cell.textDecoration(value ? 2 : 0);
          break;

        case 'textWrap':
          cell.wordWrap(!!value);
          break;

        case 'hAlign':
          cell.hAlign(Object(_util__WEBPACK_IMPORTED_MODULE_4__["getHAlign"])(value));
          break;

        case 'vAlign':
          cell.vAlign(Object(_util__WEBPACK_IMPORTED_MODULE_4__["getVAlign"])(value));
          break;

        case 'foreColor':
          cell.foreColor(value);
          break;

        case 'backColor':
          if (value === 'RGB(255,255,255)') {
            value = '';
          }

          cell.backColor(value);
          break;

        case 'borderTop':
        case 'borderRight':
        case 'borderBottom':
        case 'borderLeft':
          if (!value || !value.toString().match('object object') || !value.toString().match('object')) {
            value = value ? Object(_util__WEBPACK_IMPORTED_MODULE_4__["getBorder"])(value) : null;
            cell[property](value);
          }

      }

      if (isFont) cell.font(font.toString());
    });
    var isAutoFit = isNeedToAutoFitRow(property);

    if (isAutoFit) {
      // 自适应调整行高
      for (var row = selection.row; row < selection.row + selection.rowCount; row++) {
        if (['textWrap'].indexOf(property) > -1) {
          textWrapFlags[row] = true;
        }

        worksheet.autoFitRow(row);
      }
    }

    if (!multiple) worksheet.resumePaint();
  } // 添加命令到undoCmds 支持撤销操作


  if (undo) {
    var dataTable = data.data.dataTable;
    Object(_util__WEBPACK_IMPORTED_MODULE_4__["iterateSelection"])(selection, function (row, col) {
      var style = Object(_util__WEBPACK_IMPORTED_MODULE_4__["safeGet"])(dataTable, [row, col, 'style']);
      style = style || {};
      var font = '';
      if (style.font) font = style.font;
      if (isFont) font = new _Font__WEBPACK_IMPORTED_MODULE_5__["default"](font);
      var selection = {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      };

      switch (property) {
        case 'bold':
          if (font.bold() !== !!value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: value ? 0 : 1
            }));
          }

          break;

        case 'italic':
          if (font.italic() !== !!value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: value ? 0 : 1
            }));
          }

          break;

        case 'fontSize':
          if (font.size() !== value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: font.size()
            }));
          }

          break;

        case 'strike':
          {
            var textDecoration = value ? 2 : 0;
            style.textDecoration = style.textDecoration || 0;

            if (style.textDecoration !== textDecoration) {
              undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
                selection: selection,
                property: property,
                value: value ? 0 : 1
              }));
            }

            break;
          }

        case 'textWrap':
          style.wordWrap = style.wordWrap || false;

          if (style.wordWrap !== !!value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: value ? 0 : 1
            }));
          }

          break;

        case 'hAlign':
          style.hAlign = style.hAlign === 0 ? 0 : style.hAlign || 3;

          if (style.hAlign !== Object(_util__WEBPACK_IMPORTED_MODULE_4__["getHAlign"])(value)) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_4__["getHAlign"])(style.hAlign)
            }));
          }

          break;

        case 'vAlign':
          style.vAlign = style.vAlign === 0 ? 0 : style.vAlign || 3;

          if (style.vAlign !== Object(_util__WEBPACK_IMPORTED_MODULE_4__["getVAlign"])(value)) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: Object(_util__WEBPACK_IMPORTED_MODULE_4__["getVAlign"])(style.vAlign)
            }));
          }

          break;

        case 'foreColor':
          style.foreColor = style.foreColor || '';

          if (style.foreColor !== value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.foreColor
            }));
          }

          break;

        case 'backColor':
          style.backColor = style.backColor || '';

          if (style.backColor !== value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style.backColor
            }));
          }

          break;

        case 'borderTop':
        case 'borderRight':
        case 'borderBottom':
        case 'borderLeft':
          style[property] = style[property] || '';

          if (style[property] !== value) {
            undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_3__["default"])('setStyle', {
              selection: selection,
              property: property,
              value: style[property]
            }));
          }

          break;
      }
    }); // 若清除格式操作，则在clearFormat.js里将所有指令合并后再压栈；否则，直接压栈

    if (!clear) {
      undoManager.addUndo({
        commands: commands,
        undoCmds: undoCmds
      });
    }
  } // 若清除格式操作，则在clearFormat.js里发送指令同步数据到远程；否则，直接在此发送


  if (!clear) {
    if (sync) this.sendCmds(commands);
    return commands;
  } else {
    return {
      commands: commands,
      undoCmds: undoCmds
    };
  }
});

function isFontProp(property) {
  return ['bold', 'italic', 'fontSize'].indexOf(property) > -1;
}

function isNeedToAutoFitRow(property) {
  return ['textWrap', 'fontSize'].indexOf(property) > -1;
}

/***/ }),

/***/ "RnhZ":
/*!**************************************************!*\
  !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "K/tc",
	"./af.js": "K/tc",
	"./ar": "jnO4",
	"./ar-dz": "o1bE",
	"./ar-dz.js": "o1bE",
	"./ar-kw": "Qj4J",
	"./ar-kw.js": "Qj4J",
	"./ar-ly": "HP3h",
	"./ar-ly.js": "HP3h",
	"./ar-ma": "CoRJ",
	"./ar-ma.js": "CoRJ",
	"./ar-sa": "gjCT",
	"./ar-sa.js": "gjCT",
	"./ar-tn": "bYM6",
	"./ar-tn.js": "bYM6",
	"./ar.js": "jnO4",
	"./az": "SFxW",
	"./az.js": "SFxW",
	"./be": "H8ED",
	"./be.js": "H8ED",
	"./bg": "hKrs",
	"./bg.js": "hKrs",
	"./bm": "p/rL",
	"./bm.js": "p/rL",
	"./bn": "kEOa",
	"./bn.js": "kEOa",
	"./bo": "0mo+",
	"./bo.js": "0mo+",
	"./br": "aIdf",
	"./br.js": "aIdf",
	"./bs": "JVSJ",
	"./bs.js": "JVSJ",
	"./ca": "1xZ4",
	"./ca.js": "1xZ4",
	"./cs": "PA2r",
	"./cs.js": "PA2r",
	"./cv": "A+xa",
	"./cv.js": "A+xa",
	"./cy": "l5ep",
	"./cy.js": "l5ep",
	"./da": "DxQv",
	"./da.js": "DxQv",
	"./de": "tGlX",
	"./de-at": "s+uk",
	"./de-at.js": "s+uk",
	"./de-ch": "u3GI",
	"./de-ch.js": "u3GI",
	"./de.js": "tGlX",
	"./dv": "WYrj",
	"./dv.js": "WYrj",
	"./el": "jUeY",
	"./el.js": "jUeY",
	"./en-au": "Dmvi",
	"./en-au.js": "Dmvi",
	"./en-ca": "OIYi",
	"./en-ca.js": "OIYi",
	"./en-gb": "Oaa7",
	"./en-gb.js": "Oaa7",
	"./en-ie": "4dOw",
	"./en-ie.js": "4dOw",
	"./en-il": "czMo",
	"./en-il.js": "czMo",
	"./en-nz": "b1Dy",
	"./en-nz.js": "b1Dy",
	"./eo": "Zduo",
	"./eo.js": "Zduo",
	"./es": "iYuL",
	"./es-do": "CjzT",
	"./es-do.js": "CjzT",
	"./es-us": "Vclq",
	"./es-us.js": "Vclq",
	"./es.js": "iYuL",
	"./et": "7BjC",
	"./et.js": "7BjC",
	"./eu": "D/JM",
	"./eu.js": "D/JM",
	"./fa": "jfSC",
	"./fa.js": "jfSC",
	"./fi": "gekB",
	"./fi.js": "gekB",
	"./fo": "ByF4",
	"./fo.js": "ByF4",
	"./fr": "nyYc",
	"./fr-ca": "2fjn",
	"./fr-ca.js": "2fjn",
	"./fr-ch": "Dkky",
	"./fr-ch.js": "Dkky",
	"./fr.js": "nyYc",
	"./fy": "cRix",
	"./fy.js": "cRix",
	"./gd": "9rRi",
	"./gd.js": "9rRi",
	"./gl": "iEDd",
	"./gl.js": "iEDd",
	"./gom-latn": "DKr+",
	"./gom-latn.js": "DKr+",
	"./gu": "4MV3",
	"./gu.js": "4MV3",
	"./he": "x6pH",
	"./he.js": "x6pH",
	"./hi": "3E1r",
	"./hi.js": "3E1r",
	"./hr": "S6ln",
	"./hr.js": "S6ln",
	"./hu": "WxRl",
	"./hu.js": "WxRl",
	"./hy-am": "1rYy",
	"./hy-am.js": "1rYy",
	"./id": "UDhR",
	"./id.js": "UDhR",
	"./is": "BVg3",
	"./is.js": "BVg3",
	"./it": "bpih",
	"./it.js": "bpih",
	"./ja": "B55N",
	"./ja.js": "B55N",
	"./jv": "tUCv",
	"./jv.js": "tUCv",
	"./ka": "IBtZ",
	"./ka.js": "IBtZ",
	"./kk": "bXm7",
	"./kk.js": "bXm7",
	"./km": "6B0Y",
	"./km.js": "6B0Y",
	"./kn": "PpIw",
	"./kn.js": "PpIw",
	"./ko": "Ivi+",
	"./ko.js": "Ivi+",
	"./ky": "lgnt",
	"./ky.js": "lgnt",
	"./lb": "RAwQ",
	"./lb.js": "RAwQ",
	"./lo": "sp3z",
	"./lo.js": "sp3z",
	"./lt": "JvlW",
	"./lt.js": "JvlW",
	"./lv": "uXwI",
	"./lv.js": "uXwI",
	"./me": "KTz0",
	"./me.js": "KTz0",
	"./mi": "aIsn",
	"./mi.js": "aIsn",
	"./mk": "aQkU",
	"./mk.js": "aQkU",
	"./ml": "AvvY",
	"./ml.js": "AvvY",
	"./mn": "lYtQ",
	"./mn.js": "lYtQ",
	"./mr": "Ob0Z",
	"./mr.js": "Ob0Z",
	"./ms": "6+QB",
	"./ms-my": "ZAMP",
	"./ms-my.js": "ZAMP",
	"./ms.js": "6+QB",
	"./mt": "G0Uy",
	"./mt.js": "G0Uy",
	"./my": "honF",
	"./my.js": "honF",
	"./nb": "bOMt",
	"./nb.js": "bOMt",
	"./ne": "OjkT",
	"./ne.js": "OjkT",
	"./nl": "+s0g",
	"./nl-be": "2ykv",
	"./nl-be.js": "2ykv",
	"./nl.js": "+s0g",
	"./nn": "uEye",
	"./nn.js": "uEye",
	"./pa-in": "8/+R",
	"./pa-in.js": "8/+R",
	"./pl": "jVdC",
	"./pl.js": "jVdC",
	"./pt": "8mBD",
	"./pt-br": "0tRk",
	"./pt-br.js": "0tRk",
	"./pt.js": "8mBD",
	"./ro": "lyxo",
	"./ro.js": "lyxo",
	"./ru": "lXzo",
	"./ru.js": "lXzo",
	"./sd": "Z4QM",
	"./sd.js": "Z4QM",
	"./se": "//9w",
	"./se.js": "//9w",
	"./si": "7aV9",
	"./si.js": "7aV9",
	"./sk": "e+ae",
	"./sk.js": "e+ae",
	"./sl": "gVVK",
	"./sl.js": "gVVK",
	"./sq": "yPMs",
	"./sq.js": "yPMs",
	"./sr": "zx6S",
	"./sr-cyrl": "E+lV",
	"./sr-cyrl.js": "E+lV",
	"./sr.js": "zx6S",
	"./ss": "Ur1D",
	"./ss.js": "Ur1D",
	"./sv": "X709",
	"./sv.js": "X709",
	"./sw": "dNwA",
	"./sw.js": "dNwA",
	"./ta": "PeUW",
	"./ta.js": "PeUW",
	"./te": "XLvN",
	"./te.js": "XLvN",
	"./tet": "V2x9",
	"./tet.js": "V2x9",
	"./tg": "Oxv6",
	"./tg.js": "Oxv6",
	"./th": "EOgW",
	"./th.js": "EOgW",
	"./tl-ph": "Dzi0",
	"./tl-ph.js": "Dzi0",
	"./tlh": "z3Vd",
	"./tlh.js": "z3Vd",
	"./tr": "DoHr",
	"./tr.js": "DoHr",
	"./tzl": "z1FC",
	"./tzl.js": "z1FC",
	"./tzm": "wQk9",
	"./tzm-latn": "tT3J",
	"./tzm-latn.js": "tT3J",
	"./tzm.js": "wQk9",
	"./ug-cn": "YRex",
	"./ug-cn.js": "YRex",
	"./uk": "raLr",
	"./uk.js": "raLr",
	"./ur": "UpQW",
	"./ur.js": "UpQW",
	"./uz": "Loxo",
	"./uz-latn": "AQ68",
	"./uz-latn.js": "AQ68",
	"./uz.js": "Loxo",
	"./vi": "KSF8",
	"./vi.js": "KSF8",
	"./x-pseudo": "/X5v",
	"./x-pseudo.js": "/X5v",
	"./yo": "fzPg",
	"./yo.js": "fzPg",
	"./zh-cn": "XDpg",
	"./zh-cn.js": "XDpg",
	"./zh-hk": "SatO",
	"./zh-hk.js": "SatO",
	"./zh-tw": "kOpN",
	"./zh-tw.js": "kOpN"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) { // check for number or string
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return id;
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "RnhZ";

/***/ }),

/***/ "RtkB":
/*!*********************************!*\
  !*** ./src/lib/commands/cut.js ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Logger */ "GONd");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_2__["default"]('cut');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection);
  var commands = [];
  var undoManager = this.undoManager,
      data = this.data;
  undoManager.addUndoStack();
  commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
    selection: selection,
    value: ''
  }));
  this.execute('setValue', {
    selection: selection,
    value: '',
    sync: false,
    render: false,
    undoStack: false,
    undo: true
  });
  var cmds = [];
  cmds = this.execute('clearFormat', {
    selection: selection,
    sync: false,
    render: false,
    undoStack: false,
    undo: true
  });
  commands = commands.concat(cmds.commands);

  if (data.spans && data.spans.length) {
    Object(_util__WEBPACK_IMPORTED_MODULE_0__["each"])(data.spans || [], function (span) {
      var row = selection.row,
          col = selection.col,
          rowCount = selection.rowCount,
          colCount = selection.colCount,
          rowEnd = row + rowCount - 1,
          colEnd = col + colCount - 1;

      if (span.row >= row && span.row <= rowEnd && span.col >= col && span.col <= colEnd) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('merge', {
          selection: span,
          value: 0
        }));

        _this.executeCmds(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('merge', {
          selection: span,
          value: 0
        }), {
          sync: false,
          render: false,
          undoStack: false,
          undo: true
        });
      }
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "T0Tt":
/*!***********************!*\
  !*** ./src/api/at.js ***!
  \***********************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../store */ "Q2AE");


/* harmony default export */ __webpack_exports__["default"] = ({
  fetch: function fetch() {
    var _store$state$app = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        sid = _store$state$app.sid,
        mainKey = _store$state$app.mainKey;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/push/get_list",
      params: {
        docsid: sid,
        key: mainKey
      }
    });
  },
  getshortKey: function getshortKey() {
    var _store$state$app2 = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        sid = _store$state$app2.sid,
        mainKey = _store$state$app2.mainKey;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/api/getshortkey",
      params: {
        docsid: sid,
        key: mainKey
      }
    });
  },
  addCollaborator: function addCollaborator(docName, shortKey, collaboratorsInfo) {
    var _store$state$app3 = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        sid = _store$state$app3.sid,
        mainKey = _store$state$app3.mainKey,
        corpId = _store$state$app3.corpId,
        nickName = _store$state$app3.nickName;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/authority/add_recently?docsid=".concat(sid),
      traditional: true,
      data: {
        key: mainKey,
        corp_id: corpId,
        docName: docName,
        name: nickName,
        shortKey: shortKey,
        collaborators: collaboratorsInfo
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  },
  pushAtInfo: function pushAtInfo(userIds, mainCommentId, sheetId, docName, shortkey) {
    var _store$state$app4 = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        sid = _store$state$app4.sid,
        mainKey = _store$state$app4.mainKey,
        nickName = _store$state$app4.nickName;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/push/ww_comment_at?docsid=".concat(sid),
      traditional: true,
      data: {
        atUserIdList: userIds.join(','),
        mainId: mainCommentId,
        key: mainKey,
        commentFid: sheetId,
        docName: docName,
        name: nickName,
        shortKey: shortkey
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  }
});

/***/ }),

/***/ "T22h":
/*!***************************************!*\
  !*** ./src/lib/commands/setBorder.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "8e1d");

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      type = _ref.type,
      selection = _ref.selection,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var value = '1px solid rgb(0, 0, 0)';
  selection.row = selection.row < 0 ? 0 : selection.row;
  selection.col = selection.col < 0 ? 0 : selection.col;
  var undoManager = this.undoManager,
      worksheet = this.worksheet; // 添加栈

  if (undoStack) undoManager.addUndoStack(); // 添加命令到commands数组

  var commands = [];
  if (type === 'clear') value = '';
  var borderData = [];

  switch (type) {
    case 'all':
    case 'clear':
      borderData = getAllData(selection);
      break;

    case 'inner':
      borderData = getInnerData(selection);
      break;

    case 'outer':
      borderData = getOuterData(selection);
      break;
  }

  worksheet.suspendPaint();
  Object(_util__WEBPACK_IMPORTED_MODULE_0__["each"])(borderData, function (_ref2) {
    var row = _ref2.row,
        col = _ref2.col,
        type = _ref2.type;
    commands = commands.concat(_this.execute('setStyle', {
      selection: {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      },
      property: "border".concat(Object(_util__WEBPACK_IMPORTED_MODULE_0__["upperFirst"])(type)),
      value: value,
      render: render,
      sync: false,
      undoStack: false,
      subCmd: true,
      multiple: true,
      undo: undo
    }));
  });
  worksheet.resumePaint(); // 发送指令同步数据到远程

  if (sync) this.sendCmds(commands);
  return commands;
});

function getAllData(selection) {
  return getOuterData(selection).concat(getInnerData(selection));
}

function getInnerData(selection) {
  var ret = [];
  var row = selection.row,
      col = selection.col,
      rowCount = selection.rowCount,
      colCount = selection.colCount;
  var start = {
    row: row,
    col: col
  },
      end = {
    row: row + rowCount - 1,
    col: col + colCount - 1
  };
  Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
    if (row !== start.row) {
      ret.push({
        row: row,
        col: col,
        type: 'top'
      });
    }

    if (row !== end.row) {
      ret.push({
        row: row,
        col: col,
        type: 'bottom'
      });
    }

    if (col !== start.col) {
      ret.push({
        row: row,
        col: col,
        type: 'left'
      });
    }

    if (col !== end.col) {
      ret.push({
        row: row,
        col: col,
        type: 'right'
      });
    }
  });
  return ret;
}

function getOuterData(selection) {
  var ret = [];
  var row = selection.row,
      col = selection.col,
      rowCount = selection.rowCount,
      colCount = selection.colCount;
  var start = {
    row: row,
    col: col
  },
      end = {
    row: row + rowCount - 1,
    col: col + colCount - 1
  };
  Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
    if (row === start.row) {
      ret.push({
        row: row,
        col: col,
        type: 'top'
      });
    }

    if (row === end.row) {
      ret.push({
        row: row,
        col: col,
        type: 'bottom'
      });
    }

    if (col === start.col) {
      ret.push({
        row: row,
        col: col,
        type: 'left'
      });
    }

    if (col === end.col) {
      ret.push({
        row: row,
        col: col,
        type: 'right'
      });
    }
  });
  return ret;
}

/***/ }),

/***/ "TzrH":
/*!****************************************!*\
  !*** ./src/lib/commands/setFormula.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Logger */ "GONd");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_2__["default"]('setFormula');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection, value);
  var undoManager = this.undoManager; // 添加栈

  if (undoStack) undoManager.addUndoStack(); // 添加命令到commands/undoCmds数组

  var commands = [];
  var undoCmds = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setFormula', {
    selection: selection,
    value: value
  })); // 渲染数据到当前sheet

  if (render) {
    Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
      _this.worksheet.setFormula(row, col, value !== 'undefined' ? value : undefined);
    });
  } // 添加命令到undoCmds 支持撤销操作


  if (undo) {
    undoCmds = this.execute('deleteValue', {
      selection: selection,
      undoStack: false,
      undo: false,
      sync: false
    });
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  } // 发送指令同步数据到远程


  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "UajC":
/*!*************************!*\
  !*** ./src/api/view.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../store */ "Q2AE");


/* harmony default export */ __webpack_exports__["default"] = ({
  fetch: function fetch(sheetId) {
    var _store$state$app = _store__WEBPACK_IMPORTED_MODULE_1__["default"].state.app,
        mainKey = _store$state$app.mainKey,
        sid = _store$state$app.sid;
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: "/docs/e/".concat(mainKey),
      params: {
        docsid: sid,
        op: 'view',
        rendertype: 'json',
        doc_sheetid: sheetId
      }
    });
  }
});

/***/ }),

/***/ "VF69":
/*!*****************************************!*\
  !*** ./src/lib/commands/dragFilling.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../config */ "Gh6Q");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");


/* harmony default export */ __webpack_exports__["default"] = (function (_ref) {
  var selection = _ref.selection;
  // 添加命令到undoCmds数组
  var undoCmds = []; // 自动填充撤销命令

  undoCmds = undoCmds.concat(this.execute('setAll', {
    selection: selection,
    value: this.getRangeData(selection),
    sync: false
  })); // 清除值撤销命令

  undoCmds = undoCmds.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
    selection: selection,
    value: ''
  })); // 清除格式撤销命令

  for (var key in _config__WEBPACK_IMPORTED_MODULE_0__["clearConfig"]) {
    undoCmds = undoCmds.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setStyle', {
      selection: selection,
      property: key,
      value: _config__WEBPACK_IMPORTED_MODULE_0__["clearConfig"][key]
    }));
  }

  return undoCmds;
});

/***/ }),

/***/ "YXv6":
/*!***********************************!*\
  !*** ./src/lib/commands/merge.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/objectSpread */ "yT7P");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../util.js */ "8e1d");




var logger = new _Logger__WEBPACK_IMPORTED_MODULE_1__["default"]('merge');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$clear = _ref.clear,
      clear = _ref$clear === void 0 ? false : _ref$clear,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(selection, value);
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data; // 若清除格式操作，则在clearFormat.js里添加栈；否则，直接在此添加栈

  if (undoStack && !clear) undoManager.addUndoStack(); // 添加命令到commands/undoCmds数组

  var commands = [];
  var undoCmds = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
    selection: selection,
    value: value
  }));
  var row = selection.row,
      col = selection.col,
      rowCount = selection.rowCount,
      colCount = selection.colCount; // 渲染数据到当前sheet

  if (render) {
    if (value) {
      try {
        worksheet.addSpan(row, col, rowCount, colCount);
      } catch (err) {
        logger.debug("err catch in merge: ", err, this);
        window.showHeaderAlert('提示', '您选择的范围里包含已经合并的单元格，请先取消合并', ['确定'], function () {});
        undoManager.undo();
        return;
      }
    } else {
      worksheet.removeSpan(row, col);
    }
  } // 添加命令到undoCmds 支持撤销操作


  if (undo) {
    if (value) {
      // 在多个合并单元格嵌套中，还原上一次的单元格的指令压栈的顺序必须在unmerge之前，不然会报错
      var spans = Object(_util_js__WEBPACK_IMPORTED_MODULE_3__["getMergeCellList"])(selection, data.spans);
      Object(_util_js__WEBPACK_IMPORTED_MODULE_3__["each"])(spans, function (span) {
        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
          selection: Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_0__["default"])({}, span),
          value: 1
        }));
      });
    }

    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
      selection: selection,
      value: value ? 0 : 1
    })); // 若清除格式操作，则在clearFormat.js里将所有指令合并后再压栈；否则，直接压栈

    if (!clear) {
      undoManager.addUndo({
        commands: commands,
        undoCmds: undoCmds
      });
    }
  } // 若清除格式操作，则在clearFormat.js里发送指令同步数据到远程；否则，直接在此发送


  if (!clear) {
    if (sync) this.sendCmds(commands);
  }

  return {
    commands: commands,
    undoCmds: undoCmds
  };
});

/***/ }),

/***/ "Yrf8":
/*!*************************************!*\
  !*** ./src/store/modules/spread.js ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/defineProperty */ "oyJW");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mutationTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../mutationTypes */ "NPqI");
/* harmony import */ var _lib_util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/util */ "8e1d");



var _mutations;



/* harmony default export */ __webpack_exports__["default"] = ({
  state: {
    sheets: [],
    updateSheets: [],
    status: '',
    value: '',
    activeSheet: {}
  },
  getters: {},
  mutations: (_mutations = {}, Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].INIT_SHEETS, function (state, _ref) {
    var sheets = _ref.sheets;
    state.sheets = sheets;
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].ADD_SHEET, function (state, _ref2) {
    var sheet = _ref2.sheet;
    state.sheets.push(sheet);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].DELETE_SHEET, function (state, _ref3) {
    var index = _ref3.index;
    state.sheets.splice(index, 1);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_SHEET, function (state, payload) {
    var sheets = state.sheets;
    var sheetId = payload.sheetId;
    Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["each"])(sheets, function (sheet) {
      if (sheet.sheetId === sheetId) {
        Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["extend"])(sheet, payload);
      }
    });
    state.sheets = Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["cloneDeep"])(sheets);
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_SHEETS, function (state, _ref4) {
    var sheets = _ref4.sheets;
    state.updateSheets = sheets;
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].SET_ACTIVE_SHEET, function (state, _ref5) {
    var sheetId = _ref5.sheetId;
    Object(_lib_util__WEBPACK_IMPORTED_MODULE_3__["each"])(state.sheets, function (sheet) {
      if (sheet.sheetId == sheetId) state.activeSheet = sheet;
    });
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_STATUS, function (state, _ref6) {
    var status = _ref6.status;
    state.status = status;
  }), Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(_mutations, _mutationTypes__WEBPACK_IMPORTED_MODULE_2__["default"].UPDATE_CELL_VALUE, function (state, _ref7) {
    var value = _ref7.value;
    state.value = value || '';
  }), _mutations),
  actions: {}
});

/***/ }),

/***/ "ZqfF":
/*!*******************************************!*\
  !*** ./src/lib/changeset/CmdStrParser.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return CmdStrParser; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _IndexInfo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./IndexInfo */ "Eaqo");
/* harmony import */ var _PosInfo__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./PosInfo */ "Lt7s");



 // 命令行的解析器

var CmdStrParser =
/*#__PURE__*/
function () {
  function CmdStrParser(cmdStr) {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, CmdStrParser);

    this.cmdStr = cmdStr;
    this.pos = 0;
    this.delimiter = ' ';
    this.lineEnd = cmdStr.indexOf('\n');

    if (this.lineEnd < 0) {
      this.lineEnd = cmdStr.length;
    }
  } // 取出指令里面的每一个子元素


  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(CmdStrParser, [{
    key: "NextToken",
    value: function NextToken() {
      if (this.pos < 0) {
        return '';
      }

      var pos2 = this.cmdStr.indexOf(this.delimiter, this.pos);
      var pos1 = this.pos;

      if (pos2 > this.lineEnd) {
        pos2 = this.lineEnd;
      }

      if (pos2 >= 0) {
        this.pos = pos2 + 1;
        return this.cmdStr.substring(pos1, pos2);
      } else {
        this.pos = this.lineEnd;
        return this.cmdStr.substring(pos1, this.lineEnd);
      }
    }
  }, {
    key: "RestOfString",
    value: function RestOfString() {
      var oldpos = this.pos;

      if (this.pos < 0 || this.pos >= this.lineEnd) {
        return '';
      }

      this.pos = this.lineEnd;
      return this.cmdStr.substring(oldpos, this.lineEnd);
    }
  }, {
    key: "RestOfStringNoMove",
    value: function RestOfStringNoMove() {
      if (this.pos < 0 || this.pos >= this.lineEnd) return '';
      return this.cmdStr.substring(this.pos, this.lineEnd);
    }
  }, {
    key: "NextLine",
    value: function NextLine() {
      this.pos = this.lineEnd + 1;
      this.lineEnd = this.cmdStr.indexOf('\n', this.pos);

      if (this.lineEnd < 0) {
        this.lineEnd = this.cmdStr.length;
      }
    }
  }, {
    key: "EOF",
    value: function EOF() {
      if (this.pos < 0 || this.pos >= this.cmdStr.length) return true;
      return false;
    }
    /* 将一个坐标转为数值坐标
     * 例如：A5  是第一列第5行。  row:5 col:1
     * 36是$符号
     * 48-57数字0-9
     * 97-122 小写a-z
     * 65-90 大写A-Z
     */

  }], [{
    key: "coordToColRow",
    value: function coordToColRow(cr) {
      var c, i, ch;
      var r = CmdStrParser.coordToRow[cr];
      if (r) return {
        row: r,
        col: CmdStrParser.coordToCol[cr]
      };
      c = 0;
      r = 0;

      for (i = 0; i < cr.length; i++) {
        ch = cr.charCodeAt(i); // if (ch === 36) {
        // } else if (ch <= 57) {

        if (ch <= 57) {
          r = 10 * r + ch - 48;
        } else if (ch >= 97) {
          c = 26 * c + ch - 96;
        } else if (ch >= 65) {
          c = 26 * c + ch - 64;
        }
      }

      CmdStrParser.coordToCol[cr] = c;
      CmdStrParser.coordToRow[cr] = r;
      return {
        row: r,
        col: c
      };
    }
  }, {
    key: "crToCoord",
    value: function crToCoord(c, r) {
      var result;
      if (c < 1) c = 1;
      if (c > 702) c = 702; // maximum number of columns - ZZ

      if (r < 1) r = 1;
      var collow = (c - 1) % 26;
      var colhigh = Math.floor((c - 1) / 26);
      if (colhigh) result = CmdStrParser.letters[colhigh - 1] + CmdStrParser.letters[collow] + r;else result = CmdStrParser.letters[collow] + r;
      return result;
    } // 将数值坐标转成row类型的游标对象

  }, {
    key: "RangeTorow",
    value: function RangeTorow(cr) {
      var tmp = new _IndexInfo__WEBPACK_IMPORTED_MODULE_2__["default"]();
      tmp.index = cr.row;
      return tmp;
    } // 将数值坐标转成col类型的游标对象

  }, {
    key: "RangeTocol",
    value: function RangeTocol(cr) {
      var tmp = new _IndexInfo__WEBPACK_IMPORTED_MODULE_2__["default"]();
      tmp.index = cr.col;
      return tmp;
    } // 将数值坐标转换为位置坐标

  }, {
    key: "ColRowToPos",
    value: function ColRowToPos(cr) {
      var posInfoBR = new _PosInfo__WEBPACK_IMPORTED_MODULE_3__["default"]();
      posInfoBR.row = CmdStrParser.RangeTorow(cr);
      posInfoBR.col = CmdStrParser.RangeTocol(cr);
      return posInfoBR;
    } // 将两个数值坐标转换成数组
    // TL is top-left, BR is bottom-right

  }, {
    key: "CrsToPosArr",
    value: function CrsToPosArr(crTL, crBR) {
      var arrRet = [];
      arrRet.push(CmdStrParser.ColRowToPos(crTL));

      if (crBR && (crBR.row !== crTL.row || crBR.col !== crTL.col)) {
        arrRet.push(CmdStrParser.ColRowToPos(crBR));
      }

      return arrRet;
    } // 根据range的两个点，返回arrRet
    // range相当于是一个矩形的选取

  }, {
    key: "RangeToPosArr",
    value: function RangeToPosArr(range) {
      return CmdStrParser.CrsToPosArr(range.cr1, range.cr2);
    } // 返回index1到index2区间的范围转成游标数组

  }, {
    key: "RangeToColArr",
    value: function RangeToColArr(index1, index2) {
      var arrRet = [];
      index2 = index2 < index1 ? index1 : index2;

      for (var i = index1; i < index2; ++i) {
        var indexInfo = new _IndexInfo__WEBPACK_IMPORTED_MODULE_2__["default"]();
        indexInfo.index = i;
        var posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_3__["default"]();
        posInfo.col = indexInfo;
        arrRet.push(posInfo);
      }

      return arrRet;
    } // 返回index1到index2区间的行信息转成游标数组

  }, {
    key: "RangeToRowArr",
    value: function RangeToRowArr(index1, index2) {
      var arrRet = [];
      if (index2 < index1) index2 = index1;

      for (var i = index1; i < index2; ++i) {
        var indexInfo = new _IndexInfo__WEBPACK_IMPORTED_MODULE_2__["default"]();
        indexInfo.index = i;
        var posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_3__["default"]();
        posInfo.row = indexInfo;
        arrRet.push(posInfo);
      }

      return arrRet;
    } // 将一个指令坐标 A1:B2 转换为数值坐标

  }, {
    key: "ParseRange",
    value: function ParseRange(range) {
      var pos, cr, cr1, cr2;
      if (!range) range = 'A1:A1';
      range = range.toUpperCase();
      pos = range.indexOf(':');

      if (pos >= 0) {
        cr = range.substring(0, pos);
        cr1 = CmdStrParser.coordToColRow(cr);
        cr1.coord = cr;
        cr = range.substring(pos + 1);
        cr2 = CmdStrParser.coordToColRow(cr);
        cr2.coord = cr;
      } else {
        cr1 = CmdStrParser.coordToColRow(range);
        cr1.coord = range;
        cr2 = CmdStrParser.coordToColRow(range);
        cr2.coord = range;
      }

      return {
        cr1: cr1,
        cr2: cr2
      };
    }
  }]);

  return CmdStrParser;
}();


CmdStrParser.coordToCol = {};
CmdStrParser.coordToRow = {};
CmdStrParser.letters = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

/***/ }),

/***/ "aFx9":
/*!**************************!*\
  !*** ./src/api/image.js ***!
  \**************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");

/* harmony default export */ __webpack_exports__["default"] = ({
  uploadImage: function uploadImage(base64data) {
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: "/docs/api/uploadBase64Image",
      traditional: true,
      data: {
        base64data: base64data
      },
      transformRequest: [function (data) {
        var ret = '';

        for (var it in data) {
          ret += encodeURIComponent(it) + '=' + encodeURIComponent(data[it]) + '&';
        }

        return ret;
      }],
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
  }
});

/***/ }),

/***/ "bN5d":
/*!*******************************!*\
  !*** ./src/lib/Connection.js ***!
  \*******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Connection; });
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.function.name */ "f3/d");
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/slicedToArray */ "k5N+");
/* harmony import */ var core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.array.find-index */ "INYr");
/* harmony import */ var core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/objectSpread */ "yT7P");
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! regenerator-runtime/runtime */ "ls82");
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/asyncToGenerator */ "MECJ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_inherits__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/inherits */ "3Aqn");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/possibleConstructorReturn */ "0yhX");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_getPrototypeOf__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/getPrototypeOf */ "EdlT");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../store */ "Q2AE");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Constants */ "Eo9w");
/* harmony import */ var _store_mutationTypes__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../store/mutationTypes */ "NPqI");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./util */ "8e1d");
/* harmony import */ var _report__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./report */ "nBop");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./Logger */ "GONd");

















 // 消息连接时间

var CONNECT_TIME_OUT = 10000;
var MAX_RECONNECT_RETRIES = 3;
var logger = new _Logger__WEBPACK_IMPORTED_MODULE_17__["default"]("connection");

var Connection =
/*#__PURE__*/
function (_Emitter) {
  function Connection() {
    var _this;

    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_6__["default"])(this, Connection);

    _this = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_9__["default"])(this, Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_getPrototypeOf__WEBPACK_IMPORTED_MODULE_10__["default"])(Connection).call(this));
    var _store$state$app = _store__WEBPACK_IMPORTED_MODULE_12__["default"].state.app,
        vid = _store$state$app.vid,
        mainKey = _store$state$app.mainKey,
        key = _store$state$app.key;
    _this.sessionID = "".concat(vid, ".").concat(mainKey, ".").concat(+new Date());
    _this.socketUrl = "wss://doc.qmail.com/websocket?".concat(vid, "_").concat(key);
    _this.messageId = 0;
    _this.requests = [];
    _this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED; // 错误重连以及上报机制

    _this.retries = 0;
    _this.connectTimer = null;
    _this.connectionTiming = null;
    _this.notificationHandlers = {
      '0': _this.onNotifyOnline,
      '1': _this.onNotifyOnline,
      '2': _this.onNotifyOnline,
      '3': _this.onNotifyDelete,
      '4': _this.onNotifyAuthority
    };

    _this.setupBaseMsg();

    window.WeDocs.on('update', function () {
      _this.setupBaseMsg();

      _this.reconnect();

      window.WeDocs.emit('updateSocketConnect', true);
    });
    return _this;
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_8__["default"])(Connection, [{
    key: "setupBaseMsg",
    value: function setupBaseMsg() {
      var _store$state$app2 = _store__WEBPACK_IMPORTED_MODULE_12__["default"].state.app,
          fileType = _store$state$app2.fileType,
          docskey = _store$state$app2.docskey,
          sid = _store$state$app2.sid,
          vid = _store$state$app2.vid,
          mainKey = _store$state$app2.mainKey;
      this.baseMsg = {
        fileType: fileType,
        docskey: docskey,
        docsid: sid,
        vid: vid,
        room: mainKey,
        sessionID: this.sessionID
      };
      _store__WEBPACK_IMPORTED_MODULE_12__["default"].commit({
        type: _store_mutationTypes__WEBPACK_IMPORTED_MODULE_14__["default"].UPDATE_BASE_MSG,
        baseMsg: this.baseMsg
      });
    }
  }, {
    key: "connect",
    value: function connect() {
      var _this2 = this;

      if (this.state !== _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED) return;
      this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CONNECTING;
      var socket = new WebSocket(this.socketUrl);

      socket.onopen = function () {
        return _this2.onSocketOpen.apply(_this2, arguments);
      };

      socket.onmessage = function () {
        return _this2.onSocketMessage.apply(_this2, arguments);
      };

      socket.onerror = function () {
        return _this2.onSocketError.apply(_this2, arguments);
      };

      socket.onclose = function () {
        return _this2.onSocketClose.apply(_this2, arguments);
      };

      this.socket = socket;
      this.connectTimer = setTimeout(function () {
        _this2.emit('socket-connection-timeout');

        _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_socket_timeout', true);
      }, CONNECT_TIME_OUT);
      this.connectionTiming = _report__WEBPACK_IMPORTED_MODULE_16__["default"].assertTime({
        'socket-open': 78501893,
        'openResume:max': [':start'],
        'connection-ready': 78501894,
        'connection-ready:max': ['socket-open']
      });
    }
  }, {
    key: "reconnect",
    value: function reconnect() {
      if (this.state === _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED) {
        return this.connect();
      }

      this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].RECONNECTING;
      this.socket.close();
      this.onSocketClose();
    }
  }, {
    key: "disconnect",
    value: function disconnect() {
      if (this.state === _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED) {
        return;
      }

      this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSING;
      this.socket.close();
      this.onSocketClose();
    }
  }, {
    key: "request",
    value: function () {
      var _request = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_5__["default"])(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee(type) {
        var _this3 = this;

        var data,
            msgID,
            msg,
            _args = arguments;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                data = _args.length > 1 && _args[1] !== undefined ? _args[1] : {};
                msgID = this.messageId++;
                msg = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_objectSpread__WEBPACK_IMPORTED_MODULE_3__["default"])({}, this.baseMsg, {
                  type: type,
                  msgID: msgID,
                  data: data
                });
                logger.debug(msg);
                return _context.abrupt("return", new Promise(function (resolve, reject) {
                  var request = {
                    msgID: msgID,
                    msg: msg,
                    resolve: resolve,
                    reject: reject
                  };

                  _this3.requests.push(request);

                  if (!_this3.socket || _this3.socket.readyState !== WebSocket.OPEN) return;

                  _this3.socket.send(encodeMsg(msg));

                  request.isSend = true;
                }));

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function request(_x) {
        return _request.apply(this, arguments);
      };
    }()
  }, {
    key: "onSocketOpen",
    value: function onSocketOpen() {
      this.request('hello');
      this.connectTimer && clearTimeout(this.connectTimer); // 上报

      this.connectionTiming('socket-open');
    }
  }, {
    key: "onSocketMessage",
    value: function onSocketMessage(event) {
      var _this4 = this;

      Object(_util__WEBPACK_IMPORTED_MODULE_15__["each"])(this.requests, function (request) {
        if (!request.isSend) {
          _this4.socket.send(encodeMsg(request.msg));

          request.isSend = true;
        }
      });
      var msg = JSON.parse(event.data);

      if (Object(_util__WEBPACK_IMPORTED_MODULE_15__["safeGet"])(msg, 'result.errCode')) {
        return this.emit('error-received', msg);
      }

      if (Object(_util__WEBPACK_IMPORTED_MODULE_15__["safeGet"])(msg, 'data.spam')) {
        return this.emit('spam-detected', msg);
      }

      if (msg.type === 'hello') {
        this.onConnectionReady();
      }

      if (msg.type) {
        this.emit('event-received', msg);
        this.emit("event-received:".concat(msg.type), msg);
      }

      if (!Object(_util__WEBPACK_IMPORTED_MODULE_15__["isUndef"])(msg.msgID)) {
        return this.onMessageRespond(msg);
      }

      if (msg.type) return;

      if (!msg.content) {
        return this.emit('message-unhandled', msg);
      }

      if (this.notificationHandlers[msg.content.type]) {
        return this.notificationHandlers[msg.content.type].call(this, msg);
      }

      this.emit('message-unhandled', msg);
    }
  }, {
    key: "onConnectionReady",
    value: function onConnectionReady() {
      this.connectionTiming('connection-ready');
      this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].OPEN;
      this.retries = 0;
      this.emit('connection-ready');
    }
  }, {
    key: "onMessageRespond",
    value: function onMessageRespond(msg) {
      var index = this.requests.findIndex(function (request) {
        return request.msgID === msg.msgID;
      });
      if (index < 0) return;

      var _this$requests$splice = this.requests.splice(index, 1),
          _this$requests$splice2 = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_this$requests$splice, 1),
          request = _this$requests$splice2[0];

      if (msg.error) return request.reject(msg);
      request.resolve(msg);
    }
  }, {
    key: "onNotifyOnline",
    value: function onNotifyOnline(msg) {
      var users = msg.content.online.users;
      this.emit('notify-online', {
        users: users
      });
    }
  }, {
    key: "onSendmsgError",
    value: function onSendmsgError() {
      this.emit('sendmsg-error');
    }
  }, {
    key: "onWaitConnect",
    value: function onWaitConnect() {
      this.emit('waiting-connect');
    } // 文档删除

  }, {
    key: "onNotifyDelete",
    value: function onNotifyDelete(msg) {
      logger.debug("onNotifyDelete", msg);
      var authorName = msg.content.deldata.name;
      this.emit('notify-delete', {
        authorName: authorName
      });
    } // 权限变更

  }, {
    key: "onNotifyAuthority",
    value: function onNotifyAuthority(msg) {
      logger.debug(msg);
      var authorityType = msg.content.authdata.authoritytype;
      var authorName = msg.content.authdata.name;
      this.emit('notify-authority', {
        authorityType: authorityType,
        authorName: authorName
      });
    }
  }, {
    key: "onSocketError",
    value: function onSocketError() {
      this.emit('connection-error');
      var key = _store__WEBPACK_IMPORTED_MODULE_12__["default"].state.app.key;
      _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_socket_state_error', true);
      _report__WEBPACK_IMPORTED_MODULE_16__["default"].log({
        type: 'socketError',
        fileId: key,
        retry: this.retries,
        browser: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectBrowser"])(),
        os: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectOs"])(),
        isSupportSocket: !!window.WebSocket
      });
      this.checkIsCanConnectOtherWebSocket();
    }
  }, {
    key: "onSocketClose",
    value: function onSocketClose(event) {
      if (!this.socket) {
        return;
      }

      this.socket = this.socket.onopen = this.socket.onmessage = this.socket.onerror = this.socket.onclose = null;

      if (this.state === _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSING) {
        return this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED;
      }

      this.state = _Constants__WEBPACK_IMPORTED_MODULE_13__["CONNECTION_STATE"].CLOSED;

      if (event && event.code) {
        _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_connection_closed_' + event.code, true);
      }

      if (this.retries >= MAX_RECONNECT_RETRIES) {
        var key = _store__WEBPACK_IMPORTED_MODULE_12__["default"].state.app.key;

        if (window.spread.getActiveSheet().id === key) {
          this.emit('connection-error');
          _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_socket_state_closed_3', true);
        }

        return;
      }

      this.retries += 1;
      this.reconnect();
      _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_socket_state_closed', true);
    }
  }, {
    key: "checkIsCanConnectOtherWebSocket",
    value: function checkIsCanConnectOtherWebSocket() {
      var socket = new WebSocket('wss://ltodanmaku.qiecdn.com/socket.io/?debug=false&EIO=3&transport=websocket');
      var key = _store__WEBPACK_IMPORTED_MODULE_12__["default"].state.app.key;

      socket.onopen = function () {
        _report__WEBPACK_IMPORTED_MODULE_16__["default"].log({
          type: 'socketVqqOpen',
          fileId: key,
          browser: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectBrowser"])(),
          os: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectOs"])()
        });
        _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_vqq_socket_state_open', true);
      };

      socket.onerror = function () {
        _report__WEBPACK_IMPORTED_MODULE_16__["default"].log({
          type: 'socketVqqError',
          fileId: key,
          browser: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectBrowser"])(),
          os: Object(_util__WEBPACK_IMPORTED_MODULE_15__["detectOs"])()
        });
        _report__WEBPACK_IMPORTED_MODULE_16__["default"].u('excel_err_vqq_socket_state_error', true);
      };
    }
  }]);

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_inherits__WEBPACK_IMPORTED_MODULE_7__["default"])(Connection, _Emitter);

  return Connection;
}(_util__WEBPACK_IMPORTED_MODULE_15__["Emitter"]);



function encodeMsg(msg) {
  return encodeURIComponent(JSON.stringify(msg));
}

/***/ }),

/***/ "bVzj":
/*!***************************************!*\
  !*** ./src/lib/plugins/comment/At.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return At; });
/* harmony import */ var core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.array.find-index */ "INYr");
/* harmony import */ var core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_find_index__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.array.sort */ "Vd3H");
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es6_array_find__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es6.array.find */ "dRSK");
/* harmony import */ var core_js_modules_es6_array_find__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_find__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/es6.function.name */ "f3/d");
/* harmony import */ var core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_function_name__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! regenerator-runtime/runtime */ "ls82");
/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/asyncToGenerator */ "MECJ");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! core-js/modules/es6.regexp.replace */ "pIFo");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _api_at__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../../api/at */ "T0Tt");
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../emitter */ "oj7Y");














var At =
/*#__PURE__*/
function () {
  function At() {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_9__["default"])(this, At);

    this.recentAtPos = null;
    this.curNodeIdx = null;
    this.curCursorPos = null;
    this.atPanelShow = false;
    this.personIndex = 0; // 初始文档协作者列表

    this.originDocList = []; // 初始最近协作者列表

    this.originRecentList = []; // 文档协作者列表

    this.docPersonList = []; // 最近协作者列表

    this.recentPersonList = [];
    this.loadContactTimeStamp = 0;
    this.commentInputText = null;
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_10__["default"])(At, [{
    key: "listenInputTarget",
    value: function listenInputTarget(commentInputText) {
      var selection = window.getSelection().getRangeAt(0);
      this.curCursorPos = selection.endOffset;
      this.curNodeIdx = this.getCurNodeIdx(selection.endContainer, commentInputText);
    }
  }, {
    key: "getCurNodeIdx",
    value: function getCurNodeIdx(endContainer, commentInputText) {
      var childNodes = commentInputText.childNodes;

      for (var i = 0, len = childNodes.length; i < len; i++) {
        if (childNodes[i] === endContainer) {
          return i;
        }
      }
    }
  }, {
    key: "handleIconURL",
    value: function handleIconURL(iconURL) {
      if (!iconURL) {
        return '';
      } // 后台拿到的是头像的原图，大小过大，不适合用于展示


      return iconURL.replace(/\/\d$/, '/100');
    }
  }, {
    key: "isChineseStr",
    value: function isChineseStr(temp) {
      if (/.*[\u4e00-\u9fa5]+.*$/.test(temp)) {
        return false;
      } else {
        return true;
      }
    }
  }, {
    key: "moveCursor",
    value: function moveCursor(pos, len) {
      var input = this.commentInputText;
      var range = null;
      var selection = null;
      var content = input;
      range = document.createRange();
      range.selectNodeContents(content);
      range.setStart(pos, len);
      range.collapse(!0);
      selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
    }
  }, {
    key: "displayFileName",
    value: function displayFileName(fileName) {
      var result = /^([\s\S]+)\.(\w+)$/.exec(fileName);
      return result && result.length > 1 ? result[1] : fileName;
    }
  }, {
    key: "addCollaborators",
    value: function () {
      var _addCollaborators = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__["default"])(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee(person) {
        var collaborators, docName, shortKeyResponse, res;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                collaborators = "".concat(person.vid, ",,").concat(person.name, ",,").concat(person.userId || '', ",20,,");
                docName = this.displayFileName(window.settings.fileName);

                if (this.shortkey) {
                  _context.next = 7;
                  break;
                }

                _context.next = 5;
                return _api_at__WEBPACK_IMPORTED_MODULE_11__["default"].getshortKey();

              case 5:
                shortKeyResponse = _context.sent;
                this.shortkey = shortKeyResponse.data.shortkey;

              case 7:
                _context.next = 9;
                return _api_at__WEBPACK_IMPORTED_MODULE_11__["default"].addCollaborator(docName, this.shortkey, collaborators);

              case 9:
                res = _context.sent;
                return _context.abrupt("return", res);

              case 11:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function addCollaborators(_x) {
        return _addCollaborators.apply(this, arguments);
      };
    }()
  }, {
    key: "pushAtInfo",
    value: function () {
      var _pushAtInfo = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__["default"])(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee2(Vid, mainCommentId, sheetId, atVids) {
        var _this = this;

        var curPersonList, userIds, docName, shortKeyResponse, res;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                curPersonList = atVids;
                userIds = curPersonList.filter(function (vid) {
                  return vid !== Vid;
                }).map(function (vid) {
                  return _this.docPersonList.concat(_this.recentPersonList).find(function (collaborator) {
                    return collaborator.vid === vid;
                  });
                }).map(function (collaborator) {
                  return collaborator.userId || '';
                });
                docName = this.displayFileName(window.settings.fileName);

                if (this.shortkey) {
                  _context2.next = 8;
                  break;
                }

                _context2.next = 6;
                return _api_at__WEBPACK_IMPORTED_MODULE_11__["default"].getshortKey();

              case 6:
                shortKeyResponse = _context2.sent;
                this.shortkey = shortKeyResponse.data.shortkey;

              case 8:
                _context2.next = 10;
                return _api_at__WEBPACK_IMPORTED_MODULE_11__["default"].pushAtInfo(userIds, mainCommentId, sheetId, docName, this.shortkey);

              case 10:
                res = _context2.sent;
                return _context2.abrupt("return", res);

              case 12:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function pushAtInfo(_x2, _x3, _x4, _x5) {
        return _pushAtInfo.apply(this, arguments);
      };
    }()
  }, {
    key: "addInputValue",
    value: function addInputValue(person, index) {
      var personName = person.englishName ? person.englishName + '(' + person.name + ')' : person.name;

      if (person && this.commentInputText && !index) {
        var input = this.commentInputText;
        input.focus();
        var lastNode = input.childNodes[this.curNodeIdx];
        var nextNode = lastNode.nextSibling;
        var value = lastNode.nodeValue;
        var atPos = value.lastIndexOf('@');
        var leftText = value.slice(0, atPos);
        var rightText = value.slice(this.curCursorPos);
        var leftNode = document.createTextNode(leftText + ' ');
        var rightNode = document.createTextNode(' ' + rightText);
        var atNode = document.createElement('span');
        atNode.setAttribute('contenteditable', 'false');
        atNode.setAttribute('class', 'od_editor_atTarget');
        atNode.setAttribute('data-personvid', person.vid);
        atNode.setAttribute('data-isCollaborator', person.isCollaborator);
        atNode.setAttribute('data-userId', person.userId);
        atNode.innerText = '@' + personName;
        input.insertBefore(leftNode, nextNode);
        input.insertBefore(atNode, nextNode);
        input.insertBefore(rightNode, nextNode);
        input.removeChild(lastNode);
        this.moveCursor(rightNode, 1);
        this.hideAtPanel();
      } else if (person && this.commentInputText && index) {
        var _input = this.commentInputText;

        _input.focus();

        var _lastNode = _input.childNodes[this.curNodeIdx];
        var _nextNode = _lastNode.nextSibling;
        var _value = _lastNode.nodeValue;

        var _atPos = _value.lastIndexOf('@');

        var _leftText = _value.slice(0, _atPos);

        var _rightText = _value.slice(this.curCursorPos);

        var _leftNode = document.createTextNode(_leftText + '@' + personName);

        var _rightNode = document.createTextNode(' ' + _rightText);

        _input.insertBefore(_leftNode, _nextNode);

        _input.insertBefore(_rightNode, _nextNode);

        _input.removeChild(_lastNode);

        this.moveCursor(_rightNode, 1);
        this.hideAtPanel();
      }
    }
  }, {
    key: "getPersonList",
    value: function () {
      var _getPersonList = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__["default"])(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee3(force) {
        var _this2 = this;

        var now, result, resultList;
        return regeneratorRuntime.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                now = Date.now() / 1000 | 0;

                if (!(force || now - this.loadContactTimeStamp > 300)) {
                  _context3.next = 9;
                  break;
                }

                this.loadContactTimeStamp = now;
                this.docPersonList = [];
                this.recentPersonList = [];
                _context3.next = 7;
                return _api_at__WEBPACK_IMPORTED_MODULE_11__["default"].fetch();

              case 7:
                result = _context3.sent;

                if (result.data && result.data.list && result.data.list.length) {
                  resultList = result.data.list;
                  resultList.forEach(function (collaborator) {
                    if (collaborator.isCollaborator) {
                      _this2.docPersonList.push({
                        iconUrl: _this2.handleIconURL(collaborator.iconUrl),
                        name: collaborator.name,
                        englishName: collaborator.englishName,
                        vid: collaborator.vid,
                        quanpin: collaborator.quanpin,
                        isAuthor: collaborator.isAuthor,
                        isCollaborator: collaborator.isCollaborator,
                        userId: collaborator.userId
                      });
                    } else {
                      _this2.recentPersonList.push({
                        iconUrl: _this2.handleIconURL(collaborator.iconUrl),
                        name: collaborator.name,
                        englishName: collaborator.englishName,
                        vid: collaborator.vid,
                        quanpin: collaborator.quanpin,
                        isAuthor: collaborator.isAuthor,
                        isCollaborator: collaborator.isCollaborator,
                        userId: collaborator.userId
                      });
                    }
                  });
                  this.originDocList = this.docPersonList;
                  this.originRecentList = this.recentPersonList;
                  this.docPersonList = this.sortPersonList(this.docPersonList);
                  this.recentPersonList = this.sortPersonList(this.recentPersonList);
                }

              case 9:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      return function getPersonList(_x6) {
        return _getPersonList.apply(this, arguments);
      };
    }()
  }, {
    key: "addAtTarget",
    value: function addAtTarget(commentInputText) {
      if (this.recentAtPos === 0) {
        this.showAtPanel();
      } else {
        if (!this.curNodeIdx) {
          this.curNodeIdx = 0;
        }

        var input = commentInputText;
        input.focus();
        var lastNode = input.childNodes[this.curNodeIdx];

        if (!lastNode) {
          return;
        }

        var value = lastNode.nodeValue;
        var atPos = value.lastIndexOf('@');
        var leftText = value.slice(0, atPos);
        var beforeAtString = leftText.substr(leftText.length - 1, 1);

        if (!this.isChineseStr(beforeAtString) || beforeAtString === '' || beforeAtString.match('\\n') || beforeAtString === ' ') {
          this.showAtPanel();
        }
      }
    }
  }, {
    key: "sortPersonList",
    value: function sortPersonList(contactList, keyword) {
      var sortList = contactList.slice(0);
      sortList.forEach(function (contact) {
        if (contact.quanpin) {
          contact.pinyinSearchIndex = contact.quanpin.indexOf(keyword);
        }

        if (contact.name) {
          contact.nameSearchIndex = contact.name.indexOf(keyword);
        }

        if (contact.englishName) {
          contact.englishNameSearchIndex = contact.englishName.indexOf(keyword);
        }
      });
      sortList.sort(function (a, b) {
        if (a.englishNameSearchIndex >= 0 && b.englishNameSearchIndex >= 0) {
          return a.englishNameSearchIndex - b.englishNameSearchIndex;
        }

        if (a.nameSearchIndex >= 0 && b.nameSearchIndex >= 0) {
          return a.nameSearchIndex - b.nameSearchIndex;
        }

        if (a.pinyinSearchIndex >= 0 && b.pinyinSearchIndex >= 0) {
          return a.pinyinSearchIndex - b.pinyinSearchIndex;
        }

        if (a.nameSearchIndex >= 0 || b.nameSearchIndex >= 0) {
          return b.nameSearchIndex - a.nameSearchIndex;
        }

        if (a.pinyinSearchIndex >= 0 || b.pinyinSearchIndex >= 0) {
          return b.pinyinSearchIndex - a.pinyinSearchIndex;
        }

        if (a.englishNameSearchIndex >= 0 || b.englishNameSearchIndex >= 0) {
          return b.englishNameSearchIndex - a.englishNameSearchIndex;
        }

        return a.quanpin - b.quanpin;
      });
      return sortList;
    }
  }, {
    key: "showAtPanel",
    value: function () {
      var _showAtPanel = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_asyncToGenerator__WEBPACK_IMPORTED_MODULE_7__["default"])(
      /*#__PURE__*/
      regeneratorRuntime.mark(function _callee4() {
        return regeneratorRuntime.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                _context4.next = 2;
                return this.getPersonList();

              case 2:
                _emitter__WEBPACK_IMPORTED_MODULE_12__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_12__["default"].SHOW_AT, this.docPersonList, this.recentPersonList);

              case 3:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, this);
      }));

      return function showAtPanel() {
        return _showAtPanel.apply(this, arguments);
      };
    }()
  }, {
    key: "hideAtPanel",
    value: function hideAtPanel() {
      this.recentAtPos = null;
      this.personIndex = 0;
      _emitter__WEBPACK_IMPORTED_MODULE_12__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_12__["default"].HIDE_AT);
    }
  }, {
    key: "updateAtValue",
    value: function updateAtValue(event, commentInputText, preLength) {
      var _this3 = this;

      if (window.settings.type === 'qq') {
        return;
      }

      this.commentInputText = commentInputText;
      var selection = window.getSelection();
      var innerHTML = event.target.innerHTML;
      var anchorOffset = selection.anchorOffset,
          anchorNode = selection.anchorNode;
      var isInsert = event.inputType ? event.inputType.match('insert') : innerHTML.length >= preLength;
      var isDelete = event.inputType ? event.inputType.match('delete') : innerHTML.length < preLength;
      var inputData = event.data || anchorOffset > 0 ? anchorNode.textContent.substr(anchorOffset - 1, 1) : null;

      if (inputData && inputData.match('@') && isInsert) {
        this.recentAtPos = window.getSelection().anchorOffset - 1;
        this.addAtTarget(commentInputText);
      } else {
        if (!this.curNodeIdx) {
          this.curNodeIdx = 0;
        }

        var input = commentInputText;
        input.focus();

        if (this.curNodeIdx === undefined) {
          this.curNodeIdx = 0;
        }

        var lastNode = input.childNodes[this.curNodeIdx];

        if (!lastNode) {
          this.hideAtPanel();
          return;
        }

        var value = lastNode.nodeValue;

        if (value === null) {
          return;
        }

        var atPos = value.lastIndexOf('@');
        var leftText = value.slice(0, atPos);
        var searchText = value.slice(atPos + 1, this.curCursorPos + 1);
        var beforeAtString = leftText.substr(leftText.length - 1, 1); // 删除整个at节点+前后两个空格

        if (isDelete) {
          var _window$getSelection = window.getSelection(),
              _anchorOffset = _window$getSelection.anchorOffset,
              _anchorNode = _window$getSelection.anchorNode;

          if (_anchorNode.className === 'commentPopup_input_text') {
            // 直接删除末尾 at 节点
            var childNodes = _anchorNode.childNodes;

            for (var index = childNodes.length - 1; index >= 0; index--) {
              var node = childNodes[index];

              if (index === _anchorOffset - 1) {
                // 删掉的 at 节点
                input.removeChild(node);
              } else if (index === _anchorOffset - 2) {// at 节点前最后一个空格干掉
              }
            }
          } else if (_anchorOffset === 0) {
            // 删除评论中间的 at 节点
            var _childNodes = _anchorNode.parentElement.childNodes;
            var nodeIndex = Array.prototype.findIndex.call(_childNodes, function (node) {
              return node === _anchorNode;
            });

            if (nodeIndex > 1 && _childNodes[nodeIndex - 1].className === 'od_editor_atTarget') {
              Array.prototype.forEach.call(_childNodes, function (node, index) {
                if (index === nodeIndex - 1) {
                  input.removeChild(node);
                } else if (index === nodeIndex - 2) {// at 节点前最后一个空格干掉
                }
              });
            }
          }
        }

        if (atPos > -1) {
          var hideStatus = null;

          if (inputData && isInsert) {
            hideStatus = value.slice(this.curCursorPos, this.curCursorPos + 1) === ' ';
          } else if (isDelete) {
            hideStatus = value.slice(this.curCursorPos - 2, this.curCursorPos - 1) === ' ';
          } else {
            this.hideAtPanel();
            return;
          }

          if (hideStatus) {
            this.hideAtPanel();
          } else if (!(!this.isChineseStr(beforeAtString) || beforeAtString === '' || beforeAtString.match('\\n') || beforeAtString === ' ')) {
            this.hideAtPanel();
          } else {
            this.searchdocPersonList = [];
            this.searchrecentPersonList = [];
            this.originDocList.forEach(function (collaborator) {
              if (collaborator.name && collaborator.name.match(searchText) || collaborator.quanpin && collaborator.quanpin.match(searchText) || collaborator.englishName && collaborator.englishName.match(searchText)) {
                _this3.searchdocPersonList.push({
                  iconUrl: _this3.handleIconURL(collaborator.iconUrl),
                  name: collaborator.name,
                  englishName: collaborator.englishName,
                  vid: collaborator.vid,
                  quanpin: collaborator.quanpin,
                  isAuthor: collaborator.isAuthor,
                  isCollaborator: collaborator.isCollaborator,
                  userId: collaborator.userId
                });
              }
            });
            this.originRecentList.forEach(function (collaborator) {
              if (collaborator.name && collaborator.name.match(searchText) || collaborator.quanpin && collaborator.quanpin.match(searchText) || collaborator.englishName && collaborator.englishName.match(searchText)) {
                _this3.searchrecentPersonList.push({
                  iconUrl: _this3.handleIconURL(collaborator.iconUrl),
                  name: collaborator.name,
                  englishName: collaborator.englishName,
                  vid: collaborator.vid,
                  quanpin: collaborator.quanpin,
                  isAuthor: collaborator.isAuthor,
                  isCollaborator: collaborator.isCollaborator,
                  userId: collaborator.userId
                });
              }
            });
            this.docPersonList = this.sortPersonList(this.searchdocPersonList, searchText);
            this.recentPersonList = this.sortPersonList(this.searchrecentPersonList, searchText);

            if (this.docPersonList && this.docPersonList.length || this.recentPersonList && this.recentPersonList.length) {
              _emitter__WEBPACK_IMPORTED_MODULE_12__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_12__["default"].SHOW_AT, this.docPersonList, this.recentPersonList);
            } else {
              _emitter__WEBPACK_IMPORTED_MODULE_12__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_12__["default"].HIDE_AT);
            }
          }
        } else {
          this.hideAtPanel();
        }
      }
    }
  }]);

  return At;
}();



/***/ }),

/***/ "dp95":
/*!********************************************!*\
  !*** ./src/lib/plugins/comment/Comment.js ***!
  \********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Comment; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _lib_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/util */ "8e1d");
/* harmony import */ var _emitter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../emitter */ "oj7Y");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! moment */ "wd/R");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);




 // var moment = require('moment');

var Comment =
/*#__PURE__*/
function () {
  function Comment() {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, Comment);
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(Comment, [{
    key: "showComment",
    value: function showComment(commentList, selection, addFlag) {
      if (commentList && commentList.length) {
        var showFlag = 0;
        Object(_lib_util__WEBPACK_IMPORTED_MODULE_2__["each"])(commentList, function (comment) {
          var commentSelection = comment.span;
          var commentId = comment.cid;

          if (selection) {
            if (selection.row === commentSelection.row && selection.col === commentSelection.col && commentId) {
              var showComment = 1; // 表示该单元格已经有评论

              _emitter__WEBPACK_IMPORTED_MODULE_3__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_3__["default"].SHOW_COMMENT, commentId, showComment);
              showFlag = 1;
            }
          }
        });

        if (!showFlag && !addFlag) {
          _emitter__WEBPACK_IMPORTED_MODULE_3__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_3__["default"].HIDE_COMMENT);
        } else if (!showFlag && addFlag) {
          _emitter__WEBPACK_IMPORTED_MODULE_3__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_3__["default"].SHOW_COMMENT);
        }
      } else {
        if (addFlag) {
          _emitter__WEBPACK_IMPORTED_MODULE_3__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_3__["default"].SHOW_COMMENT);
        } else {
          _emitter__WEBPACK_IMPORTED_MODULE_3__["default"].emit(_emitter__WEBPACK_IMPORTED_MODULE_3__["default"].HIDE_COMMENT);
        }
      }
    }
  }, {
    key: "sort",
    value: function sort(data, userMapData, commentListData) {
      var self = this;

      if (data && data.user && data.user.list && data.comment && data.comment.comment_list) {
        return {
          userMap: self.sortUsers(data.user.list, userMapData),
          commentList: self.sortComments(data.comment.comment_list.comment, commentListData)
        };
      } else {
        return {};
      }
    }
  }, {
    key: "sortUsers",
    value: function sortUsers(list, userMapData) {
      var sortMap = userMapData || {};
      Object(_lib_util__WEBPACK_IMPORTED_MODULE_2__["each"])(list, function (user) {
        sortMap[user.vid] = user;
      });
      return sortMap;
    }
  }, {
    key: "sortComments",
    value: function sortComments(list, commentListData) {
      var self = this;
      var sortList = commentListData || {},
          subComments,
          mainCommentId,
          commentId;
      Object(_lib_util__WEBPACK_IMPORTED_MODULE_2__["each"])(list, function (comment) {
        mainCommentId = comment.main_comment_id;
        commentId = comment.comment_id;

        if (!(commentId && mainCommentId)) {
          return;
        }

        comment.createFormatTime = self.formatTime(comment.create_time);

        if (!sortList[mainCommentId]) {
          sortList[mainCommentId] = {
            main_comment_id: mainCommentId,
            subComments: {}
          };
        }

        subComments = sortList[mainCommentId]['subComments'];
        subComments[commentId] = comment;
      });
      return sortList;
    }
  }, {
    key: "formatTime",
    value: function formatTime(time) {
      return moment__WEBPACK_IMPORTED_MODULE_4___default()(time * 1000).calendar(null, {
        lastDay: '昨天 HH:mm',
        sameDay: 'HH:mm',
        nextDay: 'MM月DD日 HH:mm',
        lastWeek: 'MM月DD日 HH:mm',
        nextWeek: 'MM月DD日 HH:mm',
        sameElse: 'MM月DD日 HH:mm'
      });
    }
  }]);

  return Comment;
}();



/***/ }),

/***/ "gFnr":
/*!**************************************!*\
  !*** ./src/lib/commands/setPaste.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.string.bold */ "SMB2");
/* harmony import */ var core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_string_bold__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Font */ "lLCG");





var logger = new _Logger__WEBPACK_IMPORTED_MODULE_3__["default"]('setPaste'); // 通过获取html来复制粘贴

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      data = _ref.data,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo;

  logger.debug(selection, data);
  var commands = [];
  var undoCmds = [];
  var row = selection.row,
      col = selection.col;
  selection.rowCount = data.length;
  selection.colCount = data[0].length;
  var startRow = row;
  var startCol = col;
  var dataTable = this.data.data.dataTable;
  var undoManager = this.undoManager;
  undoManager.addUndoStack();
  var cmd = '';
  var undocmd = '';
  var mergeSpans = Object(_util__WEBPACK_IMPORTED_MODULE_1__["getMergeCellList"])(selection, this.data.spans);

  if (mergeSpans) {
    for (var i = 0; i < mergeSpans.length; i++) {
      cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
        selection: mergeSpans[i],
        value: 0
      });
      undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
        selection: mergeSpans[i],
        value: 1
      });
      this.execute('merge', {
        selection: mergeSpans[i],
        value: 0,
        sync: false,
        render: true,
        undoStack: false,
        undo: false
      });
      commands = commands.concat(cmd);
      undoCmds = undoCmds.concat(undocmd);
    }
  }

  Object(_util__WEBPACK_IMPORTED_MODULE_1__["iterateSelection"])(selection, function (row, col) {
    var cell = data[row - startRow][col - startCol];
    var style = cell.style,
        rowSpan = cell.rowSpan,
        colSpan = cell.colSpan;
    var value = cell.text;

    if (rowSpan > 1 || colSpan > 1) {
      var mergeSelection = {
        row: row,
        col: col,
        rowCount: rowSpan,
        colCount: colSpan
      };
      cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
        selection: mergeSelection,
        value: 1
      });
      undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('merge', {
        selection: mergeSelection,
        value: 0
      });

      _this.execute('merge', {
        selection: mergeSelection,
        value: 1,
        sync: false,
        render: true,
        undoStack: false,
        undo: false
      });

      commands = commands.concat(cmd);
      undoCmds = undoCmds.concat(undocmd);
    }

    if (value !== Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(dataTable, [row, col, 'value'])) {
      var valueSelection = {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      };
      cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setValue', {
        selection: valueSelection,
        value: value
      });
      undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setValue', {
        selection: valueSelection,
        value: Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(dataTable, [row, col, 'value']) || ''
      });

      _this.execute('setValue', {
        selection: valueSelection,
        value: value,
        sync: false,
        render: true,
        undoStack: false,
        undo: false
      });

      commands = commands.concat(cmd);
      undoCmds = undoCmds.concat(undocmd);
    }

    if (style) {
      var textAlign = style.textAlign,
          verticalAlign = style.verticalAlign,
          textDecoration = style.textDecoration,
          color = style.color,
          backgroundColor = style.backgroundColor,
          font = style.font,
          borderTop = style.borderTop,
          borderRight = style.borderRight,
          borderBottom = style.borderBottom,
          borderLeft = style.borderLeft,
          whiteSpace = style.whiteSpace;
      var _selection = {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      };
      var oldStyle = Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(dataTable, [row, col, 'style']);
      oldStyle = oldStyle || {};

      if (textAlign) {
        if (textAlign !== Object(_util__WEBPACK_IMPORTED_MODULE_1__["getHAlign"])(oldStyle.hAlign)) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'hAlign',
            value: textAlign
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'hAlign',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_1__["getHAlign"])(oldStyle.hAlign)
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'hAlign',
            value: textAlign,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      if (verticalAlign) {
        if (textAlign !== Object(_util__WEBPACK_IMPORTED_MODULE_1__["getVAlign"])(oldStyle.vAlign)) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'vAlign',
            value: verticalAlign
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'vAlign',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_1__["getVAlign"])(oldStyle.vAlign)
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'vAlign',
            value: verticalAlign,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      if (textDecoration) {
        value = /line-through/i.test(textDecoration) ? 1 : 0;

        if (value !== (oldStyle.textDecoration ? 1 : 0)) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'strike',
            value: value
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'strike',
            value: oldStyle.textDecoration ? 1 : 0
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'strike',
            value: value,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      if (color) {
        if (color !== oldStyle.foreColor) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'foreColor',
            value: color
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'foreColor',
            value: oldStyle.foreColor || ''
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'foreColor',
            value: color,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      if (backgroundColor) {
        if (/rgba\s*\(\s*0,\s*0,\s*0,\s*0\s*\)/i.test(backgroundColor)) {
          backgroundColor = '';
        }

        if (backgroundColor !== oldStyle.backColor) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'backColor',
            value: backgroundColor
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'backColor',
            value: oldStyle.backColor || ''
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'backColor',
            value: backgroundColor,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      if (font) {
        var fontStyle = font.fontStyle,
            fontWeight = font.fontWeight,
            fontSize = font.fontSize;
        var oldFont = '';
        if (oldStyle.font) oldFont = oldStyle && oldStyle.font;
        if (oldFont) oldFont = new _Font__WEBPACK_IMPORTED_MODULE_4__["default"](oldFont);

        if (fontStyle) {
          var _value = /italic/i.test(fontStyle) ? 1 : 0;

          if (_value !== (oldFont && oldFont.italic() ? 1 : 0)) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'italic',
              value: _value
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'italic',
              value: oldFont && oldFont.italic() ? 1 : 0
            });

            _this.execute('setStyle', {
              selection: _selection,
              property: 'italic',
              value: _value,
              sync: false,
              render: true,
              undoStack: false,
              undo: false
            });

            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }
        }

        if (fontWeight) {
          if ((fontWeight !== '400' ? 1 : 0) !== (oldFont && oldFont.bold() ? 1 : 0)) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'bold',
              value: fontWeight !== '400' ? 1 : 0
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'bold',
              value: oldFont && oldFont.bold() ? 1 : 0
            });

            _this.execute('setStyle', {
              selection: _selection,
              property: 'bold',
              value: fontWeight !== '400' ? 1 : 0,
              sync: false,
              render: true,
              undoStack: false,
              undo: false
            });

            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }
        }

        if (fontSize) {
          if (fontSize !== (oldFont && oldFont.size())) {
            cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'fontSize',
              value: fontSize
            });
            undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
              selection: _selection,
              property: 'fontSize',
              value: oldFont && oldFont.size()
            });

            _this.execute('setStyle', {
              selection: _selection,
              property: 'fontSize',
              value: fontSize,
              sync: false,
              render: true,
              undoStack: false,
              undo: false
            });

            commands = commands.concat(cmd);
            undoCmds = undoCmds.concat(undocmd);
          }
        }
      }

      if (whiteSpace) {
        if ((whiteSpace === 'normal' ? 1 : 0) !== (oldStyle.wordWrap ? 1 : 0)) {
          cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'textWrap',
            value: whiteSpace === 'normal' ? 1 : 0
          });
          undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
            selection: _selection,
            property: 'textWrap',
            value: oldStyle.wordWrap ? 1 : 0
          });

          _this.execute('setStyle', {
            selection: _selection,
            property: 'textWrap',
            value: whiteSpace === 'normal' ? 1 : 0,
            sync: false,
            render: true,
            undoStack: false,
            undo: false
          });

          commands = commands.concat(cmd);
          undoCmds = undoCmds.concat(undocmd);
        }
      }

      var borderSelection = {
        row: row,
        col: col,
        rowCount: 1,
        colCount: 1
      };

      if (borderTop) {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderTop',
          value: borderTop
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderTop',
          value: oldStyle['borderTop'] || ''
        });

        _this.execute('setStyle', {
          selection: borderSelection,
          property: 'borderTop',
          value: borderTop,
          sync: false,
          render: true,
          undoStack: false,
          undo: false
        });

        commands = commands.concat(cmd);
        undoCmds = undoCmds.concat(undocmd);
      }

      if (borderRight) {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderRight',
          value: borderRight
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderRight',
          value: oldStyle['borderRight'] || ''
        });

        _this.execute('setStyle', {
          selection: borderSelection,
          property: 'borderRight',
          value: borderRight,
          sync: false,
          render: true,
          undoStack: false,
          undo: false
        });

        commands = commands.concat(cmd);
        undoCmds = undoCmds.concat(undocmd);
      }

      if (borderLeft) {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderLeft',
          value: borderLeft
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderLeft',
          value: oldStyle['borderLeft'] || ''
        });

        _this.execute('setStyle', {
          selection: borderSelection,
          property: 'borderLeft',
          value: borderLeft,
          sync: false,
          render: true,
          undoStack: false,
          undo: false
        });

        commands = commands.concat(cmd);
        undoCmds = undoCmds.concat(undocmd);
      }

      if (borderBottom) {
        cmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderBottom',
          value: borderBottom
        });
        undocmd = Object(_generateCmd__WEBPACK_IMPORTED_MODULE_2__["default"])('setStyle', {
          selection: borderSelection,
          property: 'borderBottom',
          value: oldStyle['borderBottom'] || ''
        });

        _this.execute('setStyle', {
          selection: borderSelection,
          property: 'borderBottom',
          value: borderBottom,
          sync: false,
          render: true,
          undoStack: false,
          undo: false
        });

        commands = commands.concat(cmd);
        undoCmds = undoCmds.concat(undocmd);
      }
    }
  });

  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "iVfD":
/*!******************************************!*\
  !*** ./src/lib/commands/setRowHeight.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _Font__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Font */ "lLCG");



/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      _ref$rows = _ref.rows,
      rows = _ref$rows === void 0 ? 1 : _ref$rows,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var undoManager = this.undoManager,
      data = this.data,
      worksheet = this.worksheet,
      textWrapRowHeights = this.textWrapRowHeights;
  var dataTable = data.data.dataTable;
  var colCount = worksheet.getColumnCount();
  var defaultRowHeight = worksheet.defaults.rowHeight;
  var resizeRowHeight = value;
  var commands = [];
  var undoCmds = [];
  if (undoStack) undoManager.addUndoStack();

  for (var row = index; row < index + rows; row++) {
    var autoRowHeight = 0;

    for (var col = 0; col < colCount; col++) {
      var style = Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(dataTable, [row, col, 'style']) || {};

      if (style.wordWrap) {
        autoRowHeight = Math.max(autoRowHeight, textWrapRowHeights[row]);
      } else if (style.font) {
        var font = new _Font__WEBPACK_IMPORTED_MODULE_2__["default"](style.font);
        autoRowHeight = Math.max(autoRowHeight, getAutoRowHeight(font.size()));
      }
    } // 取三者最大值


    resizeRowHeight = Math.max(defaultRowHeight, Math.max(resizeRowHeight, autoRowHeight));
    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('setRowHeight', {
      index: row,
      value: resizeRowHeight
    }));
  }

  if (render) {
    for (var _row = index; _row < index + rows; _row++) {
      worksheet.setRowHeight(_row, resizeRowHeight);
    }
  }

  if (undo) {
    for (var _row2 = index; _row2 < index + rows; _row2++) {
      var oldValue = Object(_util__WEBPACK_IMPORTED_MODULE_1__["safeGet"])(data.rows, [_row2, 'size']) || defaultRowHeight;
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('setRowHeight', {
        index: _row2,
        value: Math.max(oldValue, defaultRowHeight)
      }));
    }

    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

function getAutoRowHeight(size) {
  var height = 0;

  switch (size) {
    case 12:
      height = 19;
      break;

    case 14:
      height = 22;
      break;

    case 18:
      height = 27;
      break;

    case 24:
      height = 34;
      break;

    case 30:
      height = 43;
      break;

    case 36:
      height = 50;
      break;

    default:
      height = 24;
      break;
  }

  return height;
}

/***/ }),

/***/ "k884":
/*!***************************************!*\
  !*** ./src/lib/commands/deleteRow.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util */ "8e1d");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('deleteRow');
/*
    TODO：
    兼容以下情况： 公式、筛选
*/

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      count = _ref.count,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(index, count);
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  var dataTable = data.data.dataTable;
  var removedData = [];
  var commands = [];
  var colCount = worksheet.getColumnCount();
  if (undoStack) undoManager.addUndoStack();

  if (undo) {
    for (var i = 0; i < count; i++) {
      if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(dataTable)) {
        removedData[index + i] = dataTable[index + i];
      }

      this.execute('clearFormat', {
        selection: {
          col: 0,
          colCount: colCount,
          row: index + i,
          rowCount: 1
        },
        sync: false,
        render: false,
        undoStack: false,
        undo: true
      });
      this.executeCmds(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setRowHeight', {
        index: index + i,
        value: worksheet.getRowHeight(index + i)
      }), {
        sync: false,
        render: false,
        undoStack: false,
        undo: true
      });
    }
  }

  for (var _i = index; _i < index + count; _i++) {
    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('deleteRow', {
      index: index,
      colCount: colCount
    }));
  }

  if (render) {
    worksheet.deleteRows(index, count);
  }

  if (undo) {
    (function () {
      var undoCmds = [];

      for (var _i2 = count - 1; _i2 >= 0; _i2--) {
        if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(removedData)) {
          (function () {
            var removedDataList = removedData[index + _i2];
            var selection = {
              col: 0,
              colCount: 1,
              row: index + _i2,
              rowCount: 1
            };

            var _loop = function _loop(j) {
              selection.col = j;

              if (removedDataList !== undefined && !Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(removedDataList[j]) && removedDataList[j] !== '') {
                if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['formula']) || '') {
                  Object(_util__WEBPACK_IMPORTED_MODULE_2__["iterateSelection"])(selection, function (row, col) {
                    if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['formula'])) {
                      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setFormula', {
                        selection: {
                          row: row,
                          col: col,
                          rowCount: 1,
                          colCount: 1
                        },
                        value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['formula']) || ''
                      }));
                    }
                  });
                } else {
                  if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['value']) || '') {
                    Object(_util__WEBPACK_IMPORTED_MODULE_2__["iterateSelection"])(selection, function (row, col) {
                      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
                        selection: {
                          row: row,
                          col: col,
                          rowCount: 1,
                          colCount: 1
                        },
                        value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['value']) || ''
                      }));
                    });
                  }
                }
              }
            };

            for (var j = 0; j < colCount; j++) {
              _loop(j);
            }
          })();
        }

        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('insertRow', {
          index: index + _i2,
          colCount: colCount
        }));
      }

      undoManager.addUndo({
        commands: commands,
        undoCmds: undoCmds
      });
    })();
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "ktbB":
/*!***************************************!*\
  !*** ./src/lib/commands/deleteCol.js ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../util */ "8e1d");



var logger = new _Logger__WEBPACK_IMPORTED_MODULE_0__["default"]('deleteCol');
/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      index = _ref.index,
      count = _ref.count,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  logger.debug(index, count);
  var undoManager = this.undoManager,
      worksheet = this.worksheet,
      data = this.data;
  var dataTable = data.data.dataTable;
  var removedData = [];
  var commands = [];
  var rowCount = worksheet.getRowCount();
  if (undoStack) undoManager.addUndoStack();

  if (undo) {
    for (var i = 0; i < count; i++) {
      if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(dataTable)) {
        removedData[index + i] = Object(_util__WEBPACK_IMPORTED_MODULE_2__["getColData"])(dataTable, index + i);
      }

      this.execute('clearFormat', {
        selection: {
          col: index + i,
          colCount: 1,
          row: 0,
          rowCount: rowCount
        },
        sync: false,
        render: false,
        undoStack: false,
        undo: true
      });
      this.executeCmds(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setColWidth', {
        index: index + i,
        value: worksheet.getColumnWidth(index + i)
      }), {
        sync: false,
        render: false,
        undoStack: false,
        undo: true
      });
    }
  }

  for (var _i = index; _i < index + count; _i++) {
    commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('deleteCol', {
      index: index,
      rowCount: rowCount
    }));
  }

  if (render) {
    worksheet.deleteColumns(index, count);
  }

  if (undo) {
    (function () {
      var undoCmds = [];

      for (var _i2 = count - 1; _i2 >= 0; _i2--) {
        if (!Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(removedData)) {
          (function () {
            var removedDataList = removedData[index + _i2];
            var selection = {
              col: index + _i2,
              colCount: 1,
              row: 0,
              rowCount: 1
            };

            var _loop = function _loop(j) {
              selection.row = j;

              if (removedDataList !== undefined && !Object(_util__WEBPACK_IMPORTED_MODULE_2__["isUndef"])(removedDataList[j]) && removedDataList[j] !== '') {
                if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['formula']) || '') {
                  Object(_util__WEBPACK_IMPORTED_MODULE_2__["iterateSelection"])(selection, function (row, col) {
                    undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setFormula', {
                      selection: {
                        row: row,
                        col: col,
                        rowCount: 1,
                        colCount: 1
                      },
                      value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['formula']) || ''
                    }));
                  });
                } else {
                  if (Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['value']) || '') {
                    Object(_util__WEBPACK_IMPORTED_MODULE_2__["iterateSelection"])(selection, function (row, col) {
                      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
                        selection: {
                          row: row,
                          col: col,
                          rowCount: 1,
                          colCount: 1
                        },
                        value: Object(_util__WEBPACK_IMPORTED_MODULE_2__["safeGet"])(removedDataList[j], ['value']) || ''
                      }));
                    });
                  }
                }
              }
            };

            for (var j = 0; j < rowCount; j++) {
              _loop(j);
            }
          })();
        }

        undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('insertCol', {
          index: index + _i2,
          rowCount: rowCount
        }));
      }

      undoManager.addUndo({
        commands: commands,
        undoCmds: undoCmds
      });
    })();
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "lLCG":
/*!*************************!*\
  !*** ./src/lib/Font.js ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _default; });
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.match */ "SRfc");
/* harmony import */ var core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_match__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.replace */ "pIFo");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _Constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Constants */ "Eo9w");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./util */ "8e1d");







var _default =
/*#__PURE__*/
function () {
  function _default(str) {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, _default);

    if (str.indexOf('700') > -1) {
      str = str.replace('700', '');
      this._bold = true;
    } else if (str.indexOf('bold') > -1) {
      str = str.replace('bold', '');
      this._bold = true;
    } else {
      this._bold = false;
    }

    if (str.indexOf('italic') > -1) {
      str = str.replace('italic', '');
      this._italic = true;
    } else {
      this._italic = false;
    }

    if (regSize.test(str)) {
      var match = str.match(regSize);
      this._size = Object(_util__WEBPACK_IMPORTED_MODULE_5__["toNum"])(match[1]);
      str = str.replace(regSize, '');
    } else {
      this._size = _Constants__WEBPACK_IMPORTED_MODULE_4__["DEFAULT_FONT"].SIZE;
    }

    this._family = Object(_util__WEBPACK_IMPORTED_MODULE_5__["trim"])(str);
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(_default, [{
    key: "bold",
    value: function bold(val) {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_5__["isUndef"])(val)) return this._bold;
      this._bold = val;
    }
  }, {
    key: "size",
    value: function size(val) {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_5__["isUndef"])(val)) return this._size;
      this._size = val;
    }
  }, {
    key: "italic",
    value: function italic(val) {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_5__["isUndef"])(val)) return this._italic;
      this._italic = val;
    }
  }, {
    key: "family",
    value: function family(val) {
      if (Object(_util__WEBPACK_IMPORTED_MODULE_5__["isUndef"])(val)) return this._family;
      this._family = val;
    }
  }, {
    key: "toString",
    value: function toString() {
      var ret = [];
      if (this._italic) ret.push('italic');
      if (this._bold) ret.push('bold');
      ret.push(this._size + 'px');
      ret.push(this._family);
      return Object(_util__WEBPACK_IMPORTED_MODULE_5__["trim"])(ret.join(' '));
    }
  }]);

  return _default;
}();


var regSize = /(\d+)px/;

/***/ }),

/***/ "nBop":
/*!***************************!*\
  !*** ./src/lib/report.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (window.KV);

/***/ }),

/***/ "o3O1":
/*!**************************************!*\
  !*** ./src/lib/commands/dragMove.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../generateCmd */ "11+Z");

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      args = _ref.args,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync;

  var rowCount = args.rowCount,
      columnCount = args.columnCount,
      fromRow = args.fromRow,
      toRow = args.toRow,
      fromColumn = args.fromColumn,
      toColumn = args.toColumn;
  var worksheet = this.worksheet; // 添加命令到commands数组

  var commands = [];
  var sheetRowCount = worksheet.getRowCount();
  var sheetColCount = worksheet.getColumnCount();

  if (fromRow === -1) {
    // 列拖拽
    if (fromColumn < toColumn) {
      // 从左向右拖拽
      for (var i = 0; i < columnCount; i++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('insertCol', {
          index: toColumn + i,
          rowCount: sheetRowCount
        }));
      }

      for (var _i = 0; _i < columnCount; _i++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('deleteCol', {
          rowCount: sheetRowCount,
          index: fromColumn
        }));
      }

      commands = commands.concat(this.execute('paste', {
        fromSelection: {
          row: fromRow,
          rowCount: sheetRowCount,
          col: fromColumn,
          colCount: columnCount
        },
        isCutting: false,
        toSelection: {
          row: toRow,
          rowCount: sheetRowCount,
          col: toColumn - columnCount,
          colCount: columnCount
        },
        sync: false
      }));
    } else if (fromColumn > toColumn) {
      // 从右向左拖拽
      for (var _i2 = 0; _i2 < columnCount; _i2++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('insertCol', {
          index: toColumn + _i2,
          rowCount: sheetRowCount
        }));
      }

      commands = commands.concat(this.execute('paste', {
        fromSelection: {
          row: fromRow,
          rowCount: sheetRowCount,
          col: fromColumn,
          colCount: columnCount
        },
        isCutting: false,
        toSelection: {
          row: toRow,
          rowCount: sheetRowCount,
          col: toColumn,
          colCount: columnCount
        },
        sync: false
      }));

      for (var _i3 = 0; _i3 < columnCount; _i3++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('deleteCol', {
          rowCount: sheetRowCount,
          index: fromColumn + columnCount
        }));
      }
    }
  } else if (fromColumn === -1) {
    // 行拖拽
    if (fromRow < toRow) {
      // 从上向下拖拽
      for (var _i4 = 0; _i4 < rowCount; _i4++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('insertRow', {
          index: toRow + _i4,
          colCount: sheetColCount
        }));
      }

      for (var _i5 = 0; _i5 < rowCount; _i5++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('deleteRow', {
          colCount: sheetColCount,
          index: fromRow
        }));
      }

      commands = commands.concat(this.execute('paste', {
        fromSelection: {
          row: fromRow,
          rowCount: rowCount,
          col: fromColumn,
          colCount: sheetColCount
        },
        isCutting: false,
        toSelection: {
          row: toRow - rowCount,
          rowCount: rowCount,
          col: toColumn,
          colCount: sheetColCount
        },
        sync: false
      }));
    } else if (fromRow > toRow) {
      // 从下向上拖拽
      for (var _i6 = 0; _i6 < rowCount; _i6++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('insertRow', {
          index: toRow + _i6,
          colCount: sheetColCount
        }));
      }

      commands = commands.concat(this.execute('paste', {
        fromSelection: {
          row: fromRow,
          rowCount: rowCount,
          col: fromColumn,
          colCount: sheetColCount
        },
        isCutting: false,
        toSelection: {
          row: toRow,
          rowCount: rowCount,
          col: toColumn,
          colCount: sheetColCount
        },
        sync: false
      }));

      for (var _i7 = 0; _i7 < rowCount; _i7++) {
        commands = commands.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_0__["default"])('deleteRow', {
          colCount: sheetColCount,
          index: fromRow + rowCount
        }));
      }
    }
  } // 发送指令同步数据到远程


  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "oLvY":
/*!********************************!*\
  !*** ./src/lib/UndoManager.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return UndoManager; });
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./util */ "8e1d");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Logger */ "GONd");
/* harmony import */ var _changeset__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./changeset */ "9pe4");





var logger = new _Logger__WEBPACK_IMPORTED_MODULE_3__["default"]('UndoManager');

var UndoManager =
/*#__PURE__*/
function () {
  function UndoManager(sheet) {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_0__["default"])(this, UndoManager);

    this.sheet = sheet;
    this.undoStack = [];
    this.redoStack = [];
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_1__["default"])(UndoManager, [{
    key: "addUndoStack",
    value: function addUndoStack() {
      this.undoStack.push({
        commands: [],
        undoCmds: []
      });
      this.redoStack = []; //每一次添加新的操作，都应该清空redoStack

      this.sheet.syncToolBar();
    }
  }, {
    key: "addUndo",
    value: function addUndo(_ref) {
      var commands = _ref.commands,
          undoCmds = _ref.undoCmds;

      if (this.undoStack && this.undoStack.length) {
        var stack = Object(_util__WEBPACK_IMPORTED_MODULE_2__["last"])(this.undoStack);

        if (commands) {
          stack.commands = stack.commands.concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["toArr"])(commands));
        }

        if (undoCmds) {
          stack.undoCmds = stack.undoCmds.concat(Object(_util__WEBPACK_IMPORTED_MODULE_2__["toArr"])(undoCmds));
        }
      }
    }
  }, {
    key: "undo",
    value: function undo() {
      var stack = this.undoStack.pop(),
          undoCmds = stack.undoCmds;
      logger.debug('trigger undo', undoCmds);
      var localChangeSet = new _changeset__WEBPACK_IMPORTED_MODULE_4__["SheetChangeSet"]();
      localChangeSet.appendCmds(undoCmds.reverse());
      var cmdStr = localChangeSet.getStrCmds();
      this.sheet.executeUndoRedoCmds(cmdStr);
      this.redoStack.push(stack);
      this.sheet.syncToolBar();
      undoCmds.reverse();
    }
  }, {
    key: "redo",
    value: function redo() {
      var stack = this.redoStack.pop(),
          commands = stack.commands;
      logger.debug('trigger redo', commands);
      var localChangeSet = new _changeset__WEBPACK_IMPORTED_MODULE_4__["SheetChangeSet"]();
      localChangeSet.appendCmds(commands);
      var cmdStr = localChangeSet.getStrCmds();
      this.sheet.executeUndoRedoCmds(cmdStr);
      this.undoStack.push(stack);
      this.sheet.syncToolBar();
    }
  }, {
    key: "canUndo",
    value: function canUndo() {
      return this.undoStack.length > 0;
    }
  }, {
    key: "canRedo",
    value: function canRedo() {
      return this.redoStack.length > 0;
    }
  }, {
    key: "clearRedo",
    value: function clearRedo() {
      this.redoStack = [];
      this.sheet.syncToolBar();
    }
  }, {
    key: "clear",
    value: function clear() {
      this.undoStack = [];
      this.redoStack = [];
      this.sheet.syncToolBar();
    }
  }]);

  return UndoManager;
}();



/***/ }),

/***/ "odEX":
/*!**************************************!*\
  !*** ./src/lib/commands/setValue.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");

 // import Logger from '../Logger';
// let logger = new Logger('setValue');

/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _this = this;

  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      value = _ref.value,
      _ref$render = _ref.render,
      render = _ref$render === void 0 ? true : _ref$render,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo,
      _ref$sync = _ref.sync,
      sync = _ref$sync === void 0 ? true : _ref$sync,
      _ref$isEdited = _ref.isEdited,
      isEdited = _ref$isEdited === void 0 ? false : _ref$isEdited;

  // logger.debug(selection, value);
  var undoManager = this.undoManager,
      data = this.data,
      worksheet = this.worksheet; // let { dataTable } = data && data.data;

  var dataTable = data && data.data && data.data.dataTable;
  var oldValue = Object(_util__WEBPACK_IMPORTED_MODULE_0__["safeGet"])(dataTable, [selection.row, selection.col, 'value']);
  var isNotChanged = selection.rowCount === 1 && selection.colCount === 1 && value == oldValue; // 1. 只有一个单元格，而且单元格的值没有改变，则不生成指令  
  // 2. 当输入为空时（value为null）,但是当oldValue为‘’或者null时(为null的情况isNotChange已经包括了)，都不需要生成指令。
  // 3. 必须要从手动编辑进来

  if ((isNotChanged || !value && oldValue === '') && isEdited) {
    return;
  } // logger.debug(selection, value);


  if (undoStack) undoManager.addUndoStack();
  var commands = [];
  commands.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
    selection: selection,
    value: value || ''
  }));

  if (render) {
    Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
      _this.worksheet.setText(row, col, value);
    }); // 自适应调整行高

    for (var row = selection.row; row < selection.row + selection.rowCount; row++) {
      worksheet.autoFitRow(row);
    }
  }

  if (undo) {
    var undoCmds = [];
    Object(_util__WEBPACK_IMPORTED_MODULE_0__["iterateSelection"])(selection, function (row, col) {
      undoCmds.push(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('setValue', {
        selection: {
          row: row,
          col: col,
          rowCount: 1,
          colCount: 1
        },
        value: Object(_util__WEBPACK_IMPORTED_MODULE_0__["safeGet"])(dataTable, [row, col, 'value']) || ''
      }));
    });
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  if (sync) this.sendCmds(commands);
  return commands;
});

/***/ }),

/***/ "oj7Y":
/*!****************************!*\
  !*** ./src/lib/emitter.js ***!
  \****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.promise */ "VRzm");
/* harmony import */ var core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_promise__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./util */ "8e1d");


var emitter = new _util__WEBPACK_IMPORTED_MODULE_1__["Emitter"]();
/* harmony default export */ __webpack_exports__["default"] = (emitter);
Object(_util__WEBPACK_IMPORTED_MODULE_1__["extend"])(emitter, {
  WINDOW_MSG: 'window-msg',
  SHOW_HEADER_ALERT: 'show-header-alert',
  SHOW_TIPS: 'SHOW_TIPS',
  SHOW_LOADING: 'SHOW_LOADING',
  HIDE_LOADING: 'HIDE_LOADING',
  SHOW_MSG: 'SHOW_MSG',
  SET_READ_ONLY: 'SET_READ_ONLY',
  PASTE_MSG: 'PASTE_MSG',
  SHOW_COMMENT: 'SHOW_COMMENT',
  HIDE_COMMENT: 'HIDE_COMMENT',
  UPDATE_COMMENT: 'UPDATE_COMMENT',
  SHOW_AT: 'SHOW_AT',
  HIDE_AT: 'HIDE_AT',
  SELECT_AT: 'SELECT_AT',
  TOGGLE_HEADERMENU: 'TOGGLE_HEADERMENU',
  TOGGLE_CELLMENU: 'TOGGLE_CELLMENU',
  UPDATE_USER_REGIONS: "UPDATE_USER_REGIONS",
  UPDATE_REGION: "UPDATE_REGION",
  CHANGE_REGION_AREA: "CHANGE_REGION_AREA",
  CELL_MOUSE_ENTER: "CELL_MOUSE_ENTER",
  CELL_MOUSER_LEAVE: "CELL_MOUSER_LEAVE",
  UPDATE_FXEDITOR_VALUE: "UPDATE_FXEDITOR_VALUE",
  UPDATE_FILENAME: "UPDATE_FILENAME",
  SHOW_TOPTIPS: "SHOW_TOPTIPS"
});

/***/ }),

/***/ "pezt":
/*!*********************************************!*\
  !*** ./src/lib/changeset/SheetChangeSet.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return SheetChangeSet; });
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.split */ "KKXr");
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _PosInfo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PosInfo */ "Lt7s");
/* harmony import */ var _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./CmdStrParser */ "ZqfF");
/* harmony import */ var _Operation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Operation */ "yfGy");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../util */ "8e1d");








/* eslint-disable camelcase */
// changeset的主类，Operation的集合

var SheetChangeSet =
/*#__PURE__*/
function () {
  function SheetChangeSet(options) {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_2__["default"])(this, SheetChangeSet);

    this.operations = [];

    if (options && options.cmds) {
      this.appendCmds(options.cmds);
    }
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_3__["default"])(SheetChangeSet, [{
    key: "getArrCmds",
    value: function getArrCmds() {
      var cmds = [];

      for (var i = 0; i < this.operations.length; ++i) {
        var cmd = this.operations[i].getCmd();

        if (cmd.length) {
          cmds.push(cmd);
        }
      }

      return cmds;
    }
  }, {
    key: "getStrCmds",
    value: function getStrCmds() {
      return (this.getArrCmds() || []).join('\n');
    }
  }, {
    key: "appendCmds",
    value: function appendCmds(cmds) {
      var arrCmds = cmds;

      if (!Array.isArray(cmds)) {
        arrCmds = cmds.split('\n') || [];
      }

      for (var i = 0; i < arrCmds.length; ++i) {
        this.appendCmd(arrCmds[i]);
      }
    } // 将后合入的指令依次向前将指令进行合入

  }, {
    key: "appendCmd",
    value: function appendCmd(cmd) {
      if (!cmd || !cmd.length) {
        return;
      }

      var operation = new _Operation__WEBPACK_IMPORTED_MODULE_6__["default"](cmd);
      var parser = new _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"](operation.cmd);
      var cmdType = parser.NextToken();
      var pos;
      operation.type = cmdType.toLowerCase();
      this.operations.push(operation);
      var posStr, range, posInfo;
      var what, attrib;
      var rest, cr1, cr2;

      switch (operation.type) {
        case 'insertcol':
          posStr = parser.NextToken();
          range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(posStr);
          posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_4__["default"]();
          posInfo.col = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].RangeTocol(range.cr1);
          operation.posInfos.push(posInfo);
          operation.originStrRange = posStr;
          break;

        case 'insertrow':
          posStr = parser.NextToken();
          range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(posStr);
          posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_4__["default"]();
          posInfo.row = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].RangeTorow(range.cr1);
          operation.posInfos.push(posInfo);
          operation.originStrRange = posStr;
          break;

        case 'deletecol':
          posStr = parser.NextToken();
          range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(posStr);
          posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_4__["default"]();
          posInfo.col = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].RangeTocol(range.cr1);
          operation.posInfos.push(posInfo);
          operation.originStrRange = posStr;

          for (var i = range.cr1.col; i < range.cr2.col; ++i // 将删除多列的命令改为一列列删，删完后再合并。合并的逻辑暂时不加
          ) {
            this.operations.push(operation.makeACopy());
          }

          break;

        case 'deleterow':
          posStr = parser.NextToken();
          range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(posStr);
          posInfo = new _PosInfo__WEBPACK_IMPORTED_MODULE_4__["default"]();
          posInfo.row = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].RangeTorow(range.cr1);
          operation.posInfos.push(posInfo);
          operation.originStrRange = posStr;

          for (var _i = range.cr1.row; _i < range.cr2.row; ++_i // 将删除多行的命令改为一行行删，删完后再合并。合并的逻辑暂时不加
          ) {
            this.operations.push(operation.makeACopy());
          }

          break;

        case 'set':
          // eg: set A1:B2 text 4  ＝>
          what = parser.NextToken(); // A1:B2

          attrib = parser.NextToken(); // text

          operation.originStrRange = what;
          operation.secondType_Origin = attrib; // text

          operation.value = parser.RestOfString(); // 4

          rest = operation.value; // let cr1, cr2;
          // if(/^[a-z]{1,2}(:[a-z]{1,2})?$/i.test(what)) {

          if (attrib === 'width') {
            what = what.toUpperCase();

            var _pos = what.indexOf(':');

            if (_pos >= 0) {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what.substring(0, _pos) + '1');
              cr2 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what.substring(_pos + 1) + '1');
            } else {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what + '1');
              cr2 = cr1;
            }

            operation.posInfos = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].CrsToPosArr(cr1, cr2); // what ＝> pos

            operation.secondType = attrib; // } else if (/^\d+(:\d+)?$/i.test(what)) {
          } else if (attrib === 'freeze') {
            operation.posInfos = [what];
            operation.nOpSecondType = attrib;
          } else if (attrib === 'height') {
            what = what.toUpperCase();

            var _pos2 = what.indexOf(':');

            if (_pos2 >= 0) {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what.substring(0, _pos2));
              cr2 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what.substring(_pos2 + 1));
            } else {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what);
              cr2 = cr1;
            }

            operation.posInfos = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].CrsToPosArr(cr1, cr2);
            operation.secondType = attrib;
          } else if (/^[a-z]{1,2}\d+(:[a-z]{1,2}\d+)?$/i.test(what)) {
            // 这里是setvalue的地方
            range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(what);
            cr1 = range.cr1;
            cr2 = range.cr2;
            operation.posInfos = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].CrsToPosArr(cr1, cr2);
            operation.secondType = 'value';

            if (attrib === 'value') {
              pos = rest.indexOf(' ');
            } else if (attrib === 'text') {
              pos = rest.indexOf(' ');
            } else if (attrib === 'constant') {
              // else if (attrib === 'formula') {
              // } 
              pos = rest.indexOf(' ');
            } // } else if (attrib === 'empty') {
            // } else if (attrib === 'all') {
            // } else if (/^b[trbl]$/.test(attrib)) {
            else if (/^b[trbl]$/.test(attrib)) {
                operation.secondType = 'border';
              } else if (attrib === 'color' || attrib === 'bgcolor') {
                operation.secondType = attrib;
              } else if (attrib === 'layout' || attrib === 'cellformat') {
                operation.secondType = attrib;
              } else if (attrib === 'font') {
                operation.secondType = attrib;
              } else if (attrib === 'textvalueformat' || attrib === 'nontextvalueformat') {
                operation.secondType = attrib;
              } else if (attrib === 'cssc') {
                operation.secondType = attrib;
              } else if (attrib === 'csss') {
                operation.secondType = attrib;
              } else if (attrib === 'mod') {
                operation.secondType = attrib;
              } else if (attrib === 'comment') {
                operation.secondType = attrib;
              } else if (attrib === 'readonly') {
                operation.secondType = attrib;
              } else {
                var errortext = 'unknown set op';
                operation.secondType = errortext;
              }
          }

          break;

        default:
          what = parser.NextToken(); // 位置字符串

          attrib = parser.NextToken();
          operation.originStrRange = what;
          operation.secondType_Origin = attrib;
          operation.secondType = attrib;
          operation.value = parser.RestOfString();

          if (/^[a-z]{1,2}(:[a-z]{1,2})?$/i.test(what)) {
            what = what.toUpperCase();
            pos = what.indexOf(':');

            if (pos >= 0) {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what.substring(0, pos) + '1');
              cr2 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what.substring(pos + 1) + '1');
            } else {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow(what + '1');
              cr2 = cr1;
            }
          } else if (/^\d+(:\d+)?$/i.test(what)) {
            what = what.toUpperCase();
            pos = what.indexOf(':');

            if (pos >= 0) {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what.substring(0, pos));
              cr2 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what.substring(pos + 1));
            } else {
              cr1 = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].coordToColRow('A' + what);
              cr2 = cr1;
            }
          } else if (/^[a-z]{1,2}\d+(:[a-z]{1,2}\d+)?$/i.test(what)) {
            range = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].ParseRange(what);
            cr1 = range.cr1;
            cr2 = range.cr2;
          }

          operation.posInfos = _CmdStrParser__WEBPACK_IMPORTED_MODULE_5__["default"].CrsToPosArr(cr1, cr2);
          break;
      }
    } // 计算删除或者insert前，指令的老行列

  }, {
    key: "calculateOldIndex",
    value: function calculateOldIndex() {
      if (!this.operations.length) {
        return;
      }

      for (var i = 0; i < this.operations.length; ++i) {
        var operation = this.operations[i];

        for (var k = 0; k < operation.posInfos.length; ++k) {
          var pos = operation.posInfos[k];
          pos.row && (pos.row.oldIndex = pos.row.index);
          pos.col && (pos.col.oldIndex = pos.col.index);
        }

        for (var j = i - 1; j >= 0; --j) {
          var previousOperation = this.operations[j];
          this.calculateOldIndexBeforeInsertOrDelete(previousOperation, operation);
        }
      }
    } // proc两个op的相对位置，只有发生了行、列的增加或者删除才触发

  }, {
    key: "calculateOldIndexBeforeInsertOrDelete",
    value: function calculateOldIndexBeforeInsertOrDelete(previousOperation, operation) {
      if (!previousOperation.posInfos || !operation.posInfos) {
        return;
      }

      var offset = 0;
      var attrib = '';
      var preIsInsertCmd = false; // 当前用户新增行或列，说明用户依赖新行或列

      if (/^insert/.test(operation.type)) {
        attrib = operation.type.slice(6);
        operation.posInfos[0][attrib].isDependOnNew = true;
        return;
      } // 判断前操作命名是否有用户新增或者删除行或列


      if (/^insert/.test(previousOperation.type)) {
        offset = -1;
        attrib = previousOperation.type.slice(6);
        preIsInsertCmd = true;
      } else if (/^delete/.test(previousOperation.type)) {
        offset = 1;
        attrib = previousOperation.type.slice(6);
      }

      this.calculateOldRcEnumCollection(previousOperation, operation, offset, attrib);

      if (offset === 0) {
        return;
      } // insert 后续的命令oldindex应该相对-1，delete 后续命令的oldindex应该相对+1


      previousOperation.posInfos.forEach(function (prePos) {
        operation.posInfos.forEach(function (pos) {
          if (pos[attrib] && !pos[attrib].isDependOnNew) {
            if (prePos[attrib] && prePos[attrib].oldIndex <= pos[attrib].oldIndex) {
              // 正常都是直接执行偏移
              pos[attrib].oldIndex += offset;

              if (preIsInsertCmd && pos[attrib].oldIndex === prePos[attrib].oldIndex - 1) {
                pos[attrib].isDependOnNew = true; // insertrow 5, aet A5 , 这时候依赖的第5列
                // insertrow 2, insertrow 2, set A3, 这是说明依赖的是第2列
                // if (pos[attrib].oldIndex === 0) {

                pos[attrib].oldIndex = pos[attrib].index; // }
              }
            }
          }
        });
      });
    }
    /**
     * 合并或排序区域的老行列散列集合
     * {
     *     enum: {
     *         row: [1, 2, 3],
     *         col: [1, 2, 3]
     *     }
     * }
     */

  }, {
    key: "calculateOldRcEnumCollection",
    value: function calculateOldRcEnumCollection(previousOperation, operation, offset, attrib) {
      // 计算出merge 或者 unmerge包含的行和列枚举
      if (operation.type === 'merge' || operation.type === 'unmerge' || operation.type === 'sort') {
        // 需要获取合并单元格的原始宽列的散列，进行逐一碰撞;
        var enumCollection = operation.calculateCrEnumCollection();
        if (offset === 0) return; // 仅当前面有删除和新增的时候，需要进行剔除操作

        var prePos = previousOperation.posInfos[0];
        enumCollection[attrib] = enumCollection[attrib].map(function (attribIndex) {
          if (prePos[attrib].oldIndex <= attribIndex) {
            attribIndex += offset;

            if (offset === -1 && attribIndex === prePos[attrib].oldIndex - 1) {
              return;
            }
          }

          return attribIndex;
        }).filter(function (attribIndex) {
          return attribIndex !== undefined;
        });
      }
    }
    /**
     * 类似服务端处理冲突，按照时间顺序转换
     */

  }, {
    key: "transformAfter",
    value: function transformAfter(serverChangeSet) {
      // 克隆备份，避免修改本身，导致多次计算merge的erum时候，导致计算错误
      var clientChangeSet = Object(_util__WEBPACK_IMPORTED_MODULE_7__["cloneObject"])(this);
      serverChangeSet = Object(_util__WEBPACK_IMPORTED_MODULE_7__["cloneObject"])(serverChangeSet);
      var transformedChangetSet = new SheetChangeSet();
      var transformedOperation;
      clientChangeSet.calculateOldIndex();
      serverChangeSet.calculateOldIndex();
      clientChangeSet.operations.forEach(function (clientOperation) {
        transformedOperation = clientOperation.makeACopy();
        serverChangeSet.operations.forEach(function (serverOperation) {
          transformedOperation.transformAfter(serverOperation);
        });
        transformedChangetSet.operations.push(transformedOperation);
      });
      return transformedChangetSet;
    }
    /**
     * 类似客户端处理冲突，需要对服务器的相对于client转化后，合并到excel中
     */

  }, {
    key: "transformReverse",
    value: function transformReverse(clientChangeSet) {
      // 克隆备份，避免修改本身，导致多次计算merge的erum时候，导致计算错误
      var serverChangeSet = Object(_util__WEBPACK_IMPORTED_MODULE_7__["cloneObject"])(this);
      clientChangeSet = Object(_util__WEBPACK_IMPORTED_MODULE_7__["cloneObject"])(clientChangeSet);
      var transformedChangetSet = new SheetChangeSet();
      var transformedOperation;
      clientChangeSet.calculateOldIndex();
      serverChangeSet.calculateOldIndex();
      serverChangeSet.operations.forEach(function (serverOperation) {
        transformedOperation = serverOperation.makeACopy();
        clientChangeSet.operations.forEach(function (clientOperation) {
          transformedOperation.transformReverse(clientOperation);
        });
        transformedChangetSet.operations.push(transformedOperation);
      });
      return transformedChangetSet;
    }
  }]);

  return SheetChangeSet;
}();



/***/ }),

/***/ "qu79":
/*!*****************************!*\
  !*** ./src/lib/parseCmd.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.split */ "KKXr");
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/slicedToArray */ "k5N+");
/* harmony import */ var _changeset__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./changeset */ "9pe4");
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./util */ "8e1d");


// import Logger from './Logger';

 // let logger = new Logger('parseCmd');

/* harmony default export */ __webpack_exports__["default"] = (function (command) {
  if (Object(_util__WEBPACK_IMPORTED_MODULE_3__["isStr"])(command)) command = new _changeset__WEBPACK_IMPORTED_MODULE_2__["CmdStrParser"](command); // logger.debug(command.RestOfStringNoMove());

  var type = command.NextToken(),
      pos,
      what,
      attrib,
      rest,
      value,
      selection,
      index;

  switch (type) {
    case 'set':
      what = command.NextToken();
      attrib = command.NextToken();
      rest = command.RestOfString();

      if (what === 'sheet') {
        if (attrib === 'freeze') {
          var _rest$split = rest.split(/\|/g),
              _rest$split2 = Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_rest$split, 3),
              col = _rest$split2[0],
              row = _rest$split2[1],
              _type = _rest$split2[2];

          switch (_type) {
            case 'freezeRow':
              _type = 'row';
              break;

            case 'freezeCol':
              _type = 'column';
              break;

            case 'freezeRowCol':
              _type = 'rowColumn';
              break;

            case 'freezeCancel':
              _type = 'cancel';
              break;
          }

          return {
            name: 'freeze',
            type: _type,
            row: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(row),
            col: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(col)
          };
        }
      } else if (what === 'image') {
        if (rest) {
          return {
            name: 'setImage',
            id: attrib,
            value: parseImageParts(rest.split(':'))
          };
        } else {
          return {
            name: 'setImage',
            id: attrib
          };
        }
      } else if (isCol(what)) {
        index = Object(_util__WEBPACK_IMPORTED_MODULE_3__["labelToCol"])(what);

        if (attrib === 'width') {
          return {
            name: 'setColWidth',
            index: index,
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        }
      } else if (isRow(what)) {
        index = Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(what) - 1;

        if (attrib === 'height') {
          return {
            name: 'setRowHeight',
            index: index,
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        }
      } else if (isRange(what)) {
        selection = Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what);

        if (attrib === 'text') {
          pos = rest.indexOf(' ');
          value = decodeURIComponent(Object(_util__WEBPACK_IMPORTED_MODULE_3__["decodeFromSave"])(rest.substring(pos + 1)));
          return {
            name: 'setValue',
            selection: selection,
            value: value
          };
        } else if (attrib === 'weight') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'bold',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        } else if (attrib === 'italic') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'italic',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        } else if (attrib === 'strike') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'strike',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        } else if (attrib === 'textwrap') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'textWrap',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        } else if (attrib === 'cellformat') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'hAlign',
            value: rest
          };
        } else if (attrib === 'layout') {
          if (rest) rest = rest.split(';')[1].split(':')[1];
          return {
            name: 'setStyle',
            selection: selection,
            property: 'vAlign',
            value: rest
          };
        } else if (attrib === 'color') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'foreColor',
            value: rest
          };
        } else if (attrib === 'bgcolor') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'backColor',
            value: rest
          };
        } else if (attrib === 'size') {
          return {
            name: 'setStyle',
            selection: selection,
            property: 'fontSize',
            value: Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(rest)
          };
        } else if (isBorder(attrib)) {
          var property = attrib;

          switch (property) {
            case 'bt':
              property = 'borderTop';
              break;

            case 'br':
              property = 'borderRight';
              break;

            case 'bb':
              property = 'borderBottom';
              break;

            case 'bl':
              property = 'borderLeft';
              break;
          }

          return {
            name: 'setStyle',
            selection: selection,
            property: property,
            value: rest
          };
        } else if (attrib === 'formula') {
          return {
            name: 'setFormula',
            selection: selection,
            value: rest
          };
        } else if (attrib === 'commentId') {
          return {
            name: 'setComment',
            selection: selection,
            value: rest
          };
        }
      }

      break;

    case 'merge':
      what = command.NextToken();
      return {
        name: 'merge',
        value: 1,
        selection: Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what)
      };

    case 'unmerge':
      what = command.NextToken();
      return {
        name: 'merge',
        value: 0,
        selection: Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what)
      };

    case 'insertrow':
      what = command.NextToken();
      return {
        name: 'insertRow',
        index: Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what).row
      };

    case 'insertcol':
      what = command.NextToken();
      return {
        name: 'insertCol',
        index: Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what).col
      };

    case 'deletecol':
      what = command.NextToken();
      selection = Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what);
      return {
        name: 'deleteCol',
        index: selection.col,
        count: selection.colCount
      };

    case 'deleterow':
      what = command.NextToken();
      selection = Object(_util__WEBPACK_IMPORTED_MODULE_3__["rangeToSelection"])(what);
      return {
        name: 'deleteRow',
        index: selection.row,
        count: selection.rowCount
      };
  }
});
var regCoord = /^[a-z]{1,2}\d+(:[a-z]{1,2}\d+)?$/i;

function isRange(str) {
  return regCoord.test(str);
}

var regRow = /^\d+(:\d+)?$/;

function isRow(str) {
  return regRow.test(str);
}

var regCol = /^[a-z]{1,2}(:[a-z]{1,2})?$/i;

function isCol(str) {
  return regCol.test(str);
}

var regBorder = /^b[trbl]$/;

function isBorder(str) {
  return regBorder.test(str);
}

function parseImageParts(parts) {
  var image = {};
  var i = 1,
      type;

  while (type = parts[i++]) {
    switch (type) {
      case 's':
        image.src = decodeURIComponent(parts[i++]);
        break;

      case 'x':
        image.x = Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(parts[i++]);
        break;

      case 'y':
        image.y = Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(parts[i++]);
        break;

      case 'w':
        image.width = Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(parts[i++]);
        break;

      case 'h':
        image.height = Object(_util__WEBPACK_IMPORTED_MODULE_3__["toNum"])(parts[i++]);
        break;
    }
  }

  return image;
}

/***/ }),

/***/ "sQsY":
/*!****************************************!*\
  !*** ./src/lib/commands/dragFilled.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _generateCmd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../generateCmd */ "11+Z");


/* harmony default export */ __webpack_exports__["default"] = (function () {
  var _ref = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      selection = _ref.selection,
      undoCmds = _ref.undoCmds,
      _ref$undoStack = _ref.undoStack,
      undoStack = _ref$undoStack === void 0 ? true : _ref$undoStack,
      _ref$undo = _ref.undo,
      undo = _ref$undo === void 0 ? true : _ref$undo;

  var undoManager = this.undoManager; // 添加命令到commands数组

  var commands = []; // 自动填充执行命令

  commands = commands.concat(this.execute('setAll', {
    selection: selection,
    value: this.getRangeData(selection),
    sync: true
  })); // 清除合并单元格撤销命令

  var spans = this.getRangeData(selection).spans;

  if (spans && spans.length > 0) {
    spans.forEach(function (span) {
      undoCmds = undoCmds.concat(Object(_generateCmd__WEBPACK_IMPORTED_MODULE_1__["default"])('merge', {
        selection: span,
        value: 0
      }));
    });
  } // 新建撤销管理器


  if (undoStack) undoManager.addUndoStack(); // 一起压入撤销栈

  if (undo) {
    undoManager.addUndo({
      commands: commands,
      undoCmds: undoCmds
    });
  }

  return {
    commands: commands,
    undoCmds: undoCmds
  };
});

/***/ }),

/***/ "xCHG":
/*!******************************************************!*\
  !*** ./src/lib/plugins/copyPaste/ClipboardHelper.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ClipboardHelper; });
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.regexp.split */ "KKXr");
/* harmony import */ var core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_split__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.constructor */ "Oyvg");
/* harmony import */ var core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_constructor__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.regexp.replace */ "pIFo");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var _lib_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../lib/util */ "8e1d");







var ClipboardHelper =
/*#__PURE__*/
function () {
  function ClipboardHelper() {
    var context = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : null;

    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, ClipboardHelper);

    this.context = context;
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_4__["default"])(ClipboardHelper, [{
    key: "pxToNum",
    value: function pxToNum(str) {
      return Object(_lib_util__WEBPACK_IMPORTED_MODULE_5__["toNum"])(str.replace('px', ''));
    }
  }, {
    key: "getFont",
    value: function getFont(style) {
      var fontStyle = style.fontStyle,
          fontSize = style.fontSize,
          fontVariant = style.fontVariant,
          fontWeight = style.fontWeight,
          lineHeight = style.lineHeight,
          font = {};
      /* eslint-disable */

      if ('normal' !== fontStyle) {
        font.fontStyle = fontStyle;
      }

      if ('normal' !== fontVariant) {
        font.fontVariant = fontVariant;
      }

      if ('normal' !== fontWeight && '400' !== fontWeight) {
        font.fontWeight = fontWeight;
      }

      if ('normal' !== lineHeight) {
        font.lineHeight = lineHeight;
      }

      font.fontSize = this.pxToNum(fontSize);
      return font;
    }
    /**
     * [parseTable 解析table dom表的数据]
     * @param  {domElement}  table      [tableDom]
     * @param  {Boolean} isGetStyle [是否获取cell的style]
     * @return {Array}             [解析后的数组]
     */

  }, {
    key: "parseTable",
    value: function parseTable(table, isGetStyle) {
      var dataSource = [];

      if (table.getAttribute('data-start-row')) {
        dataSource.startPos = {
          row: +table.getAttribute('data-start-row'),
          col: +table.getAttribute('data-start-col')
        };
      }

      for (var rowIndex = 0, rowLength = table.rows.length; rowIndex < rowLength; rowIndex++) {
        var row = table.rows[rowIndex];
        var rowData = dataSource[rowIndex] || (dataSource[rowIndex] = []);

        for (var colIndex = 0, realUseColIndex = 0, colLength = row.cells.length; colIndex < colLength; colIndex++) {
          var cell = row.cells[colIndex];

          for (; rowData[realUseColIndex];) {
            realUseColIndex++;
          }

          var cellData = rowData[realUseColIndex] = {};
          var cellStyle;

          if (isGetStyle) {
            cellData.style = cellStyle = this.getStyle(cell);
          }

          cellData.text = cell.textContent;
          cellData.rowSpan = cell.rowSpan;
          cellData.colSpan = cell.colSpan;

          for (var m = 0; m < cell.rowSpan; m++) {
            for (var g = 0; g < cell.colSpan; g++) {
              if (!(0 === m && 0 === g)) {
                (dataSource[rowIndex + m] || (dataSource[rowIndex + m] = []))[realUseColIndex + g] = {
                  style: cellStyle || {},
                  text: '',
                  rowSpan: 1,
                  colSpan: 1
                };
              }
            }
          }

          realUseColIndex += cell.colSpan;
        }
      }

      return dataSource;
    }
    /**
     * [getStyle 获取单元格的样式]
     * @param  {domElement} cell td单元格
     * @return {Object} Style
     * {
     *      font : {
     *          fontStyle: '',  // 斜体
     *          fontWeight: '', // 400为正常粗细
     *          fontSize: '', // 字体大小
     *      }
     *      color: '', // 字体颜色
     *      backgroundColor: '', //背景颜色
     *
     *      textDecoration: 'line-through underline', // 下划线或者中划线
     *      verticalAlign: '', // 垂直对齐方式
     *      textAlign: '', // 水平对齐方式
     *
     *      borderLeft: '', // TODO 目前不需要后续可以追加
     *      borderRight: '',
     *      borderTop: '',
     *      borderBottom: '',
     *  }
     */

  }, {
    key: "getStyle",
    value: function getStyle(cell) {
      var fontDom = cell.getElementsByTagName('font')[0],
          originStyle = getComputedStyle(cell),
          resStyle = {};
      var borderTop = getBorder(originStyle.borderTop);
      if (borderTop) resStyle.borderTop = borderTop;
      var borderRight = getBorder(originStyle.borderRight);
      if (borderRight) resStyle.borderRight = borderRight;
      var borderBottom = getBorder(originStyle.borderBottom);
      if (borderBottom) resStyle.borderBottom = borderBottom;
      var borderLeft = getBorder(originStyle.borderLeft);
      if (borderLeft) resStyle.borderLeft = borderLeft; // 处理背景色

      var backgroundColor = originStyle.backgroundColor;

      if (backgroundColor) {
        resStyle.backgroundColor = backgroundColor;
      } // 处理字体颜色


      if (originStyle.color) {
        resStyle.color = originStyle.color;
      } // 处理字体


      if (fontDom) {
        if (fontDom.color) {
          resStyle.color = fontDom.color;
        }

        resStyle.font = this.getFont(getComputedStyle(fontDom));
      } else {
        resStyle.font = this.getFont(originStyle);
      } // 处理垂直居中


      var verticalAlign = originStyle.verticalAlign;

      if (verticalAlign) {
        resStyle.verticalAlign = verticalAlign;
      } // 处理水平居中


      var textAlign = originStyle.textAlign;

      if (textAlign && textAlign !== 'start') {
        resStyle.textAlign = textAlign;
      } // 处理下划线和中划线


      var textDecoration = originStyle.textDecoration;

      if (cell.getElementsByTagName('u').length > 0 && !/underline/i.test(textDecoration)) {
        textDecoration += 'underline';
      }

      if (cell.getElementsByTagName('s').length > 0 && !/line-through/i.test(textDecoration)) {
        textDecoration += 'line-through';
      }

      resStyle.textDecoration = textDecoration;
      return resStyle;
    }
  }, {
    key: "parseHtml",
    value: function parseHtml(dom, originHtml) {
      if (dom) {
        var tables = dom.getElementsByTagName('table');

        if (tables.length > 0) {
          var table = tables[0]; // 针对这种HTML只处理并识别第一个table

          return this.parseTable(table, true);
        } else if (originHtml) {
          /(<html(.*?)>[\s\S]*?<\/html>)/i.test(originHtml) && (originHtml = RegExp.$1);
          dom.innerHTML = originHtml.replace(/<head>[\s\S]*?<\/head>/, '');
          return [[{
            text: dom.textContent.trim()
          }]];
        } else {
          return [[{
            text: dom.textContent
          }]];
        }
      }

      return [[{
        text: ''
      }]];
    }
    /**
     * [getPureText 获取纯字符串]
     * @param  {domElement} dom        目标元素
     * @param  {String} originHtml 原来的html内容
     * @return {String}            提取出来的纯字符串
     */

  }, {
    key: "getPureText",
    value: function getPureText(dom, originHtml) {
      var textArr = [];
      var rowData;
      var cellContent;

      if (dom) {
        var tables = dom.getElementsByTagName('table');

        if (tables.length > 0) {
          var table = tables[0]; // 针对这种HTML只处理并识别第一个table

          var tableDataSource = this.parseTable(table, false);

          for (var rowIndex = 0, rowLength = tableDataSource.length; rowIndex < rowLength; rowIndex++) {
            rowData = tableDataSource[rowIndex];

            for (var colIndex = 0, colLength = rowData.length; colIndex < colLength; colIndex++) {
              cellContent = rowData[colIndex] ? rowData[colIndex].text : '';
              cellContent.indexOf('\n') >= 0 && (cellContent = '"' + cellContent + '"');
              textArr.push(cellContent.trim());
              colIndex < rowLength - 1 && textArr.push('\t');
            }

            rowIndex < rowLength - 1 && textArr.push('\r\n');
          }
        } else if (originHtml) {
          dom.innerHTML = originHtml.replace(/<head>[\s\S]*?<\/head>/, '');
          textArr.push(dom.textContent.trim());
        } else {
          textArr.push(dom.textContent);
        }
      }

      return textArr.join('');
    }
    /**
     * [normalize 处理字符串]
     */

  }, {
    key: "normalize",
    value: function normalize(text) {
      var textArr = [];
      var preHasDoubleQuotes = false;

      if (text) {
        for (var i = 0, length = text.length; i < length; i++) {
          var char = text[i];
          /* eslint-disable */

          if ('"' === char) {
            preHasDoubleQuotes = !preHasDoubleQuotes;
            textArr.push('"');
          } else if (preHasDoubleQuotes || '\n' !== char) {
            textArr.push(char);
          } else {
            textArr.push('\r\n');
          }
        }

        return textArr.join('');
      }

      return '';
    }
    /**
     * [getRangeHtml 获取表格本身的html]
     * @return  {String} selected 拼装成的HTML
     */

  }, {
    key: "getRangeHtml",
    value: function getRangeHtml() {
      var hot = this.context.hot;
      var selectedRange = hot.getSelectedRange();
      var start = selectedRange.getTopLeftCorner();
      var end = selectedRange.getBottomRightCorner();
      var _ref = [start.row, start.col, end.row, end.col],
          startRow = _ref[0],
          startCol = _ref[1],
          endRow = _ref[2],
          endCol = _ref[3];
      var table = [];

      for (var rowIndex = 0, rowLength = endRow - startRow + 1; rowIndex < rowLength; rowIndex++) {
        var row = table[rowIndex] || (table[rowIndex] = []);

        for (var colIndex = 0, colLength = endCol - startCol + 1; colIndex < colLength; colIndex++) {
          if (row[colIndex] !== undefined) continue;
          var cell = hot.getCell(startRow + rowIndex, startCol + colIndex);
          var rowSpan = parseInt(cell.getAttribute('rowspan') || 1);
          var colSpan = parseInt(cell.getAttribute('colspan') || 1);
          row[colIndex] = cell.outerHTML;

          for (var m = 0; m < rowSpan; m++) {
            for (var g = 0; g < colSpan; g++) {
              if (m > 0 || g > 0) {
                table[rowIndex + m] || (table[rowIndex + m] = []);
                table[rowIndex + m][colIndex + g] = '';
              }
            }
          }
        }
      }

      var html = '<table>';
      table.forEach(function (row) {
        html += '<tr>' + row.join('') + '</tr>';
      });
      html += '</table>';
      return html;
    }
  }]);

  return ClipboardHelper;
}();



function getBorder(value) {
  if (value.indexOf('none') > -1) return '';
  value = value.split(' ').slice(2);
  return "1px solid ".concat(value.join(' '));
}

/***/ }),

/***/ "yfGy":
/*!****************************************!*\
  !*** ./src/lib/changeset/Operation.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Operation; });
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es6.array.sort */ "Vd3H");
/* harmony import */ var core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_array_sort__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es6.regexp.replace */ "pIFo");
/* harmony import */ var core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_replace__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es6.regexp.to-string */ "a1Th");
/* harmony import */ var core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es6_regexp_to_string__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/classCallCheck */ "xmWZ");
/* harmony import */ var D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/builtin/es6/createClass */ "qpph");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! core-js/modules/web.dom.iterable */ "rGqo");
/* harmony import */ var core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_iterable__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../util */ "8e1d");
/* harmony import */ var _Logger__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Logger */ "GONd");
/* harmony import */ var _CmdStrParser__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./CmdStrParser */ "ZqfF");









var logger = new _Logger__WEBPACK_IMPORTED_MODULE_7__["default"]('changeset.Operation');

function posInfoIsDependentOnNew(opPos) {
  return opPos.row && opPos.row.isDependOnNew || opPos.col && opPos.col.isDependOnNew;
}

function isSameOldIndexInfo(info1, info2) {
  if (info1 && !info2 || !info1 && info2) {
    return false;
  }

  if (!info1 || info1.oldIndex === info2.oldIndex) {
    return true;
  }

  return false;
}

function isSameOldPos(opPos1, opPos2) {
  return isSameOldIndexInfo(opPos1.row, opPos2.row) && isSameOldIndexInfo(opPos1.col, opPos2.col);
} // 区域碰撞
// 1 表示有交集
// 0 表示没交集


function regionCollision(operation, baseOperation) {
  var crEnumCollection = operation.calculateCrEnumCollection();
  var baseCrEnumCollection = baseOperation.calculateCrEnumCollection();
  var rowIntersection = Object(_util__WEBPACK_IMPORTED_MODULE_6__["intersect"])(crEnumCollection.row, baseCrEnumCollection.row);
  var colIntersection = Object(_util__WEBPACK_IMPORTED_MODULE_6__["intersect"])(crEnumCollection.col, baseCrEnumCollection.col);
  logger.info('rowIntersection:', rowIntersection, ';colIntersection', colIntersection);

  if (rowIntersection && rowIntersection.length > 0 && colIntersection && colIntersection.length > 0) {
    return 1;
  }

  return 0;
} // 判断区域是否包含关系


function isContain(operation, baseOperation) {
  var crEnumCollection = operation.calculateCrEnumCollection();
  var baseCrEnumCollection = baseOperation.calculateCrEnumCollection();
  var result = Object(_util__WEBPACK_IMPORTED_MODULE_6__["difference"])(baseCrEnumCollection.row, crEnumCollection.row).length === 0 && Object(_util__WEBPACK_IMPORTED_MODULE_6__["difference"])(baseCrEnumCollection.col, crEnumCollection.col).length === 0;
  logger.info('rowdiff:', Object(_util__WEBPACK_IMPORTED_MODULE_6__["difference"])(baseCrEnumCollection.row, crEnumCollection.row), ';col:', Object(_util__WEBPACK_IMPORTED_MODULE_6__["difference"])(baseCrEnumCollection.col, crEnumCollection.col), ';isContain:', result);
  return result;
} // 取区域的交集


function mergeRegion(operation, baseOperation) {
  var row = [];
  var col = [];
  [operation, baseOperation].forEach(function (op) {
    op.posInfos.forEach(function (pos) {
      row.push(pos.row.index);
      col.push(pos.col.index);
    });
  });
  operation.posInfos[0].row.index = Math.min.apply(Math, row);
  operation.posInfos[1].row.index = Math.max.apply(Math, row);
  operation.posInfos[0].col.index = Math.min.apply(Math, col);
  operation.posInfos[1].col.index = Math.max.apply(Math, col);
  return operation;
}
/**
 * 原子操作，可以认为就只有一条指令
 */


var Operation =
/*#__PURE__*/
function () {
  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_4__["default"])(Operation, null, [{
    key: "indexInfoToRow",
    // 获取游标对象的行信息
    value: function indexInfoToRow(indexInfo) {
      if (!indexInfo) {
        return '';
      }

      return indexInfo.index.toString();
    } // 获取游标对象的列信息。如果是26内，则A-Z，否则为AC类似这样的

  }, {
    key: "indexInfoToCol",
    value: function indexInfoToCol(indexInfo) {
      if (!indexInfo) {
        return '';
      }

      if (indexInfo.index <= 26) {
        return String.fromCharCode(64 + indexInfo.index); // 101 is A's asii value
      } else {
        var n1 = indexInfo.index / 26;
        var n2 = indexInfo.index % 26;
        return String.fromCharCode(64 + n1) + String.fromCharCode(64 + n2);
      }
    }
  }]);

  function Operation(cmd) {
    Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_classCallCheck__WEBPACK_IMPORTED_MODULE_3__["default"])(this, Operation);

    this.cmd = cmd;
    this.isUpdatedAfterTransform = false;
    this.type = ''; // 指令的基本操作类型，如 set、insertRow

    this.originStrRange = '';
    this.posInfos = []; // cache所有PosInfo数组

    this.secondType = ''; // 单元格的操作类型的归属类型
    // this.secondType_Origin = ''; // 单元格的操作类型，value、text、format等
    // this.value = '';
  }

  Object(D_Projects_webdoceditnjlogic_excel_frontend_spreadjs_node_modules_babel_runtime_helpers_builtin_es6_createClass__WEBPACK_IMPORTED_MODULE_4__["default"])(Operation, [{
    key: "makeACopy",
    value: function makeACopy() {
      return Object(_util__WEBPACK_IMPORTED_MODULE_6__["cloneObject"])(this);
    }
  }, {
    key: "getCmd",
    value: function getCmd() {
      if (this.isUpdatedAfterTransform) {
        if (this.skip) {
          this.cmd = '';
        } else {
          var range = this.posInfos2Range();

          if (range) {
            this.cmd = this.cmd.replace(this.originStrRange, range);
            this.originStrRange = range;
          } else {
            this.cmd = '';
          }
        }

        this.isUpdatedAfterTransform = false;
      }

      return this.cmd;
    } // 将pos的数组转换为一个操作Range，类似A1:A2

  }, {
    key: "posInfos2Range",
    value: function posInfos2Range() {
      var posLen = this.posInfos.length;
      var range = [];
      this.posInfos.forEach(function (pos, idx) {
        // set A1 ,然而A1被删除了，所以就可以忽略了
        if (pos.hasDeleted && posLen === 1) {
          return false;
        }

        if (pos.hasDeleted && idx === 0) {
          // merge A2:C4， ROW 2被删除了，则继续变为merge A2:C3
          range.push(Operation.indexInfoToCol(pos.col) + Operation.indexInfoToRow(pos.row));
        } else if (pos.hasDeleted && idx === 1) {
          // merge A2:C4， ROW 4被删除了，则继续变为merge A2:C3
          pos.row.hasDeleted && (pos.row.index += -1);
          pos.col.hasDeleted && (pos.col.index += -1);
          range.push(Operation.indexInfoToCol(pos.col) + Operation.indexInfoToRow(pos.row));
        } else {
          range.push(Operation.indexInfoToCol(pos.col) + Operation.indexInfoToRow(pos.row));
        }
      });
      return range.join(':');
    } // 类似服务端处理冲突，按照时间顺序转换

  }, {
    key: "transformAfter",
    value: function transformAfter(serverOperation) {
      var self = this;
      var offset;
      var attribute;
      logger.info("start-------->".concat(this.cmd, " transformAfter ").concat(serverOperation.cmd));
      logger.info('oldOperation: ', JSON.stringify(this.posInfos));
      logger.info('input: ', JSON.stringify(serverOperation.posInfos)); // set只支持单元格，不能支持set range;

      if (self.type === 'set' && serverOperation.type === 'merge') {
        // set 新行，命令不变
        if (!posInfoIsDependentOnNew(self.posInfos[0])) {
          if (_CmdStrParser__WEBPACK_IMPORTED_MODULE_8__["default"].crToCoord(self.posInfos[0].col.oldIndex, self.posInfos[0].row.oldIndex) === _CmdStrParser__WEBPACK_IMPORTED_MODULE_8__["default"].crToCoord(serverOperation.posInfos[0].col.oldIndex, serverOperation.posInfos[0].row.oldIndex) && !posInfoIsDependentOnNew(serverOperation.posInfos[0])) {// 说明是 set A1 mergeA1这种情况，应该set命令不变，可以set过去
          } else if (regionCollision(self, serverOperation) === 1) {
            // 说明有交集
            self.skip = true;
          }
        }

        self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = self.skip === true);
        return;
      } // 处理排序和排序的冲突，处理原则：以大range为准，以client为准，如果有部分交集，就取并集


      if (self.type === 'sort' && serverOperation.type === 'sort') {
        if (isContain(serverOperation, self)) {
          self.skip = true;
        } else if (isContain(self, serverOperation)) {
          logger.info(serverOperation);
        } else if (regionCollision(self, serverOperation) === 1) {
          mergeRegion(self, serverOperation);
          self.isUpdatedAfterTransform = true;
        }

        self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = self.skip === true);
        return;
      }

      self.posInfos.forEach(function (pos) {
        serverOperation.posInfos.forEach(function (prePos) {
          switch (serverOperation.type) {
            case 'insertrow':
            case 'insertcol':
              // row|col
              attribute = serverOperation.type.slice(6);

              if (!prePos[attribute] || !pos[attribute]) {
                break;
              }

              if (prePos[attribute].oldIndex <= pos[attribute].oldIndex) {
                // 只要前面是新增行或列，后续的位置坐标+1
                offset = 1;
                pos[attribute].index += offset;
              }

              break;

            case 'deleterow':
            case 'deletecol':
              // row|col
              attribute = serverOperation.type.slice(6);

              if (!prePos[attribute] || !pos[attribute]) {
                break;
              }

              if (prePos[attribute].oldIndex === pos[attribute].oldIndex && !prePos[attribute].isDependOnNew) {
                offset = 0;

                if (self.type === "insert".concat(attribute) || pos[attribute].isDependOnNew) {// 命令保持不变
                } else if (self.type === "delete".concat(attribute)) {
                  // 冲突删除同一行，命令跳过
                  self.skip = true;
                } else {
                  // 任何其他指令都认为行列被删除了
                  pos.hasDeleted = true;
                  pos[attribute].hasDeleted = true;
                }
              } else if (prePos[attribute].oldIndex <= pos[attribute].oldIndex) {
                offset = -1;
                pos[attribute].index += offset;
              }

              break;

            default:
              break;
          } // 说明transform后有变化了


          self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = offset !== undefined);
          offset = undefined;
        });
      });
      logger.info('output: ', JSON.stringify(self.posInfos), " skip:".concat(this.skip));
      logger.info('----------->end:cmd: ', self.getCmd());
    } // 类似客户端处理冲突，需要对服务器的相对于client转化后，合并到excel中
    // 这里相对于transformafter，主要不同点在于插入相同行列、删除相同行列、设置同一单元格

  }, {
    key: "transformReverse",
    value: function transformReverse(clientOperation) {
      var self = this;
      var offset;
      var attribute;
      logger.info("start-------->".concat(this.cmd, " transformReverse ").concat(clientOperation.cmd));
      logger.info('oldOperation: ', JSON.stringify(this.posInfos));
      logger.info('input: ', JSON.stringify(clientOperation.posInfos));

      switch (clientOperation.type) {
        case 'merge':
        case 'unmerge':
          if (self.type === 'merge' || self.type === 'unmerge') {
            if (regionCollision(self, clientOperation) === 1) {
              self.skip = true;
            }
          } else if (self.type === 'set' && clientOperation.type === 'merge') {
            // set 新行，命令不变
            if (!posInfoIsDependentOnNew(self.posInfos[0])) {
              if (_CmdStrParser__WEBPACK_IMPORTED_MODULE_8__["default"].crToCoord(self.posInfos[0].col.oldIndex, self.posInfos[0].row.oldIndex) === _CmdStrParser__WEBPACK_IMPORTED_MODULE_8__["default"].crToCoord(clientOperation.posInfos[0].col.oldIndex, clientOperation.posInfos[0].row.oldIndex) && !posInfoIsDependentOnNew(clientOperation.posInfos[0])) {// 说明是 set A1 mergeA1这种情况，应该set命令不变，可以set过去
              } else if (regionCollision(self, clientOperation) === 1) {
                // 说明有交集
                self.skip = true;
              }
            }
          }

          self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = self.skip === true);
          return;

        case 'sort':
          // 处理排序和排序的冲突，处理原则：以大range为准，以client为准，如果有部分交集，就取并集
          if (self.type === 'sort') {
            if (isContain(clientOperation, self)) {
              self.skip = true;
            } else if (isContain(self, clientOperation)) {
              logger.info(clientOperation);
            } else if (regionCollision(self, clientOperation) === 1) {
              mergeRegion(self, clientOperation); // 这里展示以客户端为准

              self.cmd = clientOperation.cmd;
              self.originStrRange = clientOperation.originStrRange;
              self.isUpdatedAfterTransform = true;
            }
          }

          self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = self.skip === true);
          return;

        default:
          break;
      }

      self.posInfos.forEach(function (pos) {
        clientOperation.posInfos.forEach(function (prePos) {
          switch (clientOperation.type) {
            case 'insertrow':
            case 'insertcol':
              // row|col
              attribute = clientOperation.type.slice(6);

              if (!prePos[attribute] || !pos[attribute]) {
                break;
              }

              if (prePos[attribute].oldIndex === pos[attribute].oldIndex && (self.type === "insert".concat(attribute) || pos[attribute].isDependOnNew)) {// 收到服务端的insert row 不需要转换，只需要发送给服务端的时候，insert row+1就行
              } else if (prePos[attribute].oldIndex <= pos[attribute].oldIndex) {
                // 只要前面是新增行或列，后续的位置坐标+1
                offset = 1;
                pos[attribute].index += offset;
              }

              break;

            case 'deleterow':
            case 'deletecol':
              // row|col
              attribute = clientOperation.type.slice(6);

              if (!prePos[attribute] || !pos[attribute]) {
                break;
              }

              if (prePos[attribute].oldIndex === pos[attribute].oldIndex) {
                offset = 0;

                if (self.type === "insert".concat(attribute) || pos[attribute].isDependOnNew) {// 命令保持不变
                } else if (prePos[attribute].isDependOnNew) {
                  offset = -1;
                  pos[attribute].index += offset;
                } else if (self.type === "delete".concat(attribute)) {
                  // 冲突删除同一行，命令跳过
                  self.skip = true;
                } else {
                  // 任何其他指令都认为行列被删除了
                  pos.hasDeleted = true;
                  pos[attribute].hasDeleted = true;
                }
              } else if (prePos[attribute].oldIndex < pos[attribute].oldIndex) {
                offset = -1;
                pos[attribute].index += offset;
              }

              break;

            default:
              if (!posInfoIsDependentOnNew(prePos) && !posInfoIsDependentOnNew(pos)) {
                // 如果依赖新的行或者列是不可能和其他行列冲突的。
                if (isSameOldPos(prePos, pos)) {
                  if (clientOperation.type === 'set') {
                    if (clientOperation.secondType === self.secondType) {
                      // skip
                      self.skip = true;
                      offset = 0;
                    }
                  }
                }
              }

              break;
          } // 说明transform后有变化了


          self.isUpdatedAfterTransform || (self.isUpdatedAfterTransform = offset !== undefined);
          offset = undefined;
        });
      });
      logger.info('output: ', JSON.stringify(self.posInfos));
      logger.info('----------->end:cmd: ', self.getCmd());
    }
    /**
     * 获取range区域内，所有的coord集合
     * ['A1', 'A2']
     */

  }, {
    key: "getCoords",
    value: function getCoords() {
      var coords = [];
      var crEnumCollection = this.calculateCrEnumCollection();
      crEnumCollection.row.forEach(function (row) {
        crEnumCollection.col.forEach(function (col) {
          coords.push(_CmdStrParser__WEBPACK_IMPORTED_MODULE_8__["default"].crToCoord(col, row));
        });
      });
      logger.info('getCoords:', coords);
      return coords;
    } // 计算merge或unmerge、sort区域的行列枚举集合

  }, {
    key: "calculateCrEnumCollection",
    value: function calculateCrEnumCollection() {
      var _this = this;

      // 需要获取合并单元格的原始宽列的散列，进行逐一碰撞;
      if (!this.enum) {
        this.enum = {};

        if (this.posInfos.length === 1) {
          this.posInfos.push(this.posInfos[0]);
        }

        ['row', 'col'].forEach(function (attribute) {
          var _this$posInfos$reduce = _this.posInfos.reduce(function (init, pos) {
            return {
              min: Math.min(init[attribute].oldIndex, pos[attribute].oldIndex),
              max: Math.max(init[attribute].oldIndex, pos[attribute].oldIndex)
            };
          }),
              min = _this$posInfos$reduce.min,
              max = _this$posInfos$reduce.max;

          for (var attribIndex = min; attribIndex <= max; attribIndex++) {
            if (_this.enum[attribute]) {
              _this.enum[attribute].push(attribIndex);
            } else {
              _this.enum[attribute] = [attribIndex];
            }
          } // 默认升序


          _this.enum[attribute].sort();
        });
      }

      logger.info('this.cmd', this.cmd, 'this.enum:', this.enum);
      return this.enum;
    }
  }]);

  return Operation;
}();



/***/ }),

/***/ "zpmH":
/*!*****************************!*\
  !*** ./src/api/snapshot.js ***!
  \*****************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _lib_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/http */ "HgRx");

/* harmony default export */ __webpack_exports__["default"] = ({
  fetch: function fetch(data) {
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'post',
      url: '/docs/snapshot/e',
      data: "data=".concat(encodeURIComponent(JSON.stringify(data)))
    });
  },
  get: function get(data) {
    return Object(_lib_http__WEBPACK_IMPORTED_MODULE_0__["default"])({
      method: 'get',
      url: '/docs/snapshot/excel',
      params: {
        fileType: data.fileType,
        docskey: data.docskey,
        docsid: data.docsid,
        vid: data.vid,
        room: data.room,
        sessionID: data.sessionID,
        type: data.type,
        'data[docId]': data.data,
        nocache: data.nocache
      }
    });
  }
});

/***/ })

}]);