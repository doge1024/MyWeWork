(function () {
    QMailBridge = function () {
        this._sendMessageQueue = [];
        this._callback_count = 1000;
        this._callback_map = {};
        this.available_func = {};
        this._iframe = document.createElement("iframe");
        this._iframe.setAttribute("id", "iframe");
        this._iframe.setAttribute("style", "position:absolute;top:0;left:0;width:1px;height:1px;visibility:hidden;");
        this._QUEUE_HAS_MESSAGE_URL = 'qqmailapijs://dispatch_message/';
        document.body.appendChild(this._iframe);

        this._resultIframe = document.createElement("iframe");
        this._resultIframe.setAttribute("id", "_resultIframe");
        this._resultIframe.setAttribute("style", "position:absolute;top:0;left:0;width:1px;height:1px;visibility:hidden;");
        this._resultIframe._SET_RESULT_URL = 'qqmailapijs://private/setresult/';
        document.body.appendChild(this._resultIframe);
    }

    /**
     * 获取网络状况
     * @return 0 无网络，1 非wifi，2 wifi。
     */
    QMailBridge.prototype.getNetState = function (successCallback, failCallback) {
        var self = this;
        this._call("getNetState", "{}", function (successOrNot, result) {
            var params = { "netState": result };
            self.localLog(params);
            if (successOrNot) {
                var netState = result;
                successCallback(netState);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 获取网络状况
     * @return [
     *  		{
     *				"nick" : "abc"
     *				"emails": ["a@163.com","b@qq.com"]
     *				"mark" : "cde"
     *				"birthday" : "2015-1-2"
     *			},
     *			{
     *				"nick" : "abc"
     *				"emails": ["a@163.com","b@qq.com"]
     *				"mark" : "cde"
     *				"birthday" : "2015-1-2"
     *			}
     *         ]
     *		
     *	  
     */
    QMailBridge.prototype.getAddressBookContacts = function (successCallback, failCallback) {
        var self = this;
        this._call("getAddressBookContacts", "{}", function (successOrNot, result) {
            var params = { "getAddressBookContacts": result };
            self.localLog(params);
            if (successOrNot) {
                var contacts = result;
                successCallback(contacts);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 获取deviceid
     * @return successOrNot 成功返回YES, 失败返回NO.
     * @return deviceid 成功返回deviceid值 失败返回error字符串
     */
    QMailBridge.prototype.getDeviceId = function (successCallback, failCallback) {
        var self = this;
        this._call("getDeviceId", "{}", function (successOrNot, result) {
            var params = { "deviceid": result };
            self.localLog(params);
            if (successOrNot) {
                var deviceid = result;
                successCallback(deviceid);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

   /**
    * 收藏贺卡
    * @return successOrNot 成功返回YES, 失败返回NO.
    * params {"cardID":"XXXXXXXX"}
    */
   QMailBridge.prototype.keepGreetingCard = function (params, successCallback, failCallback) {
        var self = this;
        this._call("keepGreetingCard", params, function (successOrNot, result) {
            self.localLog(params);
            if (successOrNot) {
                successCallback(result);
            } else {
                failCallback(result);
            }
        });
   }

    /**
     *获取deviceid
     *对于android采用新的deviceID算法与读书统一, ios保持不变
     * @return successOrNot 成功返回YES, 失败返回NO.
     * @return deviceid 成功返回deviceid值 失败返回error字符串
     */
    QMailBridge.prototype.getWeReadDeviceId = function (successCallback, failCallback) {
        var self = this;
        this._call("getWeReadDeviceId", "{}", function (successOrNot, result) {
            var params = { "deviceid": result };
            self.localLog(params);
            if (successOrNot) {
                var deviceid = result;
                successCallback(deviceid);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 获取docSid
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return docSid  成功返回获取的docSid值 失败返回error字符串
     */
    QMailBridge.prototype.docLogin = function (successCallback, failCallback) {
        var self = this;
        this._call("docLogin", "{}", function (successOrNot, result) {
            var params = { "docLogin": result };
            self.localLog(params);
            if (successOrNot) {
                successCallback(result);
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 在线文档修改之后通知APP处理列表逻辑
     * params {key:"v2_87b16fbb32fffae4d06bc5928868b"}
     */
    QMailBridge.prototype.docModify = function (params, successCallback, failCallback) {
        var self = this;
        this._call("docModify", params, function (successOrNot, result) {
            var params = { "docModify": result };
            self.localLog(params);
            if (successOrNot) {
                successCallback(result);
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 通知表格是否滚动到了最左边
     * params {onLeft: true/false}
     */
    QMailBridge.prototype.isXlsOnLeft = function (params, successCallback, failCallback) {
        var self = this;
        this._call("isXlsOnLeft", params, function (successOrNot, result) {
            var params = { "onLeft": result };
            self.localLog(params);
            if (successOrNot) {
                successCallback(result);
            } else {
                failCallback(result);
            }
        });
    }

    /**
     *获取sid
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return sid  成功返回获取的sid值 失败返回error字符串
     */
    QMailBridge.prototype.getSid = function (successCallback, failCallback) {
        var self = this;
        this._call("getSid", "{}", function (successOrNot, result) {
            var params = { "sid": result };
            self.localLog(params);
            if (successOrNot) {
                var sid = result;
                successCallback(sid);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 获取uin
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return uin  成功返回获取的uin值 失败返回error字符串
     */
    QMailBridge.prototype.getUin = function (successCallback, failCallback) {
        var self = this;
        this._call("getUin", "{}", function (successOrNot, result) {
            var params = { "uin": result };
            self.localLog(params);
            if (successOrNot) {
                var uin = result;
                successCallback(uin);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 获取系统版本号getSystemVersion
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return   成功返回获取的systemVersion值以及相应的系统  如{"systemVersion":8.01,"system":"iphone 5s"} 失败返回error字符串
     */
    QMailBridge.prototype.getSystemVersion = function (successCallback, failCallback) {
        var self = this;
        this._call("getSystemVersion", "{}", function (successOrNot, result) {
            self.localLog(result);
            if (successOrNot) {
                successCallback(result);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * token过期的时候，重新换token，并重新刷新页面
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return successOrNot 返回YES，失败返回NO,返回error字符串。
     */
    QMailBridge.prototype.refreshToken = function (successCallback, failCallback) {
        var self = this;
        this._call("refreshToken", "{}", function (successOrNot, result) {
            var params = { "refreshToken": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * @params uin
     * token过期的时候，重新换token，并重新刷新页面
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return successOrNot 返回YES，失败返回NO,返回error字符串。
     */
    QMailBridge.prototype.refreshTokenWithUin = function (params, successCallback, failCallback) {
        var self = this;
        this._call("refreshTokenWithUin", { 'uin': params }, function (successOrNot, result) {
            var params = { "refreshTokenWithUin": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * @params {'reload':true,'uin':888} uin可选
     * skey过期的时候，重新换skey，并重新刷新页面
     * @return successOrNot 返回YES，放回新的token，失败返回NO，返回error字符串。
     */
    QMailBridge.prototype.refreshSkey = function (params, successCallback, failCallback) {
        var self = this;
        this._call("refreshSkey", params, function (successOrNot, result) {
            var params = { "refreshSkey": result };
            self.localLog(params);
            if (successOrNot) {
                var token = result
                successCallback(token);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 判断是否安装app
     * @params {'packageName': '包名，例如 com.tencent.weread', 'packageUrl': '协议名，例如 weread://'}
     * @return successOrNot 返回YES，失败返回NO,返回error字符串。
     */
    QMailBridge.prototype.appInstallJudge = function (params, successCallback, failCallback) {
        var self = this;
        this._call("appInstallJudge", params, function (successOrNot, result) {
            var params = { "appInstallJudge": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 获取app版本号getAppVersion
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return appVersion  成功返回获取的appVersion值,失败返回error字符串
     */
    QMailBridge.prototype.getAppVersion = function (successCallback, failCallback) {
        var self = this;
        this._call("getAppVersion", "{}", function (successOrNot, result) {
            var params = { "appVersion": result };
            self.localLog(params);
            if (successOrNot) {
                var appVersion = result;
                successCallback(appVersion);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 跳转到qq登录界面
     * @return successOrNot 调整成功返回YES，失败返回NO,并返回error字符串。
     *
     */
    /* QMailBridge.prototype.goToQQMailLogin = function (successCallback, failCallback) {
        var self = this;
        this._call("goToQQMailLogin", "{}", function (successOrNot, result) {
            var params = { "goToQQMailLogin": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    } */

    /**
     * 跳转到某个url 这里即可以是app的某个模块 也可以是外部url
     * @url qqmail://ftn?a=b&c=d 或者 http://   @return successOrNot 成功返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.goToUrl = function (url, successCallback, failCallback) {
        var self = this;
        var params = { "url": url };
        this._call("goToUrl", params, function (successOrNot, result) {
            var params = { "goToUrl": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 执行更多操作
     * @params [
     *         {'shareToWechatTimeLine': {'title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url,'itemName':itemName}},
     *         {'shareToWechatFriend': {'title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url,'itemName':itemName}},
     *         {'copyLink':{'url':linkedUrl,'itemName':itemName}}    //copyLink 为空 默认当前url
     *         {‘openWithSafari’:{'url':url,'itemName':itemName}}   //openWithSafari 为空 默认当前url
     *         {‘sendmail’:{'type':1 0r 2 or 3,'content':content,'itemName':itemName}} // 1:发送当前url,这种情况contetnt不填  2:当前正文,这种情况contetnt不填 3:发送自定义content
     *         ]
     * itemName 为操作对应的文案，如shareToWechatTimeLine 的itemName为 “分享到朋友圈”
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.moreOperation = function (params, successCallback, failCallback) {
        var self = this;
        this._call("moreOperation", params, function (successOrNot, result) {
            var params = { "moreOperation": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 分享到朋友圈
     * @params {'mode':'image or url','title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url}
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.shareToWechatTimeLine = function (params, successCallback, failCallback) {//朋友圈
        var self = this;
        this._call("shareToWechatTimeLine", params, function (successOrNot, result) {
            var params = { "shareToWechatTimeLine": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 分享到朋友
     * @params {'mode':'image or url','title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url}
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.shareToWechatFriend = function (params, successCallback, failCallback) {//朋友
        var self = this;
        this._call("shareToWechatFriend", params, function (successOrNot, result) {
            var params = { "shareToWechatFriend": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 分享到qq朋友
     * @params {‘mode’:’image or url’,’title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url}
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.shareToQQFriend = function (params, successCallback, failCallback) {//qq
        var self = this;
        this._call("shareToQQFriend", params, function (successOrNot, result) {
            var params = { "shareToQQFriend": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 分享到qqzone
     * @params {‘mode’:’image or url’,’title':title,'imageUrl':imageUrl,'abstract':abstract,'url':url}
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.shareToQQZone = function (params, successCallback, failCallback) {//qqzone
        var self = this;
        this._call("shareToQQZone", params, function (successOrNot, result) {
            var params = { "shareToQQZone": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 将url或image分享给邮箱、微信、朋友圈、qq 、qqzone
     * @params {‘qqmail’: {},’Wechat’:{} , ‘WechatTimeLine’:{} , ‘qq’:{}, ‘qqzone’:{} }
     * 每一个方式的结构 {"mode”:’image or url’,’title’:title,’imageUrl’:imageUrl,"abstract’:abstract,’url’:url}
     * 目前mode支持两种image和url
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.shareToFriend = function (params, successCallback, failCallback) {//朋友
        var self = this;
        this._call("shareToFriend", params, function (successOrNot, result) {
            var params = { "shareToFriend": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * @params {'title' : title }
     * @return successOrNot 返回YES, 失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.setTitle = function (params, successCallback, failCallback) {
        var self = this;
        this._call("setTitle", params, function (successOrNot, result) {
            var params = { "setTitle": successOrNot };
            if (successOrNot) {
                successCallback();
            } else {
                failCallback();
            }
        });
    }

    /**
     * 设置该页面是否可以分享
     * @param {'type' : '1'} '1'表示禁止 ‘0’表示不禁止
     */
    QMailBridge.prototype.showOptionMenu = function (option, callback) {//设置是否支持分享
        var self = this;
        this._call("showOptionMenu", option, function (successOrNot, result) {
            callback();
        });
    }
 
    /**
     * 同步在线文档富文本状态
     * @param qull.getFormat()
     */
    QMailBridge.prototype.syncDocFormat = function (params, callback) {//设置是否支持分享
        var self = this;
        this._call("syncDocFormat", params, function (successOrNot, result) {
            callback();
        });
    }

    // excel
    QMailBridge.prototype.syncExcelFormat = function (params, callback) {//设置是否支持分享
         var self = this;
         this._call("syncExcelFormat", params, function (successOrNot, result) {
             callback();
         });
    }

    /**
     * 同步在线文档表格状态
     * @param table.getAllFormat()
     */
    QMailBridge.prototype.syncTableFormat = function (params, callback) {//设置是否支持分享
        var self = this;
        this._call("syncTableFormat", params, function (successOrNot, result) {
            callback();
        });
    }

    /**
     * 获取nick
     * @return successOrNot 成功返回YES，失败返回NO。
     * @return nick  成功返回获取的nick值 失败返回error字符串
     */
    QMailBridge.prototype.getNick = function (successCallback, failCallback) {
        var self = this;
        this._call("getNick", "{}", function (successOrNot, result) {
            var params = { "nick": result };
            self.localLog(params);
            if (successOrNot) {
                var nick = result;
                successCallback(nick);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     *获取email
     * @return successOrNot 成功返回YES，失败返回NO。
     *@return email  成功返回获取的email值 失败返回error字符串
     */
    QMailBridge.prototype.getEmail = function (successCallback, failCallback) {
        var self = this;
        this._call("getEmail", "{}", function (successOrNot, result) {
            var params = { "email": result };
            self.localLog(params);
            if (successOrNot) {
                var email = result;
                successCallback(email);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }


    /**
     * 复制链接
     * @params linkedUrl
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.copyLink = function (params, successCallback, failCallback) {
        var self = this;
        this._call("copyLink", { 'url': params }, function (successOrNot, result) {
            var params = { "copyLink": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * Safar打开
     * @params linkedUrl
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.openWithSafari = function (params, successCallback, failCallback) {
        var self = this;
        this._call("openWithSafari", { 'url': params }, function (successOrNot, result) {
            var params = { "openWithSafari": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 发信
     * @params {'type':1 0r 2 or 3,'content':content}// 1:发送当前url,这种情况contetnt不填  2:当前正文,这种情况contetnt不填 3:发送自定义content
     * @return successOrNot 返回YES，失败返回NO,并返回error字符串。
     */
    QMailBridge.prototype.sendmail = function (params, successCallback, failCallback) {
        var self = this;
        this._call("sendmail", params, function (successOrNot, result) {
            var params = { "sendmail": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 去下载页面 关闭当前页面
     * @params {'appid':'95xxxxxx', 'packageName:'com.xxxx.xxxx', 'url':'www.xxx.qmail.com'}//ios appid; android packagename包名 url下载地址
     * @return  successOrNot 返回YES，失败返回NO,并返回error字符串。当前没有任何返回
     */
    QMailBridge.prototype.gotoDownloadAndCloseWebView = function (params, successCallback, failCallback) {
        var self = this;
        this._call("gotoDownloadAndCloseWebView", params, function (successOrNot, result) {
            var params = { "gotoDownloadAndCloseWebView": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    /**
     * 获取当前是否正在下载app
     * @params {'appid':'95xxxxxx', 'packageName:'com.xxxx.xxxx', 'url':'www.xxx.qmail.com'}//ios appid; android packagename包名 url下载地址
     * @return   下载完成了没 1完成 0未下载 2下载中 如{"isDownloading":1} 失败返回error字符串
     */
    QMailBridge.prototype.isDownloadingApp = function (params, successCallback, failCallback) {
        var self = this;
        this._call("isDownloadingApp", params, function (successOrNot, result) {
            self.localLog(result);
            if (successOrNot) {
                successCallback(result);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 在线文档页面准备完成，可以开始让app执行cmd的通知
     */
    QMailBridge.prototype.msgLogicReady = function(successCallback, failCallback) {
        var self = this;
        var params = {};
        this._call("msgLogicReady", params, function(successOrNot, result) {
            self.localLog(result);
            if (successOrNot) {
                successCallback(result);
            } else {
                var error = result;
                failCallback(error);
            }
        });
    }

    /**
     * 离开webview时，调用的函数
     */
    QMailBridge.prototype.onUnload = function(successCallback, failCallback) {
        var self = this;
        var params = {};
        this._call("onUnload", params, function(successOrNot, result) {
            var params = {"deviceid":result};
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback();
            }
        });
    }

    /**
     * 关闭当前controller android关闭当前activity
     * @return  successOrNot 返回YES，失败返回NO,并返回error字符串。当前没有任何返回
     */
    QMailBridge.prototype.closeWebView = function (successCallback, failCallback) {
        var self = this;
        this._call("closeWebView", "{}", function (successOrNot, result) {
            var params = { "closeWebView": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);

            }
        });
    }

    /**
     * 是否显示toolbar
     */
    QMailBridge.prototype.showMailAppDocToolbar = function (show) {
        this._call("showMailAppDocToolbar", {"show" : show});
    }

    /**
     * 关闭当前controller android关闭当前悬浮webview
     * @return  successOrNot 返回YES，失败返回NO,并返回error字符串。当前没有任何返回
     */
    QMailBridge.prototype.closeActivityWebView = function (successCallback, failCallback) {
        var self = this;
        this._call("closeActivityWebView", "{}", function (successOrNot, result) {
            var params = { "closeActivityWebView": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);

            }
        });
    }

    QMailBridge.prototype.localLog = function (params, successCallback, failCallback) {
        this._call("localLog", params);
    }

    QMailBridge.prototype.openInWechatWebView = function (params, successCallback, failCallback) {
        var self = this;
        this._call("openInWechatWebView", { 'url': params }, function (successOrNot, result) {
            var params = { "openInWechatWebView": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    QMailBridge.prototype.goToQQMailLogin = function (successCallback, failCallback) {
        var self = this;
        var params = { "url": "qqmail://account?action=login" };
        this._call("goToQQMailLogin", params, function (successOrNot, result) {
            var params = { "goToQQMailLogin": successOrNot };
            self.localLog(params);
            if (successOrNot) {
                successCallback();
            } else {
                failCallback(result);
            }
        });
    }

    QMailBridge.prototype.clickCommentTips = function (commentId, comments, users) {
        var params = { "commendId": commentId, "comments": comments, "users": users};
        this._call("clickCommentTips", params);
    }

    QMailBridge.prototype.commentChanged = function (commentId, comments, users) {
        var params = { "commendId": commentId, "comments": comments, "users": users};
        this._call("commentChanged", params);
    }

    QMailBridge.prototype.showCommentButton = function (showOrNot) {
        this._call("showCommentButton", {"show" : showOrNot});
    }

    QMailBridge.prototype.insertImageFinish = function () {
        this._call("insertImageFinish", {});
    }

    QMailBridge.prototype.getLocalImage = function (imageId, successCallback, failCallback) {
        this._call("getLocalImage", { imageId }, function (successOrNot, result) {
            if (successOrNot) {
                successCallback(result);
            } else {
                failCallback(result);
            }
        })
    }

    QMailBridge.prototype.deleteLocalImage = function (imageId) {
        this._call("deleteLocalImage", { imageId })
    }

    QMailBridge.prototype.setSubTitle = function (subTitle) {
        this._call("setSubTitle", { subTitle });
    }

    QMailBridge.prototype.updateAuthority = function (authority) {
        this._call("updateAuthority", { authority })
    }

    QMailBridge.prototype.clickBottomStatusBar = function (fileAuthority) {
        this._call("clickBottomStatusBar", { fileAuthority });
    }

    QMailBridge.prototype.enableSendButton = function (enable) {
        this._call("enableSendButton", { enable })
    }

    QMailBridge.prototype.fetchQueue = function () {
        var messageQueueString = JSON.stringify(this._sendMessageQueue);
        this._sendMessageQueue = [];
        this._setResultValue('fetchqueue', messageQueueString);
        return messageQueueString;
    }

    QMailBridge.prototype._setResultValue = function (scene, result) {
        // Android 通过另一个iframe上传数据
        if (result === undefined) {
            result = '';
        }
        this._resultIframe.src = this._resultIframe._SET_RESULT_URL + scene + '&' + this._base64Encode(this._utf8Encode(result));
    }

    // public method for url encoding
    QMailBridge.prototype._utf8Encode = function (str) {
        str = str.replace(/\r\n/g, "\n");
        var utftext = "";

        for (var n = 0; n < str.length; n++) {

            var c = str.charCodeAt(n);

            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }

        return utftext;
    }

    // public method for url decoding
    QMailBridge.prototype._utf8Decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;

        while (i < utftext.length) {

            c = utftext.charCodeAt(i);

            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if ((c > 191) && (c < 224)) {
                c1 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c1 & 63));
                i += 2;
            } else {
                c1 = utftext.charCodeAt(i + 1);
                c2 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c1 & 63) << 6) | (c2 & 63));
                i += 3;
            }

        }

        return string;
    }

    QMailBridge.prototype._base64Encode = function (str) {
        //base64编码
        var base64encodechars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        if (str === undefined) {
            return str;
        }
        var out, i, len;
        var c1, c2, c3;
        len = str.length;
        i = 0;
        out = "";
        while (i < len) {
            c1 = str.charCodeAt(i++) & 0xff;
            if (i == len) {
                out += base64encodechars.charAt(c1 >> 2);
                out += base64encodechars.charAt((c1 & 0x3) << 4);
                out += "==";
                break;
            }
            c2 = str.charCodeAt(i++);
            if (i == len) {
                out += base64encodechars.charAt(c1 >> 2);
                out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
                out += base64encodechars.charAt((c2 & 0xf) << 2);
                out += "=";
                break;
            }
            c3 = str.charCodeAt(i++);
            out += base64encodechars.charAt(c1 >> 2);
            out += base64encodechars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
            out += base64encodechars.charAt(((c2 & 0xf) << 2) | ((c3 & 0xc0) >> 6));
            out += base64encodechars.charAt(c3 & 0x3f);
        }
        return out;
    }

    QMailBridge.prototype._sendMessage = function (message) {
        this._sendMessageQueue.push(message);
        this._iframe.src = this._QUEUE_HAS_MESSAGE_URL;
    }

    QMailBridge.prototype.handleMessage = function (message) {
        var callbackId = message["callbackId"];
        if (!callbackId || typeof callbackId !== 'string') {
            return;
        }
        var successOrNot = message["successOrNot"];
        var params = message["params"];
        if (typeof this._callback_map[callbackId] === "function") {
            this._callback_map[callbackId](successOrNot, params);
            delete this._callback_map[callbackId];
        }
    }

    QMailBridge.prototype._call = function (func, params, callback) {
        if (!func || typeof func !== "string") {
            return;
        }

        if (typeof params !== "object") {
            params = {};
        }

        var msgObj = { "func": func, "params": params };

        var callbackID = (this._callback_count++).toString();

        if (typeof callback === "function") {
            this._callback_map[callbackID] = callback;
            msgObj["callbackId"] = callbackID;
        }
        this._sendMessage(JSON.stringify(msgObj));
    }

    QMailBridge.prototype.onReady = function (func) {
        !_isReady && _bindReadyFuns.unshift([this, func]);
    }

    QMailBridge.prototype.bindReady = function (func) {
        !_isReady ? _bindReadyFuns.unshift([this, func]) : func.call(this);
    }

    QMailBridge.prototype.isReady = function () {
        return _isReady;
    }

    QMailBridge.prototype.isAvailable = function (apiName) {
        return !!(_QMailBridgeInfo && _QMailBridgeInfo["apis"][apiName]);
    }

    var _isReady, _QMailBridgeInfo, _bindReadyFuns = [],
        _onReady = function () {
            _QMailBridgeInfo = window["__QMB_INFO__"];
            if (_isReady) return;
            _isReady = true;
            var _funcParams;
            while (_funcParams = _bindReadyFuns.pop()) {
                _funcParams[1].call(_funcParams[0]);
            };
        };
    window["qmailBridge"] = new QMailBridge();
    if (window["__QMB_INFO__"]) {
        _onReady();
    } else {
        window["__QMB_INFO_CALL__"] = function () {
            _onReady();
        };
    }

    if (/\(i[^;]+;( U;)? CPU.+Mac OS X/.test(navigator.userAgent) && !qmailBridge.isReady()) {
        // 对 4.0.3- 版本进行api接口兼容
        qmailBridge.getAppVersion(function (version) {
            var v = version.split('.');
            var v2 = [4, 0, 3];
            for (var i = 0; i < v2.length; i++) {
                if (Number(v[i]) > v2[i]) return;
            }

            // 使用模拟数据
            window["__QMB_INFO__"] = {
                apis: { "getSid": 1, "getAppVersion": 1, "getSystemVersion": 1, "appInstallJudge": 1, "goToUrl": 1, "moreOperation": 1, "refreshToken": 1, "shareToWechatTimeLine": 1, "shareToWechatFriend": 1, "copyLink": 1, "openWithSafari": 1, "sendmail": 1, "localLog": 1 },
                ver: version,
                os: "ios"
            };
            _onReady();
        });
    }
})();

// window.qmailBridge = new QMailBridge();
//window.qmailBridge.refreshTokenWithUin("");
/**
 * load页面之前需要先执行以下的js
 * eval('window["__QMB_INFO__"]={apis:{"a":1,"b":1},ver:"4.0.5",os:"android"};window["__QMB_INFO_CALL__"]&&window["__QMB_INFO_CALL__"]();');
 */

// window.qmailBridge.moreOperation(new Array({'shareToWechatTimeLine': {'title':'title','imageUrl':'imageUrl','abstract':'abstract','url':'url'}}));
// window.qmailBridge.dismissController();
// window.qmailBridge.shareToWechatFriend({'title':'中文','imageUrl':'imageUrl','abstract':'中文测试','url':'url'});

