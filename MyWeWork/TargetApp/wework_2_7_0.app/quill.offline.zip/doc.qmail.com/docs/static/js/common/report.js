window.__LQ_REPORT_URL__ = "/docs/report";
window.__LQ_REPORT_NAME__ = "KV";

var exports, module, temp;

(function() {
var __KVCLICK_KEY__ = ["k","u","ku","pu","pku","spku"];
var report = (function()
{
	typeof console && console;
	var waitReportList = [];

	/*var ie = (function(){
		var v = 3, div = document.createElement('div');
		while (
			div.innerHTML = '<!--[if gt IE '+(++v)+']><i></i><![endif]-->',
			div.getElementsByTagName('i')[0]
		);
		return v > 4 ? v : undefined;
	}());*/

	/**
	 * 通用上报入口
	 * 注意query中少了一次encodeURIComponent 方便查看
	 * 
	 * @param  {String} query
	 * @param  {Mix}    options
	 *
	 * [options]
	 * Function: 上报完成后回调，注：自动切成实时上报
	 * Boolean: 是否需要实时上报 (默认false)
	 * Number: 抽样比例(小数)
	 * Object: {onload, delay, sample}
	 */
	function report(query, options)
	{
		query = 'q='+encodeURIComponent(query);
		var optsType = typeof options;
		var callback, isDoNow = false, sample;

		if ('function' == optsType)
		{
			callback = options;
		}
		else if ('boolean' == optsType)
		{
			isDoNow = optsType === false;
		}
		else if (!isNaN(options))
		{
			sample = options;
		}
		else if (options && 'object' == optsType)
		{
			callback = options.onload;
			isDoNow = options.delay === false;
			sample = options.sample === true ? 0.1 : options.sample;
		}

		// 判断是否需要忽略这个数据
		if (sample && Math.random() > Number(sample)) return;

		waitReportList.push(query);

		// 是否立马发送数据
		if (isDoNow || callback)
		{
			// 延迟，方便一个调用栈中的所有数据，都被合并到一个请求中
			setTimeout(function()
			{
				sendQuery(callback);
			});
		}
		else if (waitReportList.length == 1)
		{
			setTimeout(sendQuery, 3000);
		}
	}

	function sendQuery(callback)
	{
		// 因为有延迟，所以有可能产生空数据包
		if (waitReportList.length)
		{
			sendData(waitReportList.join('&'), callback);
			waitReportList = [];
		}
	}

	var globalXHR;
	function sendData(data, callback)
	{
		var xhr = globalXHR;
		globalXHR = null;

		if (!xhr)
		{
			exports.newXhr(function(xhr)
			{
				_sendData(xhr, data);
				xhr.onreadystatechange = function()
				{
					if (xhr.readyState == 2)
					{
						if (xhr.abort)
						{
							xhr.abort();
							// 非ie可以复用xhr
							// if (!ie) globalXHR = xhr;
							if (window.XMLHttpRequest) globalXHR = xhr;
						}

						callback && callback();
					}
				};
			});
		}
		else
		{
			_sendData(xhr, data);
		}
	}

	function _sendData(xhr, data)
	{
		if (exports.xhr_cross_domain)
		{
			xhr.open('POST', exports.report_url, true);
			xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhr.send(data+'&r='+Math.random());
		}
		else
		{
			var lastChar = exports.report_url.charAt(exports.report_url.length-1);
			var splitChar = lastChar == '?' || lastChar == '&' ? '' : (exports.report_url.indexOf('?') != -1 ? '&' : '?');
			(new Image(1,1)).src = exports.report_url + splitChar + data + '&r=' + Math.random();
		}
	}

	function newXhr(callback)
	{
		callback(window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject("Microsoft.XMLHTTP"));
	}

	/**
	 * 自定义上报类型
	 *
	 * stat 可以在每个项目的 config/mail.report.conf.js 中定义
	 * 
	 * @param  {String}        stat
	 * @param  {String/Object} data
	 */
	function stat(stat, data, options)
	{
		if (typeof data == 'object') data = JSON.stringify(data);
		report('st:'+stat+'='+data, options);
	}

	function log(data, options)
	{
		exports.stat('c_log', data, options);
	}


	// 需要上报到点击流，所以不能延迟
	// 不能使用q包裹(不好判断)
	function ck_error(msg)
	{
		waitReportList.push('ck_error='+encodeURIComponent(msg));
		sendQuery();
	}
	function ck_login(loginTime, resTime)
	{
		waitReportList.push('ck_login='+loginTime+','+ resTime);
		sendQuery();
	}




	function devWarn(msg)
	{
		console.warn && console.warn(msg);
	}


	var exports		= report;
	exports.newXhr	= newXhr;
	exports.stat	= stat;
	exports.log		= log;
	exports.warn_	= devWarn;

	exports.ck_error	= ck_error,
	exports.ck_login	= ck_login;

	try {
		exports.report_url = window.__LQ_REPORT_URL__ || top.__LQ_REPORT_URL__;
		exports.xhr_cross_domain = window.__LQ_REPORT_URL_CROSS_DOMAIN__ || top.__LQ_REPORT_URL_CROSS_DOMAIN__;
	}
	catch(e) {}

	exports.report_url || (exports.report_url = '/report');
	if (typeof exports.xhr_cross_domain != 'boolean')
	{
		var host = exports.report_url.match(/^(?:https?:)?\/\/([^\/]+)\//);
		exports.xhr_cross_domain = !host || (document.domain ? host[1] == document.domain : host[1] == location.host);
	}

	return exports;
})();



if (__KVCLICK_KEY__ && __KVCLICK_KEY__.length)
{
	function _bindKvClickType(kv_name)
	{
		if (kv_name && !report[kv_name])
		{
			report[kv_name] = function(key, options)
			{
				report(kv_name+'='+(''+key).toLowerCase(), options);
			}
		}
	}

	for(var i = __KVCLICK_KEY__.length; i--;)
	{
		_bindKvClickType(__KVCLICK_KEY__[i]);
	}
}



var BIG_VAL = Number('300000') || 300000;

/********* 速度上报相关函数 ***********/
function speed(key, val, options)
{
	if (val > BIG_VAL) report.stat('speed_big_val', val+':speed', options);
	// key必须是小写
	report.stat('speed', 'k='+key+'&v='+val, options);
}

/**
 * 上报页面初始化的时间线
 *
 * 通过html定义的 window.__PAGE_START_TIME__做时间戳上报
 * 
 * @param  {String} key
 * @param  {Date}   useThisTime
 */
function pageLine(key, useThisTime, options)
{
	if (window.__PAGE_START_TIME__)
	{
		speed(key, +(useThisTime || new Date()) - window.__PAGE_START_TIME__, options);
	}
	else
	{
		report.warn_(new Error('no __PAGE_START_TIME__'));
	}
}



/**
 * 简单的上报速度
 * 
 * 支持subkey，但必须在使用前先定义
 * 支持设置split  timline两种模式
 * (打点时间，split以上一个统计时间为准，timline以开始时间为准)
 * split 自定义开始时间 (可配置 alias:min/max)
 * 可定义上报闸值自动上报 (可配置 key:min/max)
 * 
 * @param  {String/Object/Array} keys    上报的keys
 * @param  {Object}              options 上报的配置
 *
 * @example
 * assertTime(1000);
 * assertTime({step1: 1000, step2:1001, step3:1002});
 * 
 * assertTime([1000, 'step1', 'step2', 'step3']);
 * 	==
 * 	assertTime(
 * 	{
 * 		'step1': 1000,
 * 		'step2': 1001,
 * 		'step3': 1002,
 * 		'step2:min': ['step1'],
 * 		'step3:min': ['step2']
 * 	]);
 * 
 * assertTime(
 * 	{
 * 		":type": "timeline",
 * 		":values": [1000, 'step1', 'step2', 'step3'],
 * 		"step4": 1003,
 * 		"step3:max": ["step1", "step2"],
 * 		"1004:min": ["step1", "step2"]
 * 	});
 *
 * 
 * keys opts
 * ":type": "split"              split  timline  (defualt:split)
 * ":values": [1000, "step1"]    同数组格式
 * ":start": new Date            起始时间
 * 
 * 　　★ 注意：在:type=timline时，alias的max和min配置无效 ★
 *
 * "alias:min": ["a1", "a2"]     指定此alias开始值取这两个key的最小
 * "alias:max": ["a1", "a2"]     同上 (注：同时存在 max min，取max配置)
 * 
 * "id:min": ["a1", "a2"]        取这些alias最小值上报 (当这几个alias有值时数据)
 * "id:max": ["a1", "a2"]        同上 (注：同时存在 max min，取max配置)
 *
 * 注意：有两个特殊的alias ":start"(初始化时间) ":last"(最后一次上报时间)
 */
function assertTime(keys, options)
{
	// 一般会存在内存问题
	// timeEnd很可能会放到全局啥的地方，然后忘记销毁
	var at = new AssertTime(keys, options);

	return function timeEnd()
	{
		at.handle.apply(at, arguments);
	};
}


function AssertTime(keys, options)
{
	this.reportOptions = options;

	this.supSubkey = typeof keys == 'object';
	this.splitModule = true;
	this.listener = null;
	this.aliasTiming = {};
	this.aliasData = {};
	this.keys = keys;

	if (this.supSubkey)
	{
		var parseKeys = this._parseArrayValues(this.keys);
		if (parseKeys)
		{
			// 数组模式的传入
			this.keys = parseKeys;
		}
		else
		{
			// 非数组
			this.aliasTiming[':start'] = keys[':start'];
			if (keys[':type']) this.splitModule = keys[':type'] != 'timline';
			this.listener = this._parseListener(keys);
			if (keys[':values']) this._parseArrayValues(keys[':values'], keys);
		}
	}

	if (!this.aliasTiming[':start']) this.aliasTiming[':start'] = +(new Date);
	this.aliasTiming[':last'] = this.aliasTiming[':start'];
}


AssertTime.prototype =
{
	handle: function(key, useThisTime, options)
	{
		var st, alias = ':last';
		var now = useThisTime || +(new Date);

		if (key && isNaN(key) && this.supSubkey)
		{
			alias = key;
			key = this.keys[alias];

			if (this.aliasTiming[alias]) return report.warn_(new Error('report twice:'+(key || alias)));

			if (this.splitModule)
			{
				st = this._getConfigStartTime(alias);
				if (st instanceof Error) return report.warn_(st);
			}
		}


		if (!key)
		{
			if (!this.supSubkey && this.keys)
				key = this.keys;
			else
				return report.warn_(new Error('no key in assertTime'));
		}

		if (!st)
		{
			if (this.splitModule)
			{
				st = this.aliasTiming[':last'];
				report.warn_('It is dangerous to use last date:'+key);
			}
			else
			{
				st = this.aliasTiming[':start'];
			}
		}

		this.aliasTiming[':last'] = this.aliasTiming[alias] = now;
		var rs = this.aliasData[alias] = now-st;
		this._fireListener(alias);
		if (this.keys) speed(key, rs, arguments.length > 1 ? options : this.reportOptions);
	},

	// 处理alias的max配置
	_getConfigStartTime: function(alias)
	{
		var stList = this.keys[alias+':max'];
		if (stList)
		{
			var maxList = this._fiterTiming(this.aliasTiming, stList);
			if (!maxList.length) return new Error('has no max values:'+(this.keys[alias] || alias));
			if (maxList.length != stList.length) report.warn_('values not all ready in maxlist:'+(this.keys[alias] || alias));
			return Math.max.apply(Math, maxList);
		}

		stList = this.keys[alias+':min'];
		if (stList)
		{
			var minList = this._fiterTiming(this.aliasTiming, stList);
			if (!minList.length) return new Error('has no min values:'+(this.keys[alias] || alias));
			return Math.min.apply(Math, minList);
		}
	},

	// 判断是否触发listener
	_fireListener: function(alias)
	{
		var myListener = this.listener && this.listener[alias];
		if (myListener)
		{
			for(var lserId in myListener)
			{
				var lser = myListener[lserId];
				var lsterRs = this._fiterTiming(this.aliasData, lser.waits);

				if (lser.type == 'min' || lsterRs.length == lser.waits.length)
				{
					delete this.listener[alias];
					speed(lserId, Math[lser.type].apply(Math, lsterRs), this.reportOptions);
				}
			}
		}
	},

	_parseArrayValues: function(arr, keys)
	{
		if (this._isArray(arr) && typeof arr[0] == 'number')
		{
			keys || (keys = {});

			for(var i = arr.length, start = arr[0]; --i;)
			{
				keys[arr[i]] = start+i-1;
				// 创建max队列
				if (i > 1)
				{
					var maxList = keys[arr[i]+':min'] || (keys[arr[i]+':min'] = []);
					maxList.push(arr[i-1]);
				}
			}

			return keys;
		}
	},

	_parseListener: function(keys)
	{
		var listener = {};
		var hasListener = false;

		for (var key in keys)
		{
			if (key.indexOf(':') > 0)
			{
				var sp = key.split(':');
				var id = sp[0];
				var type = sp[1] || 'max';
				var waits = keys[key];

				if (!id || isNaN(id)
					|| !this._isArray(waits) || !waits.length
					|| (type != 'min' && type != 'max')
					|| (type == 'min' && keys[id+':max'])
				) continue;

				// id
				hasListener = true;
				var lser = {type: type, waits: waits};

				for (var ii = waits.length; ii--;)
				{
					var lserList = listener[waits[ii]] || (listener[waits[ii]] = {});
					lserList[id] = lser;
				}
			}
		}

		if (hasListener) return listener;
	},

	_isArray: function(arr)
	{
		return arr.splice === Array.prototype.splice;
	},

	_fiterTiming: function(timing, list)
	{
		var timList = [];

		if (list)
		{
			for(var i = list.length; i--;)
			{
				var val = timing[list[i]];
				if (val) timList.push(val);
			}
		}

		return timList;
	}
};


report.speed		= speed;
report.assertTime	= assertTime;
report.pageLine		= pageLine;



;(function()
{
	function noopFalse(){return false}


	/**
	 * 上报页面性能，在页面onload后最佳
	 * 数据来自：performance.timing
	 */
	var timingList	= 'navigationStart|unloadEventStart|unloadEventEnd|redirectStart|redirectEnd|fetchStart|domainLookupStart|domainLookupEnd|connectStart|connectEnd|requestStart|responseStart|responseEnd|domLoading|domInteractive|domContentLoadedEventStart|domContentLoadedEventEnd|domComplete|loadEventStart|loadEventEnd'.split('|');
	var BIG_VAL		= Number('300000') || 300000;
	var deadline	= new Date - 3600000;

	function pageSpeed(id, win, options)
	{
		if (!id) return;

		// 参数处理
		if (!options && ((win && win.window !== win) || win === false))
		{
			options = win;
			win = null;
		}
		if (!win) win = window;

		var doc = win.document;
		var reported = false;
		var timing = (win.webkitPerformance || win.performance).timing;

		function _send()
		{
			if (reported) return;
			reported = true;

			win.setTimeout(function()
			{
				var t0 = timing[timingList[0]];
				if (t0 < deadline)
				{
					console && console.warn('LogPageSpeed navigationStart error: %d date: %s', t0, new Date(t0));
					report.v && report.v('log_page_speed|err|navigation_start');
					return;
				}

				var data = _getData(t0, 'timing', timing, options);
				if (!data.length) return;

				report.stat('page_speed', 'app='+id+'&'+data.join('&'), options);
			});
		}


		if (/*doc.readyState == 'complete' || */timing.loadEventEnd)
		{
			_send();
		}
		else
		{
			if (doc.addEventListener)
			{
				doc.addEventListener('load', function()
					{
						_clear();
						_send();
					}, false);
			}

			function _clear()
			{
				wait && win.clearInterval(wait);
				wait2 && win.clearTimeout(wait2);
				wait = wait2 = null;
			}
			// 保护措施
			var wait = win.setInterval(function()
				{
					if (timing.loadEventEnd)
					{
						_clear();
						_send();
					}
				}, 500);

			var wait2 = win.setTimeout(function()
				{
					_clear();
					_send();
				}, 5000);
		}
	}

	var resList = 'startTime|redirectStart|redirectEnd|fetchStart|domainLookupStart|domainLookupEnd|connectStart|secureConnectionStart|connectEnd|requestStart|responseStart|responseEnd'.split('|');
	/**
	 * 资源文件时间点上报
	 * @param  {String}             id         上报的id
	 * @param  {DOMElement/String}  res        获取数据的url地址或则带src的dom节点
	 * @param  {Windows}            win        获取performance的window
	 * @param  {Object}             options    上报的配置
	 */
	function resSpeed(id, res, win, options)
	{
		// 参数处理
		if (!options && ((win && win.window !== win) || win === false))
		{
			options = win;
			win = null;
		}

		if (typeof res != 'string' && res)
		{
			var doc = res.ownerDocument;
			var resWin = doc && (doc.parentWindow || doc.defaultView);
			if (resWin) win = resWin;
			res = res.src;
		}
		if (!win) win = window;
		if (!id || !res || !win) return;


		var entries = (win.webkitPerformance || win.performance).getEntriesByName(res);
		if (!entries || !entries.length) return;


		for(var i = entries.length; i--;)
		{
			var t0 = entries[i][resList[0]];

			// 不能大于100000，必然是假数据
			if (t0 > 1e5) continue;
			var tmp = _getData(t0, 'res', entries[i], options);
			if (!tmp.length) continue;

			report.stat('res_speed', 'app='+id+'&'+tmp.join('&'), options);
		}
	}


	var tList = {res: resList, timing: timingList};
	function _getData(t0, listName, data, options)
	{
		var newData = [];
		var list = tList[listName];
		if (!list) return;

		for (var i = 1, l = list.length; i < l; i++)
		{
			var val = Math.round((data[list[i]] || 0) - t0);
			if (val >= 0)
			{
				newData.push(i + '=' + val);
				if (val > BIG_VAL) report.stat('speed_big_val', val+':'+listName, options);
			}
		}

		return newData;
	}

	var performance = window.webkitPerformance || window.performance;
	report.pageSpeed = performance && performance.timing ? pageSpeed : noopFalse;
	report.resSpeed = performance && performance.getEntriesByName ? resSpeed : noopFalse;
})();



function saveGlobalData(win, winKey, handler)
{
	if (!win.__reportData__ || !win.__reportData__[winKey] || !handler) return;

	for(var data = win.__reportData__[winKey], i = data.length; i--;)
	{
		var args = data[i];
		if (args.runType == 'call')
		{
			handler(args);
		}
		else
		{
			handler.apply(null, args);
		}
	}

	delete win.__reportData__[winKey];
}

report.globalHandlers = [
	{key: 'log', handler: report.log},
	{key: 'stat', handler: report.stat},
	{key: 'speed', handler: report.speed},
	{key: 'pageLine', handler: report.pageLine},
	{key: 'pageSpeed', handler: report.pageSpeed},
	{key: 'resSpeed', handler: report.resSpeed},
	{key: 'assertTime', handler: asserTimeHandler}
];


if (__KVCLICK_KEY__ && __KVCLICK_KEY__.length)
{
	for(var i = __KVCLICK_KEY__.length; i--;)
	{
		var kv_name = __KVCLICK_KEY__[i];
		if (report[kv_name])
		{
			report.globalHandlers.push(
			{
				key		: kv_name,
				handler	: report[kv_name]
			});
		}
	}
}

function asserTimeHandler(args)
{
	var initArgs = args.args;
	var keys = initArgs[0];
	if (!keys)
		keys = {};
	else if (keys.splice === Array.prototype.splice)
		keys = {values: keys}

	keys[':start'] || (keys[':start'] = args.start);
	initArgs[0] = keys;

	var timeEnd = report.assertTime.apply(null, initArgs);

	// 绑定到已经生成的函数上
	args.handler = timeEnd;

	// 处理已经有的上报
	for(var i = 0, data = args.logs, len = data.length; i < len; i++)
	{
		var tInfo = data[i];
		var tArgs = tInfo.args;
		tArgs[1] || (tArgs[1] = tInfo.time);
		timeEnd.apply(null, tArgs);
	}

	args.logs = [];
}

/**
 * 将页面初始化过程中的产生数据，上报到服务器
 * 使用前：请先在页面头部引用 pre_global_include.js
 */
function saveAllGlobalData(win)
{
	setTimeout(function()
	{
		var handlers = report.globalHandlers;
		for(var i = handlers.length; i--;)
		{
			saveGlobalData(win || window, handlers[i].key, handlers[i].handler);
		}
	});
}

report.saveAllGlobalData = saveAllGlobalData;
report.saveGlobalData = saveGlobalData;

// 针对当前页面，进行一个小的汇总上报
saveAllGlobalData();


function handlerName()
{
	var name;
	try {
		name = window.__LQ_REPORT_NAME__ || top.__LQ_REPORT_NAME__;
	}
	catch(e) {}

	return name || 'LQReport';
}
if (typeof exports == "object" && typeof module == "object" && module.exports === exports) {module.exports = report} else {this[handlerName()]=report}
}).call(this);


